from active_forgetting_temporal_reconstruction import (
    ActiveForgettingTemporalReconstructionModule,
    ForgettingPolicy,
)


def main():
    memory = ActiveForgettingTemporalReconstructionModule(
        ForgettingPolicy(
            active_budget_bytes=220,
            target_latent_ratio=0.01,
            recurrent_promotion_threshold=1.5,
        )
    )

    memory.add_block(
        "KV cache pages reuse prefix blocks for long context LLM runtime memory.",
        block_id="kv_prefix",
        importance=0.25,
        tags=["cache", "llm"],
        relations=[("kv_cache", "reuses", "prefix_cache")],
    )
    memory.add_block(
        "PagedAttention stores attention context in virtual-memory-like pages to reduce fragmentation.",
        block_id="paged_attention",
        importance=0.35,
        tags=["attention", "memory"],
        relations=[("paged_attention", "reduces", "fragmentation")],
    )
    memory.add_block(
        "Critical project rule: preserve Cache OS architecture and never flatten memory layers.",
        block_id="stable_rule",
        importance=1.0,
        tags=["critical", "goal"],
        pinned=True,
    )

    print("ACTIVE BYTES BEFORE:", memory.active_bytes())

    plan = memory.prepare_forget(pressure="high")
    print("\nFORGET PLAN")
    print(plan.to_dict())

    applied = memory.apply_forget(plan.plan_id)
    print("\nAPPLIED")
    print(applied)

    hits = memory.search_latent("KV cache prefix reuse")
    print("\nLATENT SEARCH")
    print(hits)

    if hits:
        rec = memory.reconstruct(hits[0]["block_id"], query="KV cache prefix reuse")
        print("\nRECONSTRUCTION")
        print(rec.to_dict())

    print("\nSELF AWARENESS REPORT")
    print(memory.self_awareness_report())

    print("\nPOLICY BUNDLE")
    print(memory.compile_policy_bundle())


if __name__ == "__main__":
    main()
