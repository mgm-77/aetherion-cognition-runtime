from __future__ import annotations

import copy
import hashlib
import json
import math
import re
import time
import uuid
from dataclasses import dataclass, field, asdict
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple


_WORD_RE = re.compile(r"[A-Za-z0-9_\-ăâîșțĂÂÎȘȚ]+", re.UNICODE)
_STOPWORDS = {
    "the", "and", "for", "with", "this", "that", "from", "into", "are", "was", "were", "have", "has",
    "este", "sunt", "care", "din", "pentru", "prin", "cand", "când", "sau", "mai", "foarte", "un", "o", "si", "și",
    "de", "la", "in", "în", "pe", "cu", "nu", "ca", "se", "ce", "cum", "daca", "dacă"
}


def _now() -> float:
    return time.time()


def _stable_json(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def _sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _tokenize(text: str) -> List[str]:
    return [m.group(0).lower() for m in _WORD_RE.finditer(text or "")]


def _extract_concepts(text: str, limit: int = 12) -> List[str]:
    counts: Dict[str, int] = {}
    for tok in _tokenize(text):
        if len(tok) < 3 or tok in _STOPWORDS:
            continue
        counts[tok] = counts.get(tok, 0) + 1
    ranked = sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))
    return [k for k, _ in ranked[:limit]]


def _jaccard(a: Iterable[str], b: Iterable[str]) -> float:
    sa, sb = set(a), set(b)
    if not sa and not sb:
        return 0.0
    return len(sa & sb) / max(1, len(sa | sb))


def _estimate_size(text: str) -> int:
    return len((text or "").encode("utf-8"))


@dataclass
class MemoryBlock:
    id: str
    content: str
    created_at: float = field(default_factory=_now)
    last_accessed_at: float = field(default_factory=_now)
    access_count: int = 0
    importance: float = 0.5
    tags: List[str] = field(default_factory=list)
    concepts: List[str] = field(default_factory=list)
    relations: List[Tuple[str, str, str]] = field(default_factory=list)
    active: bool = True
    pinned: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.importance = max(0.0, min(1.0, float(self.importance)))
        if not self.concepts:
            self.concepts = _extract_concepts(self.content)

    @property
    def size_bytes(self) -> int:
        return _estimate_size(self.content)

    def touch(self) -> None:
        self.last_accessed_at = _now()
        self.access_count += 1


@dataclass
class LatentSkeleton:
    id: str
    original_block_id: str
    concepts: List[str]
    concept_weights: Dict[str, float]
    relations: List[Tuple[str, str, str]]
    tags: List[str]
    temporal_anchor: float
    original_size_bytes: int
    compressed_size_bytes: int
    fingerprint: str
    forgotten_at: float = field(default_factory=_now)
    reconstruction_count: int = 0
    promotion_score: float = 0.0
    confidence: float = 0.65
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def compression_ratio(self) -> float:
        if self.original_size_bytes <= 0:
            return 1.0
        return self.compressed_size_bytes / self.original_size_bytes


@dataclass
class ForgettingPolicy:
    active_budget_bytes: int = 4096
    min_age_seconds: float = 0.0
    redundancy_threshold: float = 0.35
    target_latent_ratio: float = 0.01
    max_candidates_per_run: int = 32
    protect_tags: List[str] = field(default_factory=lambda: ["critical", "pinned", "goal"])
    min_importance_to_keep: float = 0.86
    recurrent_promotion_threshold: float = 2.0
    reconstruction_confidence_floor: float = 0.35
    dry_run_required: bool = True


@dataclass
class ForgetCandidate:
    block_id: str
    score: float
    reason: str
    size_bytes: int
    concepts: List[str]
    projected_latent_bytes: int


@dataclass
class ForgetPlan:
    plan_id: str
    created_at: float
    active_bytes_before: int
    latent_bytes_before: int
    candidates: List[ForgetCandidate]
    projected_active_bytes_after: int
    projected_latent_bytes_after: int
    expected_active_reduction_ratio: float
    safe_to_apply: bool
    warnings: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data["candidates"] = [asdict(c) for c in self.candidates]
        return data


@dataclass
class ReconstructionResult:
    block_id: str
    reconstructed_text: str
    confidence: float
    source: str
    concepts_used: List[str]
    promoted: bool = False
    warnings: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class ActiveForgettingTemporalReconstructionModule:
    """
    Closed-loop active forgetting and approximate temporal reconstruction.

    This module intentionally stores latent skeletons rather than exact backups during normal forgetting.
    Rollback tokens are operational safety checkpoints for failed apply steps; they are not the normal
    reconstruction mechanism.
    """

    version = "2.0.0"

    def __init__(self, policy: Optional[ForgettingPolicy] = None) -> None:
        self.policy = policy or ForgettingPolicy()
        self.active_memory: Dict[str, MemoryBlock] = {}
        self.latent_memory: Dict[str, LatentSkeleton] = {}
        self.prepared_plans: Dict[str, ForgetPlan] = {}
        self.rollback_tokens: Dict[str, Dict[str, Any]] = {}
        self.reactivation_counts: Dict[str, int] = {}
        self.ledger: List[Dict[str, Any]] = []
        self._ledger_hash = "0" * 64
        self.runtime: Any = None
        self.hooks: Dict[str, Callable[..., Any]] = {}
        self._record("init", {"version": self.version})

    # ---------------- Runtime plugin lifecycle ----------------
    def attach(self, runtime: Any) -> "ActiveForgettingTemporalReconstructionModule":
        self.runtime = runtime
        if hasattr(runtime, "register"):
            runtime.register("active_forgetting.add", self.add_block)
            runtime.register("active_forgetting.plan", self.dry_run_forget)
            runtime.register("active_forgetting.prepare", self.prepare_forget)
            runtime.register("active_forgetting.apply", self.apply_forget)
            runtime.register("active_forgetting.reconstruct", self.reconstruct)
            runtime.register("active_forgetting.report", self.self_awareness_report)
            runtime.register("shutdown", self.detach)
        self._record("attach", {"runtime": type(runtime).__name__})
        return self

    def detach(self, *args: Any, **kwargs: Any) -> Dict[str, Any]:
        self._record("detach", {"active_blocks": len(self.active_memory), "latent_skeletons": len(self.latent_memory)})
        self.runtime = None
        return {"ok": True, "detached": True}

    # ---------------- Core memory APIs ----------------
    def add_block(
        self,
        content: str,
        block_id: Optional[str] = None,
        importance: float = 0.5,
        tags: Optional[Sequence[str]] = None,
        relations: Optional[Sequence[Tuple[str, str, str]]] = None,
        pinned: bool = False,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> MemoryBlock:
        block_id = block_id or f"block:{uuid.uuid4().hex[:12]}"
        block = MemoryBlock(
            id=block_id,
            content=content,
            importance=importance,
            tags=list(tags or []),
            relations=list(relations or []),
            pinned=pinned,
            metadata=dict(metadata or {}),
        )
        self.active_memory[block_id] = block
        self._record("add_block", {"block_id": block_id, "size_bytes": block.size_bytes, "concepts": block.concepts})
        return block

    def access_block(self, block_id: str) -> Optional[MemoryBlock]:
        block = self.active_memory.get(block_id)
        if block:
            block.touch()
            self._record("access_active", {"block_id": block_id, "access_count": block.access_count})
            return block
        if block_id in self.latent_memory:
            result = self.reconstruct(block_id)
            return self.active_memory.get(block_id) if result.promoted else None
        return None

    def active_bytes(self) -> int:
        return sum(b.size_bytes for b in self.active_memory.values())

    def latent_bytes(self) -> int:
        return sum(s.compressed_size_bytes for s in self.latent_memory.values())

    # ---------------- Planning ----------------
    def dry_run_forget(self, pressure: str = "normal", target_active_bytes: Optional[int] = None) -> ForgetPlan:
        target = int(target_active_bytes if target_active_bytes is not None else self.policy.active_budget_bytes)
        active_before = self.active_bytes()
        latent_before = self.latent_bytes()
        excess = max(0, active_before - target)
        candidates: List[ForgetCandidate] = []
        warnings: List[str] = []

        if active_before <= target:
            warnings.append("active_memory_within_budget")

        scored = self._score_candidates(pressure=pressure)
        freed = 0
        added_latent = 0
        for block, score, reason in scored:
            if len(candidates) >= self.policy.max_candidates_per_run:
                break
            latent_size = self._latent_size_for(block)
            candidates.append(ForgetCandidate(
                block_id=block.id,
                score=score,
                reason=reason,
                size_bytes=block.size_bytes,
                concepts=list(block.concepts),
                projected_latent_bytes=latent_size,
            ))
            freed += block.size_bytes
            added_latent += latent_size
            if freed >= excess and excess > 0:
                break

        projected_active = max(0, active_before - freed)
        projected_latent = latent_before + added_latent
        reduction = 0.0 if active_before == 0 else freed / active_before
        safe = bool(candidates) and (active_before > target or pressure in {"high", "critical"})
        if pressure == "critical" and not candidates:
            warnings.append("critical_pressure_but_no_forgettable_candidates")
        plan = ForgetPlan(
            plan_id=f"forget_plan:{uuid.uuid4().hex[:12]}",
            created_at=_now(),
            active_bytes_before=active_before,
            latent_bytes_before=latent_before,
            candidates=candidates,
            projected_active_bytes_after=projected_active,
            projected_latent_bytes_after=projected_latent,
            expected_active_reduction_ratio=reduction,
            safe_to_apply=safe,
            warnings=warnings,
        )
        self._record("dry_run_forget", {"plan_id": plan.plan_id, "candidates": len(candidates), "reduction": reduction})
        return plan

    def prepare_forget(self, pressure: str = "normal", target_active_bytes: Optional[int] = None) -> ForgetPlan:
        plan = self.dry_run_forget(pressure=pressure, target_active_bytes=target_active_bytes)
        self.prepared_plans[plan.plan_id] = plan
        self._record("prepare_forget", {"plan_id": plan.plan_id, "safe_to_apply": plan.safe_to_apply})
        return plan

    def apply_forget(self, plan_id: str, allow_unsafe: bool = False) -> Dict[str, Any]:
        plan = self.prepared_plans.get(plan_id)
        if not plan:
            raise KeyError(f"unknown forget plan: {plan_id}")
        if not plan.safe_to_apply and not allow_unsafe:
            self._record("apply_forget_blocked", {"plan_id": plan_id, "reason": "plan_not_safe"})
            return {"ok": False, "applied": False, "reason": "plan_not_safe", "plan_id": plan_id}

        rollback_token = self._checkpoint(reason=f"apply:{plan_id}")
        forgotten: List[str] = []
        for candidate in plan.candidates:
            block = self.active_memory.get(candidate.block_id)
            if not block:
                continue
            skeleton = self._make_skeleton(block)
            self.latent_memory[block.id] = skeleton
            del self.active_memory[block.id]
            forgotten.append(block.id)
        self._record("apply_forget", {"plan_id": plan_id, "forgotten": forgotten, "rollback_token": rollback_token})
        return {
            "ok": True,
            "applied": True,
            "plan_id": plan_id,
            "forgotten": forgotten,
            "rollback_token": rollback_token,
            "active_bytes_after": self.active_bytes(),
            "latent_bytes_after": self.latent_bytes(),
        }

    def rollback(self, rollback_token: str) -> Dict[str, Any]:
        state = self.rollback_tokens.get(rollback_token)
        if not state:
            raise KeyError(f"unknown rollback token: {rollback_token}")
        self.active_memory = copy.deepcopy(state["active_memory"])
        self.latent_memory = copy.deepcopy(state["latent_memory"])
        self.reactivation_counts = copy.deepcopy(state["reactivation_counts"])
        self._record("rollback", {"rollback_token": rollback_token})
        return {"ok": True, "rollback_token": rollback_token, "active_blocks": len(self.active_memory)}

    # ---------------- Reconstruction ----------------
    def reconstruct(self, block_id: str, query: str = "", promote: bool = True) -> ReconstructionResult:
        skeleton = self.latent_memory.get(block_id)
        if not skeleton:
            raise KeyError(f"unknown latent skeleton: {block_id}")

        query_concepts = _extract_concepts(query)
        concept_overlap = _jaccard(query_concepts, skeleton.concepts) if query else 0.5
        confidence = max(
            self.policy.reconstruction_confidence_floor,
            min(0.98, skeleton.confidence * 0.75 + concept_overlap * 0.25 + min(skeleton.reconstruction_count, 5) * 0.02),
        )
        skeleton.reconstruction_count += 1
        self.reactivation_counts[block_id] = self.reactivation_counts.get(block_id, 0) + 1
        skeleton.promotion_score += 1.0 + concept_overlap

        relation_text = "; ".join(f"{a}->{r}->{b}" for a, r, b in skeleton.relations[:5]) or "no explicit relations"
        weighted = sorted(skeleton.concept_weights.items(), key=lambda kv: -kv[1])[:8]
        concept_text = ", ".join(f"{k}:{v:.2f}" for k, v in weighted)
        reconstructed = (
            f"[approximate temporal reconstruction for {block_id}] "
            f"core concepts: {concept_text}. relations: {relation_text}. "
            f"temporal anchor: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(skeleton.temporal_anchor))}. "
            f"fingerprint: {skeleton.fingerprint[:12]}."
        )

        promoted = False
        warnings: List[str] = []
        if confidence < 0.55:
            warnings.append("low_reconstruction_confidence")
        if promote and skeleton.promotion_score >= self.policy.recurrent_promotion_threshold:
            self.active_memory[block_id] = MemoryBlock(
                id=block_id,
                content=reconstructed,
                created_at=skeleton.temporal_anchor,
                last_accessed_at=_now(),
                access_count=skeleton.reconstruction_count,
                importance=min(1.0, 0.5 + skeleton.promotion_score * 0.08),
                tags=list(set(skeleton.tags + ["reconstructed", "promoted"])),
                concepts=list(skeleton.concepts),
                relations=list(skeleton.relations),
                active=True,
                metadata={"reconstructed_from_skeleton": skeleton.id, **skeleton.metadata},
            )
            promoted = True
            self._record("auto_promote_reconstruction", {"block_id": block_id, "promotion_score": skeleton.promotion_score})

        result = ReconstructionResult(
            block_id=block_id,
            reconstructed_text=reconstructed,
            confidence=confidence,
            source="latent_skeleton",
            concepts_used=list(skeleton.concepts),
            promoted=promoted,
            warnings=warnings,
        )
        self._record("reconstruct", {"block_id": block_id, "confidence": confidence, "promoted": promoted})
        return result

    def search_latent(self, query: str, limit: int = 5) -> List[Dict[str, Any]]:
        q_concepts = _extract_concepts(query)
        results = []
        for skeleton in self.latent_memory.values():
            score = _jaccard(q_concepts, skeleton.concepts) * 0.7 + min(1.0, skeleton.promotion_score / 5.0) * 0.3
            if score > 0:
                results.append({
                    "block_id": skeleton.original_block_id,
                    "score": score,
                    "concepts": skeleton.concepts,
                    "compression_ratio": skeleton.compression_ratio,
                    "reconstruction_count": skeleton.reconstruction_count,
                })
        results.sort(key=lambda r: (-r["score"], r["block_id"]))
        self._record("search_latent", {"query": query, "hits": len(results[:limit])})
        return results[:limit]

    # ---------------- Self-awareness / reports ----------------
    def self_awareness_report(self) -> Dict[str, Any]:
        active = self.active_bytes()
        latent = self.latent_bytes()
        original_latent = sum(s.original_size_bytes for s in self.latent_memory.values())
        savings = 0.0 if original_latent == 0 else 1.0 - (latent / original_latent)
        top_forgotten = sorted(self.latent_memory.values(), key=lambda s: (-s.promotion_score, s.original_block_id))[:10]
        report = {
            "ok": True,
            "version": self.version,
            "active_blocks": len(self.active_memory),
            "latent_skeletons": len(self.latent_memory),
            "active_bytes": active,
            "latent_bytes": latent,
            "latent_original_bytes": original_latent,
            "estimated_latent_savings_ratio": savings,
            "knows_what_it_forgot": [
                {
                    "block_id": s.original_block_id,
                    "concepts": s.concepts,
                    "promotion_score": round(s.promotion_score, 3),
                    "confidence": round(s.confidence, 3),
                    "compression_ratio": round(s.compression_ratio, 4),
                }
                for s in top_forgotten
            ],
            "can_reconstruct_count": len(self.latent_memory),
            "ledger_entries": len(self.ledger),
            "ledger_hash": self._ledger_hash,
        }
        self._record("self_awareness_report", {"active_blocks": report["active_blocks"], "latent_skeletons": report["latent_skeletons"]})
        return report

    def metrics(self) -> Dict[str, Any]:
        return {
            "active_bytes": self.active_bytes(),
            "latent_bytes": self.latent_bytes(),
            "active_blocks": len(self.active_memory),
            "latent_skeletons": len(self.latent_memory),
            "average_reconstruction_count": (
                sum(s.reconstruction_count for s in self.latent_memory.values()) / max(1, len(self.latent_memory))
            ),
        }

    def compile_policy_bundle(self) -> Dict[str, Any]:
        bundle = {
            "module": "active_forgetting_temporal_reconstruction",
            "version": self.version,
            "policies": {
                "active_budget_bytes": self.policy.active_budget_bytes,
                "target_latent_ratio": self.policy.target_latent_ratio,
                "protect_tags": list(self.policy.protect_tags),
                "recurrent_promotion_threshold": self.policy.recurrent_promotion_threshold,
                "reconstruction_confidence_floor": self.policy.reconstruction_confidence_floor,
            },
            "integration_hints": {
                "context_windowing": "use latent search hits as low-cost candidates before expanding context window",
                "semantic_indexing": "index skeleton concepts and relations, not full forgotten content",
                "invalidation": "prefer mark_stale for high-promotion skeletons",
                "warming": "warm skeletons with rising promotion_score",
                "kv_cache": "do not store exact forgotten payload unless policy requires exact recall",
            },
        }
        self._record("compile_policy_bundle", {"keys": list(bundle["integration_hints"].keys())})
        return bundle

    # ---------------- Persistence ----------------
    def snapshot(self) -> Dict[str, Any]:
        data = {
            "version": self.version,
            "policy": asdict(self.policy),
            "active_memory": {k: asdict(v) for k, v in self.active_memory.items()},
            "latent_memory": {k: asdict(v) for k, v in self.latent_memory.items()},
            "reactivation_counts": self.reactivation_counts,
            "ledger": self.ledger,
            "ledger_hash": self._ledger_hash,
        }
        return copy.deepcopy(data)

    @classmethod
    def restore(cls, snapshot: Dict[str, Any]) -> "ActiveForgettingTemporalReconstructionModule":
        policy = ForgettingPolicy(**snapshot.get("policy", {}))
        mod = cls(policy=policy)
        mod.active_memory = {
            k: MemoryBlock(**v) for k, v in snapshot.get("active_memory", {}).items()
        }
        mod.latent_memory = {
            k: LatentSkeleton(**v) for k, v in snapshot.get("latent_memory", {}).items()
        }
        mod.reactivation_counts = dict(snapshot.get("reactivation_counts", {}))
        mod.ledger = list(snapshot.get("ledger", []))
        mod._ledger_hash = snapshot.get("ledger_hash", "0" * 64)
        mod._record("restore", {"active_blocks": len(mod.active_memory), "latent_skeletons": len(mod.latent_memory)})
        return mod

    # ---------------- Internals ----------------
    def _score_candidates(self, pressure: str = "normal") -> List[Tuple[MemoryBlock, float, str]]:
        now = _now()
        blocks = list(self.active_memory.values())
        scored: List[Tuple[MemoryBlock, float, str]] = []
        for block in blocks:
            if block.pinned or any(tag in self.policy.protect_tags for tag in block.tags):
                continue
            if block.importance >= self.policy.min_importance_to_keep and pressure != "critical":
                continue
            age = max(0.0, now - block.created_at)
            if age < self.policy.min_age_seconds and pressure not in {"high", "critical"}:
                continue
            recency_gap = max(0.0, now - block.last_accessed_at)
            recency_score = min(1.0, recency_gap / 3600.0) if recency_gap else 0.0
            access_penalty = 1.0 / (1.0 + block.access_count)
            importance_inversion = 1.0 - block.importance
            redundancy = self._max_redundancy(block, blocks)
            pressure_bonus = {"normal": 0.0, "high": 0.15, "critical": 0.3}.get(pressure, 0.0)
            score = (
                importance_inversion * 0.35 +
                access_penalty * 0.25 +
                recency_score * 0.15 +
                redundancy * 0.20 +
                pressure_bonus
            )
            reason_parts = []
            if redundancy >= self.policy.redundancy_threshold:
                reason_parts.append("redundant")
            if block.access_count == 0:
                reason_parts.append("never_accessed")
            if block.importance < 0.4:
                reason_parts.append("low_importance")
            if pressure in {"high", "critical"}:
                reason_parts.append(f"pressure_{pressure}")
            reason = "+".join(reason_parts) or "low_utility"
            scored.append((block, score, reason))
        scored.sort(key=lambda t: (-t[1], t[0].id))
        return scored

    def _max_redundancy(self, block: MemoryBlock, blocks: List[MemoryBlock]) -> float:
        best = 0.0
        for other in blocks:
            if other.id == block.id:
                continue
            best = max(best, _jaccard(block.concepts, other.concepts))
        return best

    def _latent_size_for(self, block: MemoryBlock) -> int:
        return max(24, int(math.ceil(block.size_bytes * self.policy.target_latent_ratio)))

    def _make_skeleton(self, block: MemoryBlock) -> LatentSkeleton:
        tokens = _tokenize(block.content)
        counts: Dict[str, int] = {}
        for tok in tokens:
            if tok in block.concepts:
                counts[tok] = counts.get(tok, 0) + 1
        total = max(1, sum(counts.values()))
        weights = {concept: round(counts.get(concept, 1) / total, 4) for concept in block.concepts}
        fingerprint_payload = {
            "id": block.id,
            "concepts": block.concepts,
            "relations": block.relations,
            "size": block.size_bytes,
            "created_at": int(block.created_at),
        }
        confidence = min(0.95, max(0.45, 0.55 + len(block.concepts) * 0.025 + len(block.relations) * 0.02))
        return LatentSkeleton(
            id=f"skeleton:{block.id}",
            original_block_id=block.id,
            concepts=list(block.concepts),
            concept_weights=weights,
            relations=list(block.relations),
            tags=list(block.tags),
            temporal_anchor=block.created_at,
            original_size_bytes=block.size_bytes,
            compressed_size_bytes=self._latent_size_for(block),
            fingerprint=_sha256_text(_stable_json(fingerprint_payload)),
            confidence=confidence,
            metadata={"source_metadata": block.metadata, "active_forgetting_v": self.version},
        )

    def _checkpoint(self, reason: str) -> str:
        token = f"rollback:{uuid.uuid4().hex[:12]}"
        self.rollback_tokens[token] = {
            "reason": reason,
            "created_at": _now(),
            "active_memory": copy.deepcopy(self.active_memory),
            "latent_memory": copy.deepcopy(self.latent_memory),
            "reactivation_counts": copy.deepcopy(self.reactivation_counts),
        }
        self._record("checkpoint", {"rollback_token": token, "reason": reason})
        return token

    def _record(self, event: str, payload: Dict[str, Any]) -> None:
        entry_base = {
            "ts": _now(),
            "event": event,
            "payload": payload,
            "prev_hash": self._ledger_hash,
        }
        entry_hash = _sha256_text(_stable_json(entry_base))
        entry = {**entry_base, "hash": entry_hash}
        self.ledger.append(entry)
        self._ledger_hash = entry_hash

    def verify_ledger(self) -> bool:
        prev = "0" * 64
        for entry in self.ledger:
            base = {"ts": entry["ts"], "event": entry["event"], "payload": entry["payload"], "prev_hash": prev}
            if entry.get("hash") != _sha256_text(_stable_json(base)):
                return False
            prev = entry["hash"]
        return True
