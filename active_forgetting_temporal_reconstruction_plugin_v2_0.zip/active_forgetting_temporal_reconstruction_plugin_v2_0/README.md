# Active Forgetting & Temporal Reconstruction Plugin V2.0

A plug-and-play, stdlib-only control-plane module for a memory system that **actively forgets** and can later **approximately reconstruct** forgotten material from compact latent skeletons.

## What V2 adds

- Dry-run forget planning
- Two-phase `prepare_forget` / `apply_forget`
- Rollback token for operational safety
- Latent skeleton graph: concepts, weights, relations, temporal anchor
- Approximate temporal reconstruction with confidence scoring
- Latent semantic search
- Auto-promotion when a forgotten pattern becomes relevant again
- Self-awareness report: what was forgotten, what can be reconstructed, and estimated memory savings
- Tamper-evident audit ledger
- Snapshot / restore
- Runtime hooks

## Important boundary

This module does **not** restore exact forgotten text from a backup during normal reconstruction. It reconstructs from a compact semantic/temporal skeleton. Rollback tokens are for safe transaction recovery during apply steps, not for normal recall.

## Quick start

```python
from active_forgetting_temporal_reconstruction import ActiveForgettingTemporalReconstructionModule, ForgettingPolicy

memory = ActiveForgettingTemporalReconstructionModule(
    ForgettingPolicy(active_budget_bytes=4096, target_latent_ratio=0.01)
)

memory.add_block("KV cache pages reuse prefix cache blocks.", block_id="kv1")
plan = memory.prepare_forget(pressure="high")
applied = memory.apply_forget(plan.plan_id)

result = memory.reconstruct(applied["forgotten"][0], query="KV prefix reuse")
print(result.reconstructed_text)
```

## Test

```bash
PYTHONPATH=. python -m unittest discover -s tests -v
PYTHONPATH=. python examples/demo_active_forgetting_temporal_reconstruction_v2.py
```
