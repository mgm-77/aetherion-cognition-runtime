import unittest

from active_forgetting_temporal_reconstruction import (
    ActiveForgettingTemporalReconstructionModule,
    ForgettingPolicy,
)


class ActiveForgettingV2Tests(unittest.TestCase):
    def make_module(self):
        return ActiveForgettingTemporalReconstructionModule(
            ForgettingPolicy(active_budget_bytes=170, target_latent_ratio=0.01, recurrent_promotion_threshold=1.2)
        )

    def seed(self, mod):
        mod.add_block(
            "KV cache prefix reuse and paged attention memory pages for long context runtime",
            block_id="b1",
            importance=0.25,
            tags=["cache"],
            relations=[("kv_cache", "uses", "paged_attention")],
        )
        mod.add_block(
            "KV cache prefix reuse and semantic cache relevance for context compression",
            block_id="b2",
            importance=0.2,
            tags=["cache"],
        )
        mod.add_block(
            "Critical system goal: preserve safety rules and runtime architecture",
            block_id="goal",
            importance=1.0,
            tags=["critical", "goal"],
            pinned=True,
        )

    def test_add_and_extract_concepts(self):
        mod = self.make_module()
        block = mod.add_block("Semantic memory reconstructs forgotten cache concepts", block_id="x")
        self.assertIn("semantic", block.concepts)
        self.assertGreater(block.size_bytes, 0)

    def test_dry_run_creates_plan(self):
        mod = self.make_module()
        self.seed(mod)
        plan = mod.dry_run_forget(pressure="high")
        self.assertTrue(plan.candidates)
        self.assertTrue(plan.safe_to_apply)
        self.assertLess(plan.projected_active_bytes_after, plan.active_bytes_before)

    def test_critical_and_pinned_are_protected(self):
        mod = self.make_module()
        self.seed(mod)
        plan = mod.dry_run_forget(pressure="critical")
        ids = {c.block_id for c in plan.candidates}
        self.assertNotIn("goal", ids)

    def test_prepare_apply_moves_to_latent(self):
        mod = self.make_module()
        self.seed(mod)
        plan = mod.prepare_forget(pressure="high")
        result = mod.apply_forget(plan.plan_id)
        self.assertTrue(result["ok"])
        self.assertTrue(result["forgotten"])
        for bid in result["forgotten"]:
            self.assertIn(bid, mod.latent_memory)
            self.assertNotIn(bid, mod.active_memory)

    def test_reconstruction_from_skeleton(self):
        mod = self.make_module()
        self.seed(mod)
        result = mod.apply_forget(mod.prepare_forget(pressure="high").plan_id)
        bid = result["forgotten"][0]
        rec = mod.reconstruct(bid, query="paged attention kv cache")
        self.assertEqual(rec.source, "latent_skeleton")
        self.assertGreaterEqual(rec.confidence, mod.policy.reconstruction_confidence_floor)
        self.assertIn("core concepts", rec.reconstructed_text)

    def test_auto_promotion_when_recurrent(self):
        mod = self.make_module()
        self.seed(mod)
        result = mod.apply_forget(mod.prepare_forget(pressure="high").plan_id)
        bid = result["forgotten"][0]
        rec = mod.reconstruct(bid, query="kv cache prefix", promote=True)
        self.assertTrue(rec.promoted)
        self.assertIn(bid, mod.active_memory)

    def test_search_latent(self):
        mod = self.make_module()
        self.seed(mod)
        mod.apply_forget(mod.prepare_forget(pressure="high").plan_id)
        hits = mod.search_latent("semantic cache prefix")
        self.assertTrue(hits)
        self.assertIn("score", hits[0])

    def test_rollback_restores_active(self):
        mod = self.make_module()
        self.seed(mod)
        before = set(mod.active_memory.keys())
        applied = mod.apply_forget(mod.prepare_forget(pressure="high").plan_id)
        mod.rollback(applied["rollback_token"])
        self.assertEqual(before, set(mod.active_memory.keys()))
        self.assertEqual(len(mod.latent_memory), 0)

    def test_snapshot_restore(self):
        mod = self.make_module()
        self.seed(mod)
        mod.apply_forget(mod.prepare_forget(pressure="high").plan_id)
        snap = mod.snapshot()
        restored = ActiveForgettingTemporalReconstructionModule.restore(snap)
        self.assertEqual(set(mod.latent_memory.keys()), set(restored.latent_memory.keys()))
        self.assertTrue(restored.verify_ledger())

    def test_self_awareness_report(self):
        mod = self.make_module()
        self.seed(mod)
        mod.apply_forget(mod.prepare_forget(pressure="high").plan_id)
        report = mod.self_awareness_report()
        self.assertTrue(report["ok"])
        self.assertGreaterEqual(report["can_reconstruct_count"], 1)
        self.assertIn("knows_what_it_forgot", report)

    def test_policy_bundle(self):
        mod = self.make_module()
        bundle = mod.compile_policy_bundle()
        self.assertEqual(bundle["module"], "active_forgetting_temporal_reconstruction")
        self.assertIn("context_windowing", bundle["integration_hints"])

    def test_ledger_verifies(self):
        mod = self.make_module()
        self.seed(mod)
        self.assertTrue(mod.verify_ledger())

    def test_within_budget_warns(self):
        mod = ActiveForgettingTemporalReconstructionModule(ForgettingPolicy(active_budget_bytes=999999))
        mod.add_block("small memory block", block_id="small")
        plan = mod.dry_run_forget()
        self.assertIn("active_memory_within_budget", plan.warnings)

    def test_access_latent_triggers_reconstruction(self):
        mod = self.make_module()
        self.seed(mod)
        applied = mod.apply_forget(mod.prepare_forget(pressure="high").plan_id)
        bid = applied["forgotten"][0]
        block = mod.access_block(bid)
        self.assertIsNotNone(block)

    def test_compression_ratio_is_small(self):
        mod = self.make_module()
        mod.add_block("x" * 5000, block_id="large", importance=0.1)
        applied = mod.apply_forget(mod.prepare_forget(pressure="high", target_active_bytes=0).plan_id)
        skel = mod.latent_memory[applied["forgotten"][0]]
        self.assertLessEqual(skel.compression_ratio, 0.02)


if __name__ == "__main__":
    unittest.main()
