import json
import tempfile
import unittest

from active_forgetting_temporal_reconstruction import ActiveForgettingMemoryModule, ForgettingPolicy


class TestActiveForgettingTemporalReconstruction(unittest.TestCase):
    def make_memory(self):
        return ActiveForgettingMemoryModule(ForgettingPolicy(active_memory_budget_bytes=500, auto_promote_relevance_threshold=0.2, auto_promote_reconstruct_count=1))

    def test_add_and_get_active_block(self):
        m = self.make_memory()
        bid = m.add_block("Important active memory about KV cache and semantic routing.", importance=0.8)
        self.assertIn("KV cache", m.get(bid))
        self.assertEqual(m.stats["added"], 1)

    def test_forgetting_creates_latent_skeleton(self):
        m = self.make_memory()
        m.add_block("Critical pinned goal about Cache OS.", importance=1.0, pinned=True)
        for i in range(8):
            m.add_block(f"Repeated redundant log block about cache warming and batch flushing {i}. cache warming batch flushing repeated.", importance=0.2)
        m.run_forgetting_cycle()
        self.assertGreater(len(m.latent), 0)
        self.assertGreater(m.stats["forgotten"], 0)

    def test_pinned_block_not_forgotten(self):
        m = self.make_memory()
        bid = m.add_block("Pinned critical system goal that must remain active.", importance=1.0, pinned=True)
        for i in range(8):
            m.add_block(f"noise noise noise repeated block {i} noise noise noise", importance=0.1)
        m.run_forgetting_cycle()
        self.assertIn(bid, m.active)
        self.assertNotIn(bid, m.latent)

    def test_reconstruction_from_latent(self):
        m = self.make_memory()
        bid = m.add_block("PagedAttention stores KV cache in pages and shares prefixes across sequences.", importance=0.1)
        sk = m.forget_to_latent(bid)
        self.assertIsNotNone(sk)
        rr = m.reconstruct(bid, query="KV pages prefix sequences")
        self.assertTrue(rr.ok)
        self.assertIn("Core concepts", rr.reconstructed_content)

    def test_query_reconstructs_relevant_latent(self):
        m = self.make_memory()
        bid = m.add_block("Semantic indexing keeps concepts entities relations and tone for semantic lookup.", importance=0.1)
        m.forget_to_latent(bid)
        hits = m.query("semantic concepts relations", reconstruct=True)
        self.assertTrue(any(h["block_id"] == bid for h in hits))
        self.assertTrue(any("reconstructed" in h for h in hits if h["block_id"] == bid))

    def test_auto_promotion_after_reconstruction(self):
        m = self.make_memory()
        bid = m.add_block("Prefix cache reuse is important for long context memory.", importance=0.1)
        m.forget_to_latent(bid)
        rr = m.reconstruct(bid, query="prefix cache reuse")
        self.assertTrue(rr.promoted)
        self.assertIn(bid, m.reconstructed)

    def test_snapshot_restore(self):
        m = self.make_memory()
        bid = m.add_block("Snapshot restore test with semantic memory and latent skeleton.", importance=0.1)
        m.forget_to_latent(bid)
        snap = m.snapshot()
        m2 = ActiveForgettingMemoryModule()
        m2.restore(snap)
        self.assertIn(bid, m2.latent)
        self.assertTrue(m2.ledger.verify())

    def test_file_flush_and_load(self):
        with tempfile.TemporaryDirectory() as td:
            path = f"{td}/memory.json"
            m = ActiveForgettingMemoryModule(storage_path=path)
            bid = m.add_block("Persistent active forgetting memory block.", importance=0.3)
            m.flush()
            m2 = ActiveForgettingMemoryModule(storage_path=path)
            self.assertTrue(m2.load())
            self.assertIn(bid, m2.active)

    def test_policy_bundle(self):
        m = self.make_memory()
        bundle = m.policy_bundle()
        self.assertIn("integration_hints", bundle)
        self.assertIn("semantic_indexing", bundle["integration_hints"])

    def test_report_has_memory_reduction_metric(self):
        m = self.make_memory()
        for i in range(6):
            m.add_block(f"redundant redundant cache block {i} semantic cache cache cache", importance=0.1)
        m.run_forgetting_cycle()
        report = m.report()
        self.assertIn("estimated_memory_reduction", report)
        self.assertTrue(report["ledger_ok"])

    def test_readiness_report(self):
        m = self.make_memory()
        rr = m.readiness_report()
        self.assertTrue(rr["ready_for_cache_os"])
        self.assertTrue(rr["supports_temporal_reconstruction"])


if __name__ == "__main__":
    unittest.main()
