# Active Forgetting & Temporal Reconstruction Plugin v1.0

Plug-and-play cognitive/runtime memory module for **active forgetting** and **temporal reconstruction**.

It targets the real failure mode where a runtime either keeps everything and drowns in noise, or deletes aggressively and loses useful context.

## What it does

- Stores full blocks in active memory.
- Under pressure, detects redundant/old/low-use blocks.
- Replaces selected blocks with compact vector-like skeletons.
- Moves skeletons into a latent layer.
- Reconstructs approximate details from skeletons when a forgotten concept becomes relevant again.
- Auto-promotes reconstructed memories if they become relevant repeatedly.
- Keeps a tamper-evident audit ledger.

## Important limit

This is a **stdlib-only control-plane/reference module**. It does not contain a neural decoder and does not guarantee exact reconstruction. It reconstructs approximate detail from concept weights, temporal weights, relation hints, and tone. A real production version can plug in a learned decoder or vector store.

The target metrics in the idea are treated as benchmark targets:

- 90% active memory reduction: possible on highly redundant blocks, must be benchmarked per workload.
- sub-10ms reconstruction: likely for this local reference reconstructor on small skeletons, must be benchmarked on target hardware.
- no external reminder: supported architecturally through latent skeleton index + query-triggered reconstruction.

## Quick start

```python
from active_forgetting_temporal_reconstruction import ActiveForgettingMemoryModule, ForgettingPolicy

memory = ActiveForgettingMemoryModule(ForgettingPolicy(active_memory_budget_bytes=700))

memory.add_block("KV cache pages reuse prefix cache blocks for long context decode.", tags=["kv", "cache"], importance=0.7)
memory.add_block("KV cache pages reuse prefix cache blocks for long context decode with paged attention.", tags=["kv", "cache"], importance=0.45)

memory.run_forgetting_cycle()
print(memory.query("prefix cache paged attention", reconstruct=True))
print(memory.report())
```

## Runtime hooks

- `memory.add`
- `memory.pressure`
- `memory.reconstruct`
- `memory.query`
- `shutdown`

## Integration hints

- **Semantic Indexing**: use concept weights as latent index features.
- **Hierarchical Cache**: keep active blocks in L1/L2; move skeletons to L3/L4.
- **Predictive Preloading**: promote skeletons before expected reuse.
- **Invalidation Strategy**: compress to latent before destructive eviction.
- **KV Cache**: store token/page semantic importance in metadata.
