from active_forgetting_temporal_reconstruction import ActiveForgettingMemoryModule, ForgettingPolicy


def main():
    memory = ActiveForgettingMemoryModule(
        ForgettingPolicy(
            active_memory_budget_bytes=500,
            auto_promote_relevance_threshold=0.25,
            auto_promote_reconstruct_count=1,
        )
    )

    blocks = [
        ("Goal: build a Cache OS for LLM runtime memory with KV cache, prefix cache, semantic routing and feedback loops.", ["goal", "cache"], 0.95, True),
        ("KV cache pages reuse prefix cache blocks during long context decode. PagedAttention splits KV memory into dynamic pages.", ["kv", "paged_attention"], 0.62, False),
        ("KV cache pages reuse prefix cache blocks during long context decode. PagedAttention avoids fragmentation by page tables.", ["kv", "paged_attention"], 0.42, False),
        ("Semantic indexing stores concepts, entities, relations and tone, allowing semantic cache lookup instead of literal lookup.", ["semantic"], 0.58, False),
        ("Old logs: repeated runtime messages about batch update flushing and cache warming startup plans. Old logs repeated runtime messages.", ["logs"], 0.25, False),
        ("More old logs: repeated runtime messages about batch update flushing and cache warming startup plans. Old logs repeated runtime messages.", ["logs"], 0.2, False),
    ]
    for text, tags, importance, pinned in blocks:
        memory.add_block(text, tags=tags, importance=importance, pinned=pinned)

    print("BEFORE")
    print(memory.report())

    decisions = memory.run_forgetting_cycle(reason="demo_pressure")
    print("\nFORGETTING DECISIONS")
    for d in decisions:
        print(d.to_dict())

    print("\nQUERY + RECONSTRUCT")
    hits = memory.query("paged attention prefix cache dynamic pages", reconstruct=True)
    for hit in hits:
        print(hit)

    print("\nREADINESS")
    print(memory.readiness_report())


if __name__ == "__main__":
    main()
