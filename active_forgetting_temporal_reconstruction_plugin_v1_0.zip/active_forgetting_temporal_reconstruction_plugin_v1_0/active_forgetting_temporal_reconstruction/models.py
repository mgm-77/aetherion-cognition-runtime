from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional
import time


@dataclass
class VectorSkeleton:
    block_id: str
    created_at: float
    original_bytes: int
    skeleton_bytes: int
    concept_weights: Dict[str, float]
    temporal_weights: Dict[str, float]
    relation_hints: List[str]
    tone: str = "neutral"
    summary_hint: str = ""
    access_count_before_forget: int = 0
    reconstruction_count: int = 0

    @property
    def compression_ratio(self) -> float:
        if self.original_bytes <= 0:
            return 1.0
        return round(self.skeleton_bytes / self.original_bytes, 6)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "VectorSkeleton":
        return cls(**data)


@dataclass
class MemoryBlock:
    id: str
    content: str
    tags: List[str] = field(default_factory=list)
    importance: float = 0.5
    created_at: float = field(default_factory=time.time)
    last_access: float = field(default_factory=time.time)
    access_count: int = 0
    status: str = "active"  # active | latent | reconstructed
    pinned: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)
    skeleton: Optional[VectorSkeleton] = None

    @property
    def size_bytes(self) -> int:
        return len(self.content.encode("utf-8"))

    def touch(self) -> None:
        self.last_access = time.time()
        self.access_count += 1

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data["skeleton"] = self.skeleton.to_dict() if self.skeleton else None
        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MemoryBlock":
        sk = data.get("skeleton")
        data = dict(data)
        data["skeleton"] = VectorSkeleton.from_dict(sk) if sk else None
        return cls(**data)


@dataclass
class ForgettingDecision:
    block_id: str
    action: str  # keep_active | compress_to_latent | forget_candidate | promote_active
    score: float
    reason: str
    compression_ratio: Optional[float] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ReconstructionResult:
    block_id: str
    ok: bool
    reconstructed_content: str
    confidence: float
    source: str
    promoted: bool = False
    reason: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
