from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional, Tuple

from .ledger import AuditLedger
from .models import ForgettingDecision, MemoryBlock, ReconstructionResult, VectorSkeleton
from .policy import ForgettingPolicy
from .reconstructor import TemporalReconstructor
from .skeletonizer import Skeletonizer
from .utils import byte_size, concept_weights, cosine_like, redundancy_score, stable_hash, temporal_decay


class ActiveForgettingMemoryModule:
    """Plug-and-play active forgetting + temporal reconstruction memory module.

    Core behavior:
    - active memory stores full blocks
    - under pressure, redundant/old/low-use blocks become compact latent skeletons
    - latent skeletons know what was forgotten and can be reconstructed on demand
    - repeated reconstruction/relevance auto-promotes a block back to active memory
    """

    def __init__(self, policy: Optional[ForgettingPolicy] = None, storage_path: Optional[str] = None) -> None:
        self.policy = policy or ForgettingPolicy()
        self.storage_path = Path(storage_path) if storage_path else None
        self.active: Dict[str, MemoryBlock] = {}
        self.latent: Dict[str, VectorSkeleton] = {}
        self.reconstructed: Dict[str, MemoryBlock] = {}
        self.hooks: Dict[str, List[Callable[..., Any]]] = {}
        self.ledger = AuditLedger()
        self.skeletonizer = Skeletonizer(self.policy)
        self.reconstructor = TemporalReconstructor()
        self.runtime: Any = None
        self.stats = {
            "added": 0,
            "forgotten": 0,
            "reconstructed": 0,
            "promoted": 0,
            "pressure_runs": 0,
            "queries": 0,
        }

    # ---------------- Plug-in lifecycle ----------------
    def attach(self, runtime: Any) -> "ActiveForgettingMemoryModule":
        self.runtime = runtime
        if hasattr(runtime, "register"):
            runtime.register("memory.active_forgetting", self)
        if hasattr(runtime, "on"):
            runtime.on("memory.add", self.add_block)
            runtime.on("memory.pressure", self.run_forgetting_cycle)
            runtime.on("memory.reconstruct", self.reconstruct)
            runtime.on("memory.query", self.query)
            runtime.on("shutdown", self.flush)
        self.ledger.append("attach", {"runtime": type(runtime).__name__})
        return self

    def detach(self) -> None:
        self.flush()
        self.ledger.append("detach", {})
        self.runtime = None

    def on(self, event: str, handler: Callable[..., Any]) -> None:
        self.hooks.setdefault(event, []).append(handler)

    def emit(self, event: str, payload: Dict[str, Any]) -> None:
        for handler in self.hooks.get(event, []):
            handler(payload)

    # ---------------- Core memory API ----------------
    def add_block(
        self,
        content: str,
        block_id: Optional[str] = None,
        tags: Optional[List[str]] = None,
        importance: float = 0.5,
        pinned: bool = False,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> str:
        bid = block_id or stable_hash(content + str(time.time()), 18)
        block = MemoryBlock(
            id=bid,
            content=content,
            tags=tags or [],
            importance=max(0.0, min(1.0, importance)),
            pinned=pinned,
            metadata=metadata or {},
        )
        self.active[bid] = block
        self.stats["added"] += 1
        self.ledger.append("add_block", {"block_id": bid, "bytes": block.size_bytes, "importance": block.importance})
        self.emit("memory.added", {"block_id": bid})
        if self.active_bytes() > self.policy.active_memory_budget_bytes:
            self.run_forgetting_cycle(reason="budget_exceeded")
        return bid

    def get(self, block_id: str, reconstruct_if_latent: bool = True) -> Optional[str]:
        if block_id in self.active:
            self.active[block_id].touch()
            return self.active[block_id].content
        if block_id in self.reconstructed:
            self.reconstructed[block_id].touch()
            return self.reconstructed[block_id].content
        if reconstruct_if_latent and block_id in self.latent:
            return self.reconstruct(block_id).reconstructed_content
        return None

    def query(self, query: str, limit: int = 5, reconstruct: bool = True) -> List[Dict[str, Any]]:
        self.stats["queries"] += 1
        qcw = concept_weights(query, max_terms=24)
        results: List[Tuple[float, Dict[str, Any]]] = []
        for bid, block in self.active.items():
            score = cosine_like(concept_weights(block.content, max_terms=24), qcw)
            if score > 0:
                block.touch()
                results.append((score, {"block_id": bid, "status": "active", "score": score, "content": block.content}))
        for bid, skeleton in self.latent.items():
            score = cosine_like(skeleton.concept_weights, qcw)
            if score > 0:
                item: Dict[str, Any] = {"block_id": bid, "status": "latent", "score": score, "skeleton": skeleton.to_dict()}
                if reconstruct and score >= self.policy.auto_promote_relevance_threshold:
                    rr = self.reconstruct(bid, query=query)
                    item.update({"reconstructed": rr.to_dict(), "content": rr.reconstructed_content})
                results.append((score, item))
        results.sort(key=lambda t: t[0], reverse=True)
        self.ledger.append("query", {"query_hash": stable_hash(query), "hits": len(results)})
        return [r for _, r in results[:limit]]

    # ---------------- Active forgetting ----------------
    def active_bytes(self) -> int:
        return sum(b.size_bytes for b in self.active.values())

    def latent_bytes(self) -> int:
        return sum(s.skeleton_bytes for s in self.latent.values())

    def total_original_bytes_tracked(self) -> int:
        return self.active_bytes() + sum(s.original_bytes for s in self.latent.values())

    def analyze_forgetting_candidates(self) -> List[ForgettingDecision]:
        active_texts = [b.content for b in self.active.values()]
        decisions: List[ForgettingDecision] = []
        for bid, block in self.active.items():
            if block.pinned and self.policy.preserve_pinned:
                decisions.append(ForgettingDecision(bid, "keep_active", 1.0, "pinned block"))
                continue
            if block.importance >= self.policy.critical_importance_threshold:
                decisions.append(ForgettingDecision(bid, "keep_active", 0.95, "critical importance"))
                continue
            redundancy = redundancy_score(block.content, active_texts)
            age = temporal_decay(block.created_at)
            low_access = 1.0 / (1.0 + block.access_count)
            low_importance = 1.0 - block.importance
            forget_score = (
                self.policy.redundancy_weight * redundancy
                + self.policy.age_weight * age
                + self.policy.low_access_weight * low_access
                + self.policy.low_importance_weight * low_importance
            )
            action = "compress_to_latent" if forget_score >= 0.28 else "keep_active"
            reason = f"redundancy={redundancy:.3f}, age={age:.3f}, low_access={low_access:.3f}, low_importance={low_importance:.3f}"
            decisions.append(ForgettingDecision(bid, action, round(forget_score, 6), reason))
        decisions.sort(key=lambda d: d.score, reverse=True)
        return decisions

    def run_forgetting_cycle(self, reason: str = "manual", target_bytes: Optional[int] = None) -> List[ForgettingDecision]:
        self.stats["pressure_runs"] += 1
        budget = target_bytes if target_bytes is not None else self.policy.active_memory_budget_bytes
        decisions = self.analyze_forgetting_candidates()
        applied: List[ForgettingDecision] = []
        for d in decisions:
            if self.active_bytes() <= budget:
                break
            if d.action == "compress_to_latent":
                sk = self.forget_to_latent(d.block_id, reason=d.reason)
                if sk:
                    d.compression_ratio = sk.compression_ratio
                    applied.append(d)
        self.ledger.append("forgetting_cycle", {"reason": reason, "applied": [a.to_dict() for a in applied]})
        self.emit("memory.forgetting_cycle", {"reason": reason, "applied": [a.to_dict() for a in applied]})
        return applied

    def forget_to_latent(self, block_id: str, reason: str = "manual") -> Optional[VectorSkeleton]:
        block = self.active.get(block_id)
        if not block:
            return None
        if block.pinned and self.policy.preserve_pinned:
            return None
        sk = self.skeletonizer.skeletonize(block_id, block.content, block.access_count)
        block.status = "latent"
        block.skeleton = sk
        self.latent[block_id] = sk
        del self.active[block_id]
        self.stats["forgotten"] += 1
        self.ledger.append("forget_to_latent", {
            "block_id": block_id,
            "reason": reason,
            "original_bytes": sk.original_bytes,
            "skeleton_bytes": sk.skeleton_bytes,
            "compression_ratio": sk.compression_ratio,
        })
        self.emit("memory.forgotten", {"block_id": block_id, "skeleton": sk.to_dict()})
        return sk

    def reconstruct(self, block_id: str, query: str = "") -> ReconstructionResult:
        sk = self.latent.get(block_id)
        if not sk:
            if block_id in self.active:
                return ReconstructionResult(block_id, True, self.active[block_id].content, 1.0, "active", False, "already active")
            return ReconstructionResult(block_id, False, "", 0.0, "missing", False, "no latent skeleton")
        rr = self.reconstructor.reconstruct(sk, query=query)
        self.stats["reconstructed"] += 1
        should_promote = (
            rr.confidence >= self.policy.reconstruction_confidence_threshold
            and (
                sk.reconstruction_count >= self.policy.auto_promote_reconstruct_count
                or (query and cosine_like(sk.concept_weights, concept_weights(query, max_terms=24)) >= self.policy.auto_promote_relevance_threshold)
            )
        )
        if should_promote:
            block = MemoryBlock(
                id=block_id,
                content=rr.reconstructed_content,
                tags=["reconstructed", "latent"],
                importance=min(0.9, 0.45 + rr.confidence * 0.45),
                status="reconstructed",
                metadata={"reconstructed_from": "latent_skeleton", "source_confidence": rr.confidence},
                skeleton=sk,
            )
            self.reconstructed[block_id] = block
            rr.promoted = True
            self.stats["promoted"] += 1
            self.ledger.append("promote_reconstructed", {"block_id": block_id, "confidence": rr.confidence})
        self.ledger.append("reconstruct", rr.to_dict())
        self.emit("memory.reconstructed", rr.to_dict())
        return rr

    # ---------------- Reports / snapshots ----------------
    def report(self) -> Dict[str, Any]:
        original = self.total_original_bytes_tracked()
        current = self.active_bytes() + self.latent_bytes() + sum(b.size_bytes for b in self.reconstructed.values())
        reduction = 0.0 if original <= 0 else 1.0 - min(1.0, current / original)
        return {
            "module": "active_forgetting_temporal_reconstruction",
            "version": "1.0.0",
            "active_blocks": len(self.active),
            "latent_skeletons": len(self.latent),
            "reconstructed_blocks": len(self.reconstructed),
            "active_bytes": self.active_bytes(),
            "latent_bytes": self.latent_bytes(),
            "tracked_original_bytes": original,
            "estimated_memory_reduction": round(reduction, 6),
            "stats": dict(self.stats),
            "ledger_ok": self.ledger.verify(),
            "policy": self.policy.to_dict(),
        }

    def readiness_report(self) -> Dict[str, Any]:
        r = self.report()
        return {
            "ok": True,
            "ready_for_cache_os": True,
            "supports_active_forgetting": True,
            "supports_temporal_reconstruction": True,
            "supports_auto_promotion": True,
            "notes": [
                "Reconstruction is approximate from latent skeletons, not exact backup restore.",
                "For sub-10ms guarantees, benchmark on target hardware and replace reference reconstructor if needed.",
            ],
            "summary": r,
        }

    def policy_bundle(self) -> Dict[str, Any]:
        return {
            "module": "active_forgetting_temporal_reconstruction",
            "version": "1.0.0",
            "hooks": ["memory.add", "memory.pressure", "memory.reconstruct", "memory.query", "shutdown"],
            "integration_hints": {
                "semantic_indexing": "use concept_weights as latent index features",
                "hierarchical_cache": "move latent skeletons to L3/L4 while keeping active blocks in L1/L2",
                "predictive_preloading": "promote latent skeletons when topic transition predicts reuse",
                "invalidation_strategy": "prefer latent compression before destructive eviction",
                "kv_cache": "store token/page semantic importance in block metadata",
            },
            "policy": self.policy.to_dict(),
        }

    def snapshot(self) -> Dict[str, Any]:
        return {
            "policy": self.policy.to_dict(),
            "active": {k: v.to_dict() for k, v in self.active.items()},
            "latent": {k: v.to_dict() for k, v in self.latent.items()},
            "reconstructed": {k: v.to_dict() for k, v in self.reconstructed.items()},
            "stats": dict(self.stats),
            "ledger": self.ledger.to_list(),
        }

    def restore(self, data: Dict[str, Any]) -> None:
        self.policy = ForgettingPolicy.from_dict(data.get("policy", {}))
        self.skeletonizer = Skeletonizer(self.policy)
        self.active = {k: MemoryBlock.from_dict(v) for k, v in data.get("active", {}).items()}
        self.latent = {k: VectorSkeleton.from_dict(v) for k, v in data.get("latent", {}).items()}
        self.reconstructed = {k: MemoryBlock.from_dict(v) for k, v in data.get("reconstructed", {}).items()}
        self.stats = data.get("stats", dict(self.stats))
        self.ledger = AuditLedger()
        self.ledger.load_list(data.get("ledger", []))

    def flush(self) -> None:
        if not self.storage_path:
            return
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)
        self.storage_path.write_text(json.dumps(self.snapshot(), indent=2, sort_keys=True), encoding="utf-8")

    def load(self) -> bool:
        if not self.storage_path or not self.storage_path.exists():
            return False
        self.restore(json.loads(self.storage_path.read_text(encoding="utf-8")))
        return True
