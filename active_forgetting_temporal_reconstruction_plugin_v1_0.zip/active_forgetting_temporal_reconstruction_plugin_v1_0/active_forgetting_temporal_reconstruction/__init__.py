"""
Active Forgetting & Temporal Reconstruction Plugin v1.0

A stdlib-only plug-and-play control-plane module for cognitive/runtime memory:
- active forgetting under pressure
- compact latent skeletons
- temporal reconstruction from semantic/vector-like skeletons
- self-aware forgetting ledger
- auto-promotion when forgotten patterns become relevant again

This is not a neural decoder and does not claim exact reconstruction. It provides a
reference/control-plane implementation that can later be backed by vector stores,
small MLP predictors, or model-side reconstruction adapters.
"""

from .module import ActiveForgettingMemoryModule
from .models import MemoryBlock, VectorSkeleton, ReconstructionResult, ForgettingDecision
from .policy import ForgettingPolicy

__all__ = [
    "ActiveForgettingMemoryModule",
    "MemoryBlock",
    "VectorSkeleton",
    "ReconstructionResult",
    "ForgettingDecision",
    "ForgettingPolicy",
]
