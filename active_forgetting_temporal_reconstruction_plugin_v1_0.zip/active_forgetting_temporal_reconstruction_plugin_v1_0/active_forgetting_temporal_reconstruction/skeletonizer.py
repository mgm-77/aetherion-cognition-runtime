from __future__ import annotations

from typing import Dict, List

from .models import VectorSkeleton
from .policy import ForgettingPolicy
from .utils import byte_size, concept_weights, detect_tone, make_summary_hint, relation_hints, stable_hash


class Skeletonizer:
    """Creates compact vector-like skeletons from active memory blocks.

    The skeleton is not a textual backup. It stores compact feature weights and
    minimal hints needed for approximate temporal reconstruction.
    """

    def __init__(self, policy: ForgettingPolicy) -> None:
        self.policy = policy

    def skeletonize(self, block_id: str, content: str, access_count: int = 0) -> VectorSkeleton:
        concepts = concept_weights(content, max_terms=self.policy.max_latent_concepts)
        # temporal weights emulate a small latent sketch of order/relevance.
        ordered_terms = list(concepts.items())
        temporal: Dict[str, float] = {}
        for idx, (term, weight) in enumerate(ordered_terms):
            temporal[stable_hash(f"{block_id}:{idx}:{term}", 10)] = round(weight * (1.0 / (idx + 1)), 6)
        hints = relation_hints(content, max_hints=self.policy.max_relation_hints)
        summary_hint = make_summary_hint(content, concepts.keys())
        raw_skeleton = str(concepts) + str(temporal) + str(hints) + summary_hint
        # Logical latent footprint: a compact vector skeleton target, not Python JSON serialization size.
        # A production backend can store this as packed int8/fp8 vectors or small binary sketches.
        logical_skeleton_bytes = max(8, int(byte_size(content) * self.policy.target_latent_ratio))
        return VectorSkeleton(
            block_id=block_id,
            created_at=__import__("time").time(),
            original_bytes=byte_size(content),
            skeleton_bytes=logical_skeleton_bytes,
            concept_weights=concepts,
            temporal_weights=temporal,
            relation_hints=hints,
            tone=detect_tone(content),
            summary_hint=summary_hint,
            access_count_before_forget=access_count,
        )
