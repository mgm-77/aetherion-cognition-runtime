from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass, asdict
from typing import Any, Dict, List


@dataclass
class LedgerEvent:
    ts: float
    event: str
    payload: Dict[str, Any]
    prev_hash: str
    hash: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class AuditLedger:
    def __init__(self) -> None:
        self.events: List[LedgerEvent] = []

    def append(self, event: str, payload: Dict[str, Any]) -> LedgerEvent:
        prev = self.events[-1].hash if self.events else "GENESIS"
        ts = time.time()
        raw = json.dumps({"ts": ts, "event": event, "payload": payload, "prev_hash": prev}, sort_keys=True, default=str)
        h = hashlib.sha256(raw.encode("utf-8")).hexdigest()
        ev = LedgerEvent(ts=ts, event=event, payload=payload, prev_hash=prev, hash=h)
        self.events.append(ev)
        return ev

    def verify(self) -> bool:
        prev = "GENESIS"
        for ev in self.events:
            raw = json.dumps({"ts": ev.ts, "event": ev.event, "payload": ev.payload, "prev_hash": prev}, sort_keys=True, default=str)
            if hashlib.sha256(raw.encode("utf-8")).hexdigest() != ev.hash:
                return False
            prev = ev.hash
        return True

    def to_list(self) -> List[Dict[str, Any]]:
        return [e.to_dict() for e in self.events]

    def load_list(self, events: List[Dict[str, Any]]) -> None:
        self.events = [LedgerEvent(**e) for e in events]
