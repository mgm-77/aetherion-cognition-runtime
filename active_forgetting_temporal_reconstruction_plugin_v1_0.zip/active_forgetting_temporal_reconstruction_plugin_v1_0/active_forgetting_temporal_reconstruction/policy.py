from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Dict, Any


@dataclass
class ForgettingPolicy:
    active_memory_budget_bytes: int = 16_384
    target_latent_ratio: float = 0.01
    max_latent_concepts: int = 12
    max_relation_hints: int = 6
    preserve_pinned: bool = True
    critical_importance_threshold: float = 0.92
    medium_importance_threshold: float = 0.55
    redundancy_weight: float = 0.35
    age_weight: float = 0.25
    low_access_weight: float = 0.2
    low_importance_weight: float = 0.2
    auto_promote_relevance_threshold: float = 0.42
    auto_promote_reconstruct_count: int = 2
    reconstruction_confidence_threshold: float = 0.35

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ForgettingPolicy":
        return cls(**data)
