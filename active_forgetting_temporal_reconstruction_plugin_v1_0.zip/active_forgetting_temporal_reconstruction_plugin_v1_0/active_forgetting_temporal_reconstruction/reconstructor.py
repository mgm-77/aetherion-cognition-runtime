from __future__ import annotations

from typing import Dict, List, Optional

from .models import ReconstructionResult, VectorSkeleton
from .utils import concept_weights, cosine_like


class TemporalReconstructor:
    """Approximate reconstruction from a vector-like skeleton.

    This intentionally does not restore the exact old text from a backup. It
    produces a usable structured reconstruction from concepts, relation hints and
    temporal weights. A real deployment can replace this with a learned decoder.
    """

    def reconstruct(self, skeleton: VectorSkeleton, query: str = "") -> ReconstructionResult:
        q = concept_weights(query, max_terms=16)
        relevance = cosine_like(skeleton.concept_weights, q) if query else 0.5
        top = sorted(skeleton.concept_weights.items(), key=lambda kv: kv[1], reverse=True)[:8]
        concepts = ", ".join(term for term, _ in top) or "unknown concepts"
        relation_text = "; ".join(skeleton.relation_hints[:3]) if skeleton.relation_hints else "relations unavailable"
        content = (
            f"[reconstructed:{skeleton.block_id}] Core concepts: {concepts}. "
            f"Tone: {skeleton.tone}. Relations: {relation_text}. "
            f"Seed: {skeleton.summary_hint}"
        )
        confidence = max(0.1, min(0.95, 0.35 + 0.45 * relevance + 0.1 * min(1.0, skeleton.access_count_before_forget / 5)))
        skeleton.reconstruction_count += 1
        return ReconstructionResult(
            block_id=skeleton.block_id,
            ok=True,
            reconstructed_content=content,
            confidence=round(confidence, 6),
            source="latent_skeleton",
            promoted=False,
            reason="approximate reconstruction from concept/temporal skeleton",
        )
