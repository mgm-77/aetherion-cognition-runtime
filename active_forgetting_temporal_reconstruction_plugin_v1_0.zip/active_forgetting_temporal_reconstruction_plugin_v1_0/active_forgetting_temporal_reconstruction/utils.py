from __future__ import annotations

import hashlib
import math
import re
import time
from collections import Counter
from typing import Dict, Iterable, List, Sequence, Tuple

STOPWORDS = {
    "the", "and", "for", "with", "that", "this", "from", "are", "was", "were", "you", "your", "about",
    "este", "sunt", "care", "pentru", "prin", "din", "sau", "dar", "mai", "foarte", "acest", "aceasta",
    "un", "o", "si", "și", "la", "in", "în", "pe", "de", "cu", "ca", "ce", "nu", "se", "sa", "să",
}

POSITIVE = {"bun", "excelent", "sigur", "valid", "clar", "important", "useful", "strong", "safe", "good"}
NEGATIVE = {"risc", "eroare", "prost", "invalid", "slab", "danger", "risk", "bad", "wrong", "fail", "failure"}


def now() -> float:
    return time.time()


def tokenize(text: str) -> List[str]:
    return [t.lower() for t in re.findall(r"[A-Za-zÀ-ž0-9_\-]{3,}", text) if t.lower() not in STOPWORDS]


def byte_size(text: str) -> int:
    return len(text.encode("utf-8"))


def stable_hash(text: str, length: int = 16) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:length]


def concept_weights(text: str, max_terms: int = 12) -> Dict[str, float]:
    toks = tokenize(text)
    if not toks:
        return {}
    counts = Counter(toks)
    total = sum(counts.values()) or 1
    ranked = counts.most_common(max_terms)
    return {term: round(count / total, 6) for term, count in ranked}


def relation_hints(text: str, max_hints: int = 6) -> List[str]:
    hints: List[str] = []
    phrases = re.split(r"[.;\n]+", text)
    patterns = ["->", "→", " depinde ", "because", "deoarece", "cauza", "leag", "rela", "duce"]
    for phrase in phrases:
        p = phrase.strip()
        if len(p) < 12:
            continue
        low = p.lower()
        if any(x in low for x in patterns):
            hints.append(p[:140])
        if len(hints) >= max_hints:
            break
    if not hints:
        toks = tokenize(text)[:8]
        if len(toks) >= 2:
            hints.append("related: " + " -> ".join(toks[:5]))
    return hints[:max_hints]


def detect_tone(text: str) -> str:
    toks = set(tokenize(text))
    pos = len(toks & POSITIVE)
    neg = len(toks & NEGATIVE)
    if pos > neg:
        return "positive/constructive"
    if neg > pos:
        return "risk/critical"
    return "neutral"


def cosine_like(a: Dict[str, float], b: Dict[str, float]) -> float:
    if not a or not b:
        return 0.0
    keys = set(a) | set(b)
    dot = sum(a.get(k, 0.0) * b.get(k, 0.0) for k in keys)
    na = math.sqrt(sum(v * v for v in a.values()))
    nb = math.sqrt(sum(v * v for v in b.values()))
    if na <= 0 or nb <= 0:
        return 0.0
    return max(0.0, min(1.0, dot / (na * nb)))


def redundancy_score(text: str, other_texts: Sequence[str]) -> float:
    cw = concept_weights(text, max_terms=24)
    if not cw or not other_texts:
        return 0.0
    best = 0.0
    for other in other_texts:
        if other == text:
            continue
        best = max(best, cosine_like(cw, concept_weights(other, max_terms=24)))
    return round(best, 6)


def temporal_decay(created_at: float, half_life_seconds: float = 3600.0) -> float:
    age = max(0.0, now() - created_at)
    return round(1.0 - math.exp(-age / max(1.0, half_life_seconds)), 6)


def make_summary_hint(text: str, concepts: Iterable[str], max_chars: int = 180) -> str:
    concept_text = ", ".join(list(concepts)[:8])
    first_sentence = re.split(r"[.\n]", text.strip())[0][:max_chars]
    if concept_text:
        return f"concepts={concept_text}; seed={first_sentence}"[:max_chars]
    return first_sentence[:max_chars]
