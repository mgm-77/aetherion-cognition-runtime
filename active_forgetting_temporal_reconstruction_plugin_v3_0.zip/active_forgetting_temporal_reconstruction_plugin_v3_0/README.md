# Active Forgetting & Temporal Reconstruction Plugin v3.0

**Autonomous Active Forgetting & Reconstruction Runtime** pentru Cache OS / Cognitive Runtime.

Ideea: sistemul nu ține tot și nu aruncă orb. El transformă memoria activă cu utilitate scăzută în **schelete latente compacte**, păstrează ce a uitat, reconstruiește aproximativ când un concept revine și poate promova automat înapoi în memoria activă.

## Ce adaugă V3 peste V2

- Canary forgetting
- Closed-loop maintenance
- Regret tracking
- Reconstruction confidence guard
- Temporal skeleton graph
- Auto-reactivation din query signals
- Rollback token pentru planuri de uitare
- Policy bundle pentru integrare cu Semantic Indexing / Context Windowing / Invalidation / Predictive Preloading / KV Cache
- Tamper-evident audit ledger
- Zero dependențe externe

## Limită corectă

Reconstrucția este **aproximativă**, nu restore exact din backup, dacă `allow_exact_content_in_skeleton=False`.
Modulul reconstruiește din concepte, ponderi, relații și ancore temporale.

## Testare

```bash
PYTHONPATH=. python -m unittest discover -s tests -v
PYTHONPATH=. python examples/demo_active_forgetting_temporal_reconstruction_v3.py
```

## API rapid

```python
from active_forgetting_temporal_reconstruction import ActiveForgettingTemporalReconstructionModule

memory = ActiveForgettingTemporalReconstructionModule()
memory.add_block("b1", "KV cache reuse improves long-context latency.", ["kv", "cache"], importance=0.4)

plan = memory.build_forget_plan()
result = memory.apply_forget_plan(plan)

hits = memory.latent_search("kv cache")
reconstruction = memory.reconstruct(query="kv cache")
```
