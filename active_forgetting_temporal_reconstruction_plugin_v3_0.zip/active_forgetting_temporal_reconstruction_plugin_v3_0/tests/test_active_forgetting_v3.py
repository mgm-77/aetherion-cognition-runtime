import unittest
from active_forgetting_temporal_reconstruction import (
    ActiveForgettingTemporalReconstructionModule,
    ForgetPolicy,
    ReconstructionResult,
)


def seeded_module():
    m = ActiveForgettingTemporalReconstructionModule(
        ForgetPolicy(
            stale_after_seconds=0.001,
            min_confidence_for_reconstruction=0.20,
            auto_promote_relevance=0.20,
            target_active_reduction_ratio=0.50,
        )
    )
    m.add_block("b1", "KV cache memory stores key value pages for long context runtime", ["kv", "cache", "memory"], 0.4)
    m.add_block("b2", "Semantic indexing links concepts entities and relations for retrieval", ["semantic", "indexing", "retrieval"], 0.45)
    m.add_block("b3", "Critical safety policy must remain active and pinned", ["safety", "policy"], 0.99, pinned=True)
    m.add_block("b4", "KV cache reuse can reduce repeated attention lookup latency", ["kv", "cache", "latency"], 0.35)
    return m


class TestActiveForgettingV3(unittest.TestCase):
    def test_add_and_report(self):
        m = seeded_module()
        report = m.self_awareness_report()
        self.assertEqual(report["active_blocks"], 4)
        self.assertTrue(report["ledger_ok"])

    def test_build_forget_plan_protects_critical(self):
        m = seeded_module()
        plan = m.build_forget_plan()
        ids = {x["block_id"] for x in plan["selected"]}
        self.assertNotIn("b3", ids)
        self.assertTrue(plan["safe_to_apply"])

    def test_apply_forget_plan_moves_to_latent(self):
        m = seeded_module()
        plan = m.build_forget_plan()
        res = m.apply_forget_plan(plan)
        self.assertTrue(res["ok"])
        self.assertGreaterEqual(len(m.latent), 1)
        for bid in res["forgotten"]:
            self.assertNotIn(bid, m.active)

    def test_reconstruct_by_id(self):
        m = seeded_module()
        res = m.forget()
        bid = res["forgotten"][0]
        out = m.reconstruct(block_id=bid)
        self.assertIsInstance(out, ReconstructionResult)
        self.assertIsInstance(out.reconstructed_text, str)
        self.assertGreaterEqual(out.confidence, 0.0)

    def test_latent_search(self):
        m = seeded_module()
        m.forget()
        hits = m.latent_search("cache latency kv")
        self.assertTrue(len(hits) >= 1)
        self.assertIn("score", hits[0])

    def test_promote_reconstructed(self):
        m = seeded_module()
        res = m.forget()
        bid = res["forgotten"][0]
        r = m.reconstruct(block_id=bid)
        block = m.promote(bid, r.reconstructed_text, r.confidence)
        self.assertIsNotNone(block)
        self.assertIn(bid, m.active)
        self.assertNotIn(bid, m.latent)

    def test_checkpoint_rollback(self):
        m = seeded_module()
        plan = m.build_forget_plan()
        token = m.create_checkpoint("test")
        m.apply_forget_plan(plan, checkpoint_token=token)
        self.assertGreater(len(m.latent), 0)
        ok = m.rollback(token)
        self.assertTrue(ok)
        self.assertEqual(len(m.latent), 0)
        self.assertEqual(len(m.active), 4)

    def test_canary_forget(self):
        m = seeded_module()
        plan = m.build_forget_plan()
        res = m.canary_forget(plan)
        self.assertIn("ok", res)
        self.assertIn("rollback_token", res)

    def test_closed_loop_maintenance(self):
        m = seeded_module()
        result = m.closed_loop_maintenance(apply=True, query_signals=["semantic retrieval"])
        self.assertIn("plan", result)
        self.assertIn("reactivated", result)

    def test_feedback_regret(self):
        m = seeded_module()
        m.record_feedback("b1", useful=False, reason="needed immediately")
        self.assertGreater(len(m.regret_log), 0)
        stats = m.feedback_stats["b1"]
        self.assertGreater(stats["regret"], 0)

    def test_snapshot_restore(self):
        m = seeded_module()
        m.forget()
        snap = m.snapshot()
        n = ActiveForgettingTemporalReconstructionModule()
        n.restore(snap)
        self.assertEqual(len(n.active), len(m.active))
        self.assertEqual(len(n.latent), len(m.latent))

    def test_policy_bundle(self):
        m = seeded_module()
        bundle = m.compile_policy_bundle()
        self.assertIn("active_forgetting", bundle["capabilities"])
        self.assertIn("semantic_indexing", bundle["recommended_integrations"])

    def test_ledger_verify(self):
        m = seeded_module()
        m.forget()
        self.assertTrue(m.ledger.verify())

    def test_access_latent_promotes_when_relevant(self):
        m = seeded_module()
        res = m.forget()
        bid = res["forgotten"][0]
        obj = m.access(bid)
        # Depending confidence, access may promote. It must not crash.
        self.assertTrue(obj is None or obj.block_id == bid)

    def test_memory_reduction_ratio_non_negative(self):
        m = seeded_module()
        m.forget()
        self.assertGreaterEqual(m.memory_reduction_ratio(), 0.0)


if __name__ == "__main__":
    unittest.main()
