from active_forgetting_temporal_reconstruction import (
    ActiveForgettingTemporalReconstructionModule,
    ForgetPolicy,
)

def main():
    memory = ActiveForgettingTemporalReconstructionModule(
        ForgetPolicy(
            stale_after_seconds=0.001,
            min_confidence_for_reconstruction=0.20,
            auto_promote_relevance=0.20,
            target_active_reduction_ratio=0.60,
        )
    )

    memory.add_block(
        "kv-runtime-001",
        "KV cache memory stores key value pages and allows paged attention reuse for long context inference.",
        ["kv", "cache", "paged_attention", "runtime"],
        importance=0.42,
    )
    memory.add_block(
        "semantic-index-001",
        "Semantic indexing keeps concepts, entities and relations searchable beyond literal token matching.",
        ["semantic", "indexing", "concepts", "relations"],
        importance=0.55,
    )
    memory.add_block(
        "critical-goal",
        "Critical goal: build Cache OS for LLM runtime memory without flattening semantic layers.",
        ["goal", "cache_os", "llm_runtime"],
        importance=0.98,
        pinned=True,
    )
    memory.add_block(
        "redundant-kv-note",
        "KV cache reuse reduces repeated attention lookups and improves latency for recurring context.",
        ["kv", "cache", "latency"],
        importance=0.35,
    )

    print("=== BEFORE ===")
    print(memory.self_awareness_report())

    plan = memory.build_forget_plan()
    print("\n=== FORGET PLAN ===")
    print({
        "selected": [x["block_id"] for x in plan["selected"]],
        "expected_reduction": plan["expected_active_reduction_ratio"],
        "safe_to_apply": plan["safe_to_apply"],
    })

    result = memory.closed_loop_maintenance(apply=True, query_signals=["semantic relations retrieval"])
    print("\n=== CLOSED LOOP RESULT ===")
    print(result)

    print("\n=== LATENT SEARCH ===")
    print(memory.latent_search("kv cache latency", top_k=3))

    if memory.latent:
        bid = next(iter(memory.latent))
        reconstruction = memory.reconstruct(block_id=bid)
        print("\n=== RECONSTRUCTION ===")
        print(reconstruction.to_dict())

    print("\n=== POLICY BUNDLE ===")
    print(memory.compile_policy_bundle())

    print("\n=== FINAL SELF-AWARENESS ===")
    print(memory.self_awareness_report())

if __name__ == "__main__":
    main()
