from __future__ import annotations

import copy
import hashlib
import json
import math
import re
import time
import zlib
from dataclasses import dataclass, field, asdict
from typing import Any, Callable, Dict, Iterable, List, Optional, Tuple


WORD_RE = re.compile(r"[A-Za-zÀ-ÿ0-9_]{3,}")


def _now() -> float:
    return time.time()


def _tokenize(text: str) -> List[str]:
    return [w.lower() for w in WORD_RE.findall(text or "")]


def _stable_hash(value: Any) -> str:
    raw = json.dumps(value, sort_keys=True, ensure_ascii=False, default=str).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _cosine_like(a: Dict[str, float], b: Dict[str, float]) -> float:
    if not a or not b:
        return 0.0
    inter = set(a).intersection(b)
    dot = sum(a[k] * b[k] for k in inter)
    na = math.sqrt(sum(v * v for v in a.values()))
    nb = math.sqrt(sum(v * v for v in b.values()))
    if na == 0 or nb == 0:
        return 0.0
    return dot / (na * nb)


def _term_weights(tokens: Iterable[str]) -> Dict[str, float]:
    weights: Dict[str, float] = {}
    for t in tokens:
        if len(t) < 3:
            continue
        weights[t] = weights.get(t, 0.0) + 1.0
    total = sum(weights.values()) or 1.0
    return {k: round(v / total, 6) for k, v in weights.items()}


def _estimate_size(value: Any) -> int:
    if isinstance(value, bytes):
        return len(value)
    return len(json.dumps(value, ensure_ascii=False, default=str).encode("utf-8"))


@dataclass
class MemoryBlock:
    block_id: str
    content: str
    concepts: List[str] = field(default_factory=list)
    importance: float = 0.5
    created_at: float = field(default_factory=_now)
    last_accessed_at: float = field(default_factory=_now)
    access_count: int = 0
    pinned: bool = False
    source: str = "runtime"
    metadata: Dict[str, Any] = field(default_factory=dict)

    def touch(self) -> None:
        self.access_count += 1
        self.last_accessed_at = _now()

    @property
    def size_bytes(self) -> int:
        return _estimate_size(asdict(self))


@dataclass
class ForgetPolicy:
    target_active_reduction_ratio: float = 0.50
    min_confidence_for_reconstruction: float = 0.45
    max_canary_fraction: float = 0.25
    protect_importance_above: float = 0.90
    regret_reactivation_boost: float = 0.20
    stale_after_seconds: float = 60.0
    redundancy_threshold: float = 0.55
    compression_target_ratio: float = 0.02
    auto_promote_relevance: float = 0.50
    allow_exact_content_in_skeleton: bool = False


@dataclass
class ReconstructionResult:
    ok: bool
    block_id: Optional[str]
    reconstructed_text: str
    confidence: float
    source: str
    concepts: List[str] = field(default_factory=list)
    evidence: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class AuditLedger:
    def __init__(self) -> None:
        self.events: List[Dict[str, Any]] = []
        self._last_hash = "0" * 64

    def append(self, event: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        rec = {
            "ts": _now(),
            "event": event,
            "payload": copy.deepcopy(payload),
            "prev_hash": self._last_hash,
        }
        rec["hash"] = _stable_hash(rec)
        self._last_hash = rec["hash"]
        self.events.append(rec)
        return rec

    def verify(self) -> bool:
        prev = "0" * 64
        for rec in self.events:
            clone = {k: copy.deepcopy(v) for k, v in rec.items() if k != "hash"}
            if clone.get("prev_hash") != prev:
                return False
            if _stable_hash(clone) != rec.get("hash"):
                return False
            prev = rec.get("hash", "")
        return True


class ActiveForgettingTemporalReconstructionModuleV3:
    """
    Autonomous active-forgetting runtime.

    Key idea:
    - Active memory keeps valuable blocks.
    - Low-utility/redundant blocks are converted to latent skeletons.
    - Skeletons store concept weights, relation hints, temporal anchors, and a tiny
      compressed sketch. They are not exact backups.
    - Reconstruction is approximate, confidence-scored, guarded, and can auto-promote.
    """

    version = "3.0.0"

    def __init__(self, policy: Optional[ForgetPolicy] = None) -> None:
        self.policy = policy or ForgetPolicy()
        self.active: Dict[str, MemoryBlock] = {}
        self.latent: Dict[str, Dict[str, Any]] = {}
        self.temporal_edges: Dict[str, List[str]] = {}
        self.regret_log: List[Dict[str, Any]] = []
        self.feedback_stats: Dict[str, Dict[str, float]] = {}
        self.reconstruction_history: List[Dict[str, Any]] = []
        self._snapshots: Dict[str, Dict[str, Any]] = {}
        self.ledger = AuditLedger()
        self.runtime = None
        self.hooks: Dict[str, Callable[..., Any]] = {}

    # ----- lifecycle / hooks -----

    def attach(self, runtime: Any = None) -> "ActiveForgettingTemporalReconstructionModuleV3":
        self.runtime = runtime
        if runtime is not None and hasattr(runtime, "register"):
            runtime.register("memory.forget.plan", self.build_forget_plan)
            runtime.register("memory.forget.apply", self.apply_forget_plan)
            runtime.register("memory.reconstruct", self.reconstruct)
            runtime.register("memory.maintenance", self.closed_loop_maintenance)
        self.ledger.append("attach", {"runtime_attached": runtime is not None})
        return self

    def detach(self) -> None:
        self.ledger.append("detach", {"active": len(self.active), "latent": len(self.latent)})
        self.runtime = None

    # ----- active memory operations -----

    def add_block(
        self,
        block_id: str,
        content: str,
        concepts: Optional[List[str]] = None,
        importance: float = 0.5,
        pinned: bool = False,
        source: str = "runtime",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> MemoryBlock:
        concepts = concepts or self._extract_concepts(content)
        block = MemoryBlock(
            block_id=block_id,
            content=content,
            concepts=list(dict.fromkeys([c.lower() for c in concepts])),
            importance=float(max(0.0, min(1.0, importance))),
            pinned=bool(pinned),
            source=source,
            metadata=metadata or {},
        )
        self.active[block_id] = block
        self._update_temporal_edges(block_id)
        self.ledger.append("add_block", {"block_id": block_id, "size": block.size_bytes})
        return block

    def access(self, block_id: str) -> Optional[MemoryBlock]:
        block = self.active.get(block_id)
        if block:
            block.touch()
            self.ledger.append("access_active", {"block_id": block_id, "access_count": block.access_count})
            return block
        if block_id in self.latent:
            result = self.reconstruct(block_id=block_id)
            if result.ok and result.confidence >= self.policy.auto_promote_relevance:
                promoted = self.promote(block_id, result.reconstructed_text, result.confidence)
                return promoted
        return None

    # ----- scoring / plan -----

    def build_forget_plan(
        self,
        max_active_bytes: Optional[int] = None,
        target_reduction_ratio: Optional[float] = None,
        now: Optional[float] = None,
        dry_run: bool = True,
    ) -> Dict[str, Any]:
        now = now or _now()
        target_reduction_ratio = (
            self.policy.target_active_reduction_ratio
            if target_reduction_ratio is None
            else target_reduction_ratio
        )
        current_bytes = self.active_size_bytes()
        if max_active_bytes is not None and current_bytes <= max_active_bytes:
            target_bytes_to_forget = 0
        else:
            target_bytes_to_forget = int(current_bytes * max(0.0, min(0.95, target_reduction_ratio)))
            if max_active_bytes is not None:
                target_bytes_to_forget = max(target_bytes_to_forget, current_bytes - max_active_bytes)

        scored = []
        for block in self.active.values():
            score, factors = self._forget_score(block, now)
            if block.pinned or block.importance >= self.policy.protect_importance_above:
                score = -1.0
                factors["protected"] = 1.0
            scored.append({
                "block_id": block.block_id,
                "score": round(score, 6),
                "size_bytes": block.size_bytes,
                "importance": block.importance,
                "concepts": block.concepts[:8],
                "factors": factors,
            })

        scored.sort(key=lambda x: (x["score"], x["size_bytes"]), reverse=True)
        selected = []
        bytes_selected = 0
        for cand in scored:
            if cand["score"] <= 0 or bytes_selected >= target_bytes_to_forget:
                continue
            selected.append(cand)
            bytes_selected += int(cand["size_bytes"])

        plan = {
            "version": self.version,
            "dry_run": dry_run,
            "current_active_bytes": current_bytes,
            "target_bytes_to_forget": target_bytes_to_forget,
            "selected_bytes": bytes_selected,
            "selected": selected,
            "candidates": scored,
            "expected_active_reduction_ratio": round(bytes_selected / max(1, current_bytes), 6),
            "canary_count": max(1, int(len(selected) * self.policy.max_canary_fraction)) if selected else 0,
            "safe_to_apply": bool(selected),
            "warnings": [] if selected else ["no eligible forget candidates"],
        }
        self.ledger.append("build_forget_plan", {"selected": len(selected), "bytes": bytes_selected})
        return plan

    def _forget_score(self, block: MemoryBlock, now: float) -> Tuple[float, Dict[str, float]]:
        age = max(0.0, now - block.created_at)
        idle = max(0.0, now - block.last_accessed_at)
        recency_penalty = min(1.0, idle / max(1.0, self.policy.stale_after_seconds))
        low_access = 1.0 / (1.0 + block.access_count)
        low_importance = 1.0 - block.importance
        redundancy = self._redundancy_score(block)
        regret_penalty = self._regret_penalty(block)
        score = (
            0.30 * recency_penalty
            + 0.25 * low_access
            + 0.25 * low_importance
            + 0.20 * redundancy
            - regret_penalty
        )
        factors = {
            "recency_penalty": round(recency_penalty, 6),
            "low_access": round(low_access, 6),
            "low_importance": round(low_importance, 6),
            "redundancy": round(redundancy, 6),
            "regret_penalty": round(regret_penalty, 6),
            "age_seconds": round(age, 3),
        }
        return max(0.0, score), factors

    def _redundancy_score(self, block: MemoryBlock) -> float:
        if len(self.active) <= 1:
            return 0.0
        bw = _term_weights(block.concepts or _tokenize(block.content))
        best = 0.0
        for other in self.active.values():
            if other.block_id == block.block_id:
                continue
            ow = _term_weights(other.concepts or _tokenize(other.content))
            best = max(best, _cosine_like(bw, ow))
        return best

    def _regret_penalty(self, block: MemoryBlock) -> float:
        stats = self.feedback_stats.get(block.block_id, {})
        regret = stats.get("regret", 0.0)
        return min(0.4, regret * self.policy.regret_reactivation_boost)

    # ----- forget / latent skeleton -----

    def create_checkpoint(self, label: str = "checkpoint") -> str:
        token = f"{label}:{_stable_hash({'t': _now(), 'n': len(self._snapshots)})[:12]}"
        self._snapshots[token] = self.snapshot(include_ledger=False)
        self.ledger.append("checkpoint", {"token": token})
        return token

    def rollback(self, token: str) -> bool:
        snap = self._snapshots.get(token)
        if not snap:
            self.ledger.append("rollback_failed", {"token": token})
            return False
        self.restore(snap, restore_ledger=False)
        self.ledger.append("rollback", {"token": token})
        return True

    def apply_forget_plan(
        self,
        plan: Dict[str, Any],
        mode: str = "staged",
        checkpoint_token: Optional[str] = None,
    ) -> Dict[str, Any]:
        if not plan.get("safe_to_apply"):
            return {"ok": False, "reason": "plan_not_safe", "forgotten": []}
        token = checkpoint_token or self.create_checkpoint("forget")
        selected = list(plan.get("selected", []))
        if mode == "canary":
            selected = selected[: max(1, int(plan.get("canary_count") or 1))]
        forgotten = []
        for cand in selected:
            block_id = cand["block_id"]
            block = self.active.get(block_id)
            if not block:
                continue
            skeleton = self._to_skeleton(block)
            self.latent[block_id] = skeleton
            del self.active[block_id]
            forgotten.append(block_id)
        result = {
            "ok": True,
            "mode": mode,
            "rollback_token": token,
            "forgotten": forgotten,
            "latent_count": len(self.latent),
            "active_count": len(self.active),
        }
        self.ledger.append("apply_forget_plan", result)
        return result

    def forget(
        self,
        max_active_bytes: Optional[int] = None,
        target_reduction_ratio: Optional[float] = None,
        mode: str = "staged",
    ) -> Dict[str, Any]:
        plan = self.build_forget_plan(max_active_bytes, target_reduction_ratio, dry_run=False)
        return self.apply_forget_plan(plan, mode=mode)

    def _to_skeleton(self, block: MemoryBlock) -> Dict[str, Any]:
        tokens = _tokenize(block.content)
        weights = _term_weights(tokens + block.concepts)
        concepts = sorted(weights, key=weights.get, reverse=True)[:12]
        relations = self._extract_relations(block.content, concepts)
        # Tiny approximate sketch. By default, avoid storing full exact content.
        if self.policy.allow_exact_content_in_skeleton:
            sketch = zlib.compress(block.content.encode("utf-8"))
            sketch_mode = "compressed_exact"
        else:
            sketch_text = " ".join(concepts[:8])
            sketch = zlib.compress(sketch_text.encode("utf-8"))
            sketch_mode = "semantic_skeleton"
        original_size = block.size_bytes
        latent_size = len(sketch) + _estimate_size(weights) + _estimate_size(relations)
        target = max(1, int(original_size * self.policy.compression_target_ratio))
        return {
            "block_id": block.block_id,
            "concept_weights": weights,
            "concepts": concepts,
            "relations": relations,
            "temporal_anchor": {
                "created_at": block.created_at,
                "last_accessed_at": block.last_accessed_at,
                "source": block.source,
            },
            "importance": block.importance,
            "access_count": block.access_count,
            "metadata": copy.deepcopy(block.metadata),
            "sketch": sketch.hex(),
            "sketch_mode": sketch_mode,
            "original_size_bytes": original_size,
            "latent_size_bytes": latent_size,
            "target_latent_size_bytes": target,
            "compression_ratio": round(latent_size / max(1, original_size), 6),
            "skeleton_hash": _stable_hash({"id": block.block_id, "weights": weights, "relations": relations}),
        }

    def _extract_relations(self, text: str, concepts: List[str]) -> List[Dict[str, Any]]:
        lowered = text.lower()
        relations = []
        for i, a in enumerate(concepts[:8]):
            for b in concepts[i + 1 : i + 8]:
                dist = abs(lowered.find(a) - lowered.find(b)) if a in lowered and b in lowered else 999999
                if dist < 120:
                    relations.append({"from": a, "to": b, "type": "co_occurs_near", "strength": round(1.0 - dist / 120.0, 4)})
        return relations[:20]

    # ----- reconstruction / promotion / learning -----

    def latent_search(self, query: str, top_k: int = 5) -> List[Dict[str, Any]]:
        qweights = _term_weights(_tokenize(query))
        hits = []
        for bid, skel in self.latent.items():
            score = _cosine_like(qweights, skel.get("concept_weights", {}))
            # Direct concept overlap boost.
            qset = set(qweights)
            overlap = len(qset.intersection(skel.get("concepts", []))) / max(1, len(qset))
            final = 0.75 * score + 0.25 * overlap
            hits.append({
                "block_id": bid,
                "score": round(final, 6),
                "concepts": skel.get("concepts", [])[:8],
                "compression_ratio": skel.get("compression_ratio", 0.0),
            })
        hits.sort(key=lambda x: x["score"], reverse=True)
        self.ledger.append("latent_search", {"query_hash": _stable_hash(query)[:12], "hits": len(hits[:top_k])})
        return hits[:top_k]

    def reconstruct(self, block_id: Optional[str] = None, query: Optional[str] = None) -> ReconstructionResult:
        if block_id is None:
            hits = self.latent_search(query or "", top_k=1)
            if not hits:
                return ReconstructionResult(False, None, "", 0.0, "latent", warnings=["no latent match"])
            block_id = hits[0]["block_id"]
        skel = self.latent.get(block_id)
        if not skel:
            return ReconstructionResult(False, block_id, "", 0.0, "latent", warnings=["skeleton_not_found"])

        concepts = skel.get("concepts", [])
        relations = skel.get("relations", [])
        confidence = self._reconstruction_confidence(skel, query)
        evidence = [
            f"concepts={','.join(concepts[:6])}",
            f"relations={len(relations)}",
            f"compression_ratio={skel.get('compression_ratio')}",
        ]
        if skel.get("sketch_mode") == "compressed_exact":
            try:
                text = zlib.decompress(bytes.fromhex(skel["sketch"])).decode("utf-8")
                source = "compressed_exact"
                confidence = max(confidence, 0.95)
            except Exception:
                text = self._generate_approximation(skel)
                source = "reconstructed_from_skeleton"
                confidence = min(confidence, 0.65)
        else:
            text = self._generate_approximation(skel)
            source = "reconstructed_from_skeleton"
        warnings = []
        if confidence < self.policy.min_confidence_for_reconstruction:
            warnings.append("low_confidence_reconstruction")
        result = ReconstructionResult(
            ok=confidence >= self.policy.min_confidence_for_reconstruction,
            block_id=block_id,
            reconstructed_text=text,
            confidence=round(confidence, 6),
            source=source,
            concepts=concepts,
            evidence=evidence,
            warnings=warnings,
        )
        self.reconstruction_history.append(result.to_dict())
        self.ledger.append("reconstruct", {"block_id": block_id, "confidence": result.confidence, "ok": result.ok})
        return result

    def _generate_approximation(self, skel: Dict[str, Any]) -> str:
        concepts = skel.get("concepts", [])
        relations = skel.get("relations", [])
        source = skel.get("temporal_anchor", {}).get("source", "runtime")
        if not concepts:
            return f"Approximate forgotten block from {source}: no strong concepts preserved."
        relation_bits = []
        for r in relations[:4]:
            relation_bits.append(f"{r.get('from')}↔{r.get('to')}")
        rel_text = "; relations: " + ", ".join(relation_bits) if relation_bits else ""
        return (
            f"Approximate reconstruction from latent skeleton. "
            f"Core concepts: {', '.join(concepts[:8])}{rel_text}. "
            f"Source layer: {source}. Details are approximate, not exact restore."
        )

    def _reconstruction_confidence(self, skel: Dict[str, Any], query: Optional[str]) -> float:
        concept_strength = sum(sorted(skel.get("concept_weights", {}).values(), reverse=True)[:5])
        concept_strength = min(1.0, concept_strength * 2.0)
        relation_strength = min(1.0, len(skel.get("relations", [])) / 8.0)
        compression_penalty = min(0.35, float(skel.get("compression_ratio", 0.0)) * 2.0)
        query_match = 0.5
        if query:
            qweights = _term_weights(_tokenize(query))
            query_match = _cosine_like(qweights, skel.get("concept_weights", {}))
        confidence = 0.35 * concept_strength + 0.25 * relation_strength + 0.30 * query_match + 0.10 * skel.get("importance", 0.5)
        confidence = max(0.0, min(1.0, confidence - compression_penalty * 0.15))
        return confidence

    def promote(self, block_id: str, reconstructed_text: Optional[str] = None, confidence: float = 0.5) -> Optional[MemoryBlock]:
        skel = self.latent.get(block_id)
        if not skel:
            return None
        text = reconstructed_text or self.reconstruct(block_id=block_id).reconstructed_text
        block = self.add_block(
            block_id=block_id,
            content=text,
            concepts=skel.get("concepts", []),
            importance=min(1.0, skel.get("importance", 0.5) + confidence * 0.2),
            pinned=False,
            source="reactivated_latent",
            metadata={"reactivated": True, "reconstruction_confidence": confidence},
        )
        del self.latent[block_id]
        self.ledger.append("promote", {"block_id": block_id, "confidence": confidence})
        return block

    def record_feedback(self, block_id: str, useful: bool, reason: str = "") -> None:
        stats = self.feedback_stats.setdefault(block_id, {"positive": 0.0, "negative": 0.0, "regret": 0.0})
        if useful:
            stats["positive"] += 1.0
            stats["regret"] = max(0.0, stats["regret"] - 0.25)
        else:
            stats["negative"] += 1.0
            stats["regret"] += 1.0
            self.regret_log.append({"ts": _now(), "block_id": block_id, "reason": reason})
        self.ledger.append("feedback", {"block_id": block_id, "useful": useful, "reason": reason})

    # ----- V3 autonomous cycle -----

    def canary_forget(self, plan: Dict[str, Any]) -> Dict[str, Any]:
        token = self.create_checkpoint("canary")
        applied = self.apply_forget_plan(plan, mode="canary", checkpoint_token=token)
        evaluation = self.evaluate_forget_outcome(applied)
        if not evaluation["safe"]:
            self.rollback(token)
            return {"ok": False, "rolled_back": True, "evaluation": evaluation, "rollback_token": token}
        return {"ok": True, "rolled_back": False, "evaluation": evaluation, "rollback_token": token, "applied": applied}

    def evaluate_forget_outcome(self, applied: Dict[str, Any]) -> Dict[str, Any]:
        forgotten = applied.get("forgotten", [])
        if not forgotten:
            return {"safe": False, "reason": "nothing_forgotten"}
        confidences = []
        for bid in forgotten:
            res = self.reconstruct(block_id=bid)
            confidences.append(res.confidence)
        avg = sum(confidences) / max(1, len(confidences))
        return {
            "safe": avg >= self.policy.min_confidence_for_reconstruction,
            "avg_reconstruction_confidence": round(avg, 6),
            "forgotten": forgotten,
        }

    def closed_loop_maintenance(
        self,
        max_active_bytes: Optional[int] = None,
        query_signals: Optional[List[str]] = None,
        apply: bool = True,
    ) -> Dict[str, Any]:
        plan = self.build_forget_plan(max_active_bytes=max_active_bytes, dry_run=not apply)
        result: Dict[str, Any] = {"plan": plan, "applied": None, "reactivated": []}
        if apply and plan.get("safe_to_apply"):
            canary = self.canary_forget(plan)
            result["canary"] = canary
            if canary.get("ok"):
                # Apply remaining staged plan after canary succeeds.
                remaining = copy.deepcopy(plan)
                canary_ids = set((canary.get("applied") or {}).get("forgotten", []))
                remaining["selected"] = [c for c in plan.get("selected", []) if c["block_id"] not in canary_ids]
                if remaining["selected"]:
                    result["applied"] = self.apply_forget_plan(remaining, mode="staged")
        for q in query_signals or []:
            hits = self.latent_search(q, top_k=3)
            for hit in hits:
                if hit["score"] >= self.policy.auto_promote_relevance:
                    res = self.reconstruct(block_id=hit["block_id"], query=q)
                    if res.ok:
                        promoted = self.promote(hit["block_id"], res.reconstructed_text, res.confidence)
                        if promoted:
                            result["reactivated"].append(promoted.block_id)
        self.ledger.append("closed_loop_maintenance", {
            "selected": len(plan.get("selected", [])),
            "reactivated": len(result["reactivated"]),
        })
        return result

    def self_awareness_report(self) -> Dict[str, Any]:
        reconstructable = 0
        low_conf = 0
        for bid in self.latent:
            res = self.reconstruct(block_id=bid)
            if res.ok:
                reconstructable += 1
            else:
                low_conf += 1
        report = {
            "version": self.version,
            "active_blocks": len(self.active),
            "latent_skeletons": len(self.latent),
            "active_size_bytes": self.active_size_bytes(),
            "latent_size_bytes": self.latent_size_bytes(),
            "estimated_memory_reduction_ratio": self.memory_reduction_ratio(),
            "reconstructable_skeletons": reconstructable,
            "low_confidence_skeletons": low_conf,
            "regret_events": len(self.regret_log),
            "ledger_ok": self.ledger.verify(),
            "knows_what_it_forgot": sorted(self.latent.keys()),
            "policy": asdict(self.policy),
        }
        self.ledger.append("self_awareness_report", {
            "active": report["active_blocks"],
            "latent": report["latent_skeletons"],
            "reduction": report["estimated_memory_reduction_ratio"],
        })
        return report

    def compile_policy_bundle(self) -> Dict[str, Any]:
        return {
            "module": "active_forgetting_temporal_reconstruction",
            "version": self.version,
            "capabilities": [
                "active_forgetting",
                "latent_skeleton_graph",
                "temporal_reconstruction",
                "canary_forgetting",
                "rollback",
                "regret_tracking",
                "auto_reactivation",
            ],
            "recommended_integrations": {
                "semantic_indexing": "use concept weights as semantic graph nodes",
                "context_windowing": "query latent skeletons before expanding active context",
                "invalidation_strategy": "prefer skeletonize over hard delete when semantic utility remains",
                "predictive_preloading": "reactivate latent skeletons before likely topic return",
                "kv_cache": "use active/latent state to decide KV page demotion",
            },
            "safety": {
                "exact_restore": self.policy.allow_exact_content_in_skeleton,
                "reconstruction_is_approximate": not self.policy.allow_exact_content_in_skeleton,
                "min_confidence": self.policy.min_confidence_for_reconstruction,
            },
        }

    # ----- misc helpers -----

    def _extract_concepts(self, content: str) -> List[str]:
        tokens = _tokenize(content)
        weights = _term_weights(tokens)
        return sorted(weights, key=weights.get, reverse=True)[:10]

    def _update_temporal_edges(self, block_id: str) -> None:
        ids = list(self.active.keys())
        if len(ids) >= 2:
            prev = ids[-2]
            self.temporal_edges.setdefault(prev, []).append(block_id)

    def active_size_bytes(self) -> int:
        return sum(b.size_bytes for b in self.active.values())

    def latent_size_bytes(self) -> int:
        return sum(int(s.get("latent_size_bytes", 0)) for s in self.latent.values())

    def memory_reduction_ratio(self) -> float:
        original_latent = sum(int(s.get("original_size_bytes", 0)) for s in self.latent.values())
        if original_latent <= 0:
            return 0.0
        saved = max(0, original_latent - self.latent_size_bytes())
        return round(saved / max(1, original_latent), 6)

    def snapshot(self, include_ledger: bool = True) -> Dict[str, Any]:
        return {
            "version": self.version,
            "policy": asdict(self.policy),
            "active": {k: asdict(v) for k, v in self.active.items()},
            "latent": copy.deepcopy(self.latent),
            "temporal_edges": copy.deepcopy(self.temporal_edges),
            "regret_log": copy.deepcopy(self.regret_log),
            "feedback_stats": copy.deepcopy(self.feedback_stats),
            "reconstruction_history": copy.deepcopy(self.reconstruction_history),
            "ledger": copy.deepcopy(self.ledger.events) if include_ledger else [],
        }

    def restore(self, snapshot: Dict[str, Any], restore_ledger: bool = True) -> None:
        self.policy = ForgetPolicy(**snapshot.get("policy", {}))
        self.active = {
            k: MemoryBlock(**v)
            for k, v in snapshot.get("active", {}).items()
        }
        self.latent = copy.deepcopy(snapshot.get("latent", {}))
        self.temporal_edges = copy.deepcopy(snapshot.get("temporal_edges", {}))
        self.regret_log = copy.deepcopy(snapshot.get("regret_log", []))
        self.feedback_stats = copy.deepcopy(snapshot.get("feedback_stats", {}))
        self.reconstruction_history = copy.deepcopy(snapshot.get("reconstruction_history", []))
        if restore_ledger:
            self.ledger.events = copy.deepcopy(snapshot.get("ledger", []))
            self.ledger._last_hash = self.ledger.events[-1]["hash"] if self.ledger.events else "0" * 64


# Backward-friendly alias.
ActiveForgettingTemporalReconstructionModule = ActiveForgettingTemporalReconstructionModuleV3
