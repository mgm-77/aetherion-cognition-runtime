"""
Active Forgetting & Temporal Reconstruction Plugin V3.0

Autonomous Active Forgetting & Reconstruction Runtime.

This is a stdlib-only control-plane module for cognitive/runtime memory systems.
It actively compresses low-utility memory blocks into latent skeletons, tracks what
was forgotten, reconstructs approximate details when needed, learns from regret,
and can promote forgotten concepts back into active memory.

It does not claim exact restore unless an external exact store is attached.
Reconstruction is approximate and explainable.
"""
from .module import (
    ActiveForgettingTemporalReconstructionModule,
    ActiveForgettingTemporalReconstructionModuleV3,
    MemoryBlock,
    ForgetPolicy,
    ReconstructionResult,
)

__all__ = [
    "ActiveForgettingTemporalReconstructionModule",
    "ActiveForgettingTemporalReconstructionModuleV3",
    "MemoryBlock",
    "ForgetPolicy",
    "ReconstructionResult",
]
