/*
 * Aetherion DevOS v18 - Counterfactual Guard+
 * Local-only what-if estimator. It does not predict the internet; it estimates
 * how local risk would likely move under safer/stricter/looser policy choices.
 */
(function () {
  "use strict";

  function clamp(value, min, max) { return Math.max(min, Math.min(max, Number(value || 0))); }
  function safeArray(value) { return Array.isArray(value) ? value : []; }
  function safeNumber(value, fallback) { const n = Number(value); return Number.isFinite(n) ? n : fallback; }
  function text(value, fallback) { return String(value || fallback || ""); }

  function riskLevel(score) {
    score = clamp(score, 0, 100);
    if (score >= 85) return "CRITICAL";
    if (score >= 62) return "HIGH";
    if (score >= 35) return "MEDIUM";
    return "LOW";
  }

  function strongerPolicy(mode) {
    const order = { observe: 0, balanced: 1, protective: 2, strict: 3 };
    return order[String(mode || "balanced")] ?? 1;
  }

  function confidenceFrom(input, scenarioCount) {
    const causal = safeNumber(input.causalGuard && input.causalGuard.causalConfidence, 0);
    const graph = safeNumber(input.evidenceGraph && input.evidenceGraph.graphConfidence, 0);
    const report = safeNumber(input.reportIntelligence && input.reportIntelligence.confidence, 0);
    const timeline = safeNumber(input.timelineIntelligence && input.timelineIntelligence.eventCount, 0);
    const actions = safeArray(input.actionPlan && input.actionPlan.actions).length;
    return clamp(Math.round(causal * 0.28 + graph * 0.30 + report * 0.18 + Math.min(18, timeline * 2) + Math.min(12, actions * 2) + Math.min(8, scenarioCount)), 10, 96);
  }

  function classifyDelta(delta) {
    if (delta <= -18) return "STRONGLY_BETTER";
    if (delta <= -7) return "BETTER";
    if (delta < 7) return "SIMILAR";
    if (delta < 18) return "WORSE";
    return "STRONGLY_WORSE";
  }

  function makeScenario(id, label, baselineRisk, estimatedRisk, rationale, evidence, assumptions) {
    const risk = clamp(Math.round(estimatedRisk), 0, 100);
    const delta = risk - baselineRisk;
    return {
      id,
      label,
      estimatedRisk: risk,
      estimatedLevel: riskLevel(risk),
      delta,
      deltaClass: classifyDelta(delta),
      rationale: text(rationale, "Local heuristic counterfactual."),
      evidence: safeArray(evidence).filter(Boolean).slice(0, 5),
      assumptions: safeArray(assumptions).filter(Boolean).slice(0, 5)
    };
  }

  function bestScenario(scenarios) { return scenarios.slice().sort((a, b) => a.estimatedRisk - b.estimatedRisk)[0] || null; }
  function worstScenario(scenarios) { return scenarios.slice().sort((a, b) => b.estimatedRisk - a.estimatedRisk)[0] || null; }

  function actionPressure(input) {
    const plan = input.actionPlan || {};
    const policy = input.policyDecision || {};
    const actions = safeArray(plan.actions).filter((action) => action && action.type && action.type !== "NOOP");
    const autoActions = safeArray(policy.autoActions);
    const high = actions.filter((a) => a.severity === "high" || a.severity === "critical").length;
    const visual = actions.filter((a) => /OVERLAY|HIGHLIGHT|MARK|VISUAL|FORM|DOWNLOAD/i.test(a.type || "")).length;
    return { actions, autoActions, high, visual, count: actions.length };
  }

  function buildRecommendations(scenarios, baselineRisk, input) {
    const recs = [];
    const best = bestScenario(scenarios);
    const worst = worstScenario(scenarios);
    const policy = input.policyDecision || {};
    const trust = input.trustCalibration || {};
    if (best && best.delta <= -8) recs.push({ title: "Prefer safer counterfactual", detail: `${best.label} estimates risk ${Math.abs(best.delta)} point(s) lower than current baseline.` });
    if (worst && worst.delta >= 10) recs.push({ title: "Avoid weaker posture", detail: `${worst.label} estimates a worse local risk path by ${worst.delta} point(s).` });
    if (baselineRisk >= 62 && String(policy.mode || "balanced") !== "strict") recs.push({ title: "Strict mode may be justified", detail: "High baseline risk plus causal/evidence signals suggest testing strict policy for this site." });
    if (trust.effectiveTrustLevel === "trusted" && baselineRisk >= 50) recs.push({ title: "Trusted but suspicious", detail: "The site is locally trusted, but current behavior still deserves watched/sensitive calibration." });
    if (!recs.length) recs.push({ title: "Keep observing", detail: "Counterfactuals are close to baseline; no strong alternate path is visible yet." });
    return recs.slice(0, 4);
  }

  function analyze(input) {
    input = input || {};
    const snapshot = input.snapshot || {};
    const risk = input.risk || {};
    const baselineRisk = clamp(safeNumber(risk.score, snapshot.riskScore || 0), 0, 100);
    const baselineLevel = risk.level || snapshot.riskLevel || riskLevel(baselineRisk);
    const timeline = input.timelineIntelligence || {};
    const causal = input.causalGuard || {};
    const graph = input.evidenceGraph || {};
    const policy = input.policyDecision || {};
    const trust = input.trustCalibration || {};
    const learning = input.learningProfile || {};
    const actions = actionPressure(input);
    const volatility = safeNumber(timeline.volatilityScore, 0);
    const riskDelta = safeNumber(timeline.riskDelta, 0);
    const causalConfidence = safeNumber(causal.causalConfidence, 0);
    const graphConfidence = safeNumber(graph.graphConfidence, 0);
    const policyOrder = strongerPolicy(policy.effectivePolicyMode || policy.mode || (input.settings && input.settings.policyMode));
    const trusted = trust.effectiveTrustLevel === "trusted" || trust.userTrustLevel === "trusted";
    const sensitive = trust.effectiveTrustLevel === "sensitive" || trust.effectiveTrustLevel === "blocked";
    const causeType = causal.primaryCause && causal.primaryCause.type ? causal.primaryCause.type : "unknown";
    const causeEvidence = causal.primaryCause && causal.primaryCause.evidence ? causal.primaryCause.evidence : [];
    const graphGaps = safeArray(graph.gaps).length;
    const confidenceBonus = (causalConfidence + graphConfidence) / 20;
    const actionRelief = Math.min(22, actions.visual * 4 + actions.autoActions.length * 5 + actions.high * 6);
    const volatilityPenalty = Math.min(18, volatility / 4 + Math.max(0, riskDelta) * 2);

    const scenarios = [];
    scenarios.push(makeScenario("observed_path", "Observed path", baselineRisk, baselineRisk, "Current local risk path using active Aetherion modules.", [timeline.summary, causal.summary, graph.summary], ["Uses current policy/trust/rules exactly as observed."]));
    scenarios.push(makeScenario("no_assists", "No Aetherion assists", baselineRisk, baselineRisk + Math.max(4, actionRelief * 0.72) + Math.max(0, riskDelta) + (actions.count ? 3 : 0), "Estimates local risk if visual assists, action plan, and safe auto-mode were not available.", safeArray(causeEvidence).concat([`${actions.count} action card(s), ${actions.autoActions.length} safe auto action(s).`]), ["Assumes risky UI elements remain visible.", "Does not block network requests; estimates only local UI/session risk."]));
    scenarios.push(makeScenario("strict_policy", "Strict policy", baselineRisk, baselineRisk - Math.max(6, actionRelief * 0.55 + confidenceBonus) - (policyOrder < 3 ? 5 : 0), "Estimates effect of switching this site to strict local policy.", [policy.summary, `Primary cause: ${causeType}`, graph.topPath], ["Assumes only safe/reversible local actions are allowed.", "May increase false positives on very dynamic sites."]));
    scenarios.push(makeScenario("protective_policy", "Protective policy", baselineRisk, baselineRisk - Math.max(3, actionRelief * 0.38 + confidenceBonus / 2), "Estimates a moderate safety posture without full strict mode.", [policy.summary, learning.summary], ["Balances risk reduction and page usability."]));
    scenarios.push(makeScenario("observe_only", "Observe only", baselineRisk, baselineRisk + Math.max(3, actionRelief * 0.34) + Math.min(10, volatilityPenalty / 2), "Estimates risk if Aetherion only watches and does not suggest/apply assists.", [timeline.summary, `${volatility} volatility score`], ["Useful for debugging, weaker for high-risk pages."]));
    scenarios.push(makeScenario("trusted_override", "Trusted override", baselineRisk, baselineRisk - (trusted ? 4 : 7) + (baselineRisk >= 55 ? 8 : 0) + (graphGaps > 2 ? 4 : 0), "Estimates effect of treating the domain as trusted/local-safe.", [trust.summary, `Graph gaps: ${graphGaps}`], ["Trust should not erase live high-risk evidence.", "Local trust is reversible from popup."]));
    if (sensitive || baselineRisk >= 62) {
      scenarios.push(makeScenario("sensitive_lockdown", "Sensitive / blocked calibration", baselineRisk, baselineRisk - Math.max(8, actionRelief * 0.62 + 6), "Estimates effect of calibrating this site as sensitive or blocked locally.", [trust.summary, causal.summary], ["Best for pages with forms, download risk, or repeated suspicious behavior."]));
    }

    const best = bestScenario(scenarios);
    const worst = worstScenario(scenarios);
    const avoidedRiskEstimate = worst && best ? clamp(worst.estimatedRisk - best.estimatedRisk, 0, 100) : 0;
    const noAssists = scenarios.find((s) => s.id === "no_assists") || { estimatedRisk: baselineRisk };
    const actionValueEstimate = clamp(Math.round((noAssists.estimatedRisk - baselineRisk) * 0.75), 0, 40);
    const confidence = confidenceFrom(input, scenarios.length);
    const recommendations = buildRecommendations(scenarios, baselineRisk, input);
    const healthBand = confidence >= 78 ? "STRONG" : confidence >= 55 ? "USEFUL" : confidence >= 35 ? "PARTIAL" : "WARMING";
    const summary = best ? `Counterfactual Guard estimates best local path: ${best.label} (${best.estimatedRisk}/100, Δ ${best.delta}). Worst path: ${worst.label} (${worst.estimatedRisk}/100).` : "Counterfactual Guard is warming up.";

    return {
      status: "COUNTERFACTUAL_READY",
      baselineRisk,
      baselineLevel,
      counterfactualConfidence: confidence,
      healthBand,
      bestScenario: best,
      worstScenario: worst,
      avoidedRiskEstimate,
      actionValueEstimate,
      scenarioCount: scenarios.length,
      scenarios: scenarios.slice(0, 8),
      keyAssumptions: ["All estimates are local heuristic what-if simulations.", "No external reputation lookup or API call is used.", "Risk deltas are comparative, not guarantees."],
      recommendations,
      summary,
      generatedAt: new Date().toISOString(),
      heuristic: true,
      version: "18.0.0"
    };
  }

  window.AetherionCounterfactualGuard = { analyze };
})();
