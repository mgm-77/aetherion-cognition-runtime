/*
 * Aetherion DevOS v18 - Site Intelligence+ Engine
 * Local-only domain intelligence from current page behavior + stored site profile.
 */
(function () {
  "use strict";

  const VERSION = "18.0.0";

  function nowIso() { return new Date().toISOString(); }
  function safeNumber(value, fallback) {
    const n = Number(value);
    return Number.isFinite(n) ? n : fallback;
  }
  function clamp(value, min, max) { return Math.max(min, Math.min(max, value)); }
  function round(value, digits) {
    const factor = Math.pow(10, digits || 0);
    return Math.round(value * factor) / factor;
  }
  function avg(list) {
    if (!Array.isArray(list) || !list.length) return 0;
    return list.reduce((a, b) => a + safeNumber(b, 0), 0) / list.length;
  }
  function stdev(list) {
    if (!Array.isArray(list) || list.length < 2) return 0;
    const m = avg(list);
    return Math.sqrt(avg(list.map((x) => Math.pow(safeNumber(x, 0) - m, 2))));
  }
  function compactHost(site) { return String(site || "unknown").replace(/^www\./, "").slice(0, 80); }

  function trendFrom(profile, currentRisk) {
    const trend = Array.isArray(profile && profile.riskTrend) ? profile.riskTrend : [];
    const scores = trend.map((item) => safeNumber(item && item.riskScore, null)).filter((n) => Number.isFinite(n));
    if (Number.isFinite(currentRisk)) scores.push(currentRisk);
    if (scores.length < 3) return { direction: "NEW", delta: 0, recentAvg: round(avg(scores), 1), olderAvg: 0, confidence: 42 };
    const recent = scores.slice(-3);
    const older = scores.slice(0, Math.max(0, scores.length - 3));
    const recentAvg = avg(recent);
    const olderAvg = older.length ? avg(older) : avg(scores.slice(0, -1));
    const delta = recentAvg - olderAvg;
    let direction = "STABLE";
    if (delta >= 14) direction = "WORSENING";
    else if (delta <= -14) direction = "IMPROVING";
    else if (Math.abs(delta) >= 7) direction = delta > 0 ? "SLIGHTLY_WORSE" : "SLIGHTLY_BETTER";
    return { direction, delta: round(delta, 1), recentAvg: round(recentAvg, 1), olderAvg: round(olderAvg, 1), confidence: clamp(45 + scores.length * 5, 45, 90) };
  }

  function familiarity(visits) {
    visits = safeNumber(visits, 0);
    if (visits <= 0) return "NEW";
    if (visits === 1) return "FIRST_SEEN";
    if (visits < 4) return "LOW";
    if (visits < 10) return "MEDIUM";
    return "HIGH";
  }

  function reputationLevel(reputationScore, currentRisk, profile) {
    if (profile && profile.trusted && reputationScore >= 55 && currentRisk < 70) return "TRUSTED_LOCAL";
    if (currentRisk >= 85 || reputationScore < 25) return "CRITICAL_WATCH";
    if (currentRisk >= 70 || reputationScore < 40) return "RISKY";
    if (currentRisk >= 45 || reputationScore < 60) return "WATCHLIST";
    if (reputationScore >= 80) return "STABLE";
    return "NORMAL";
  }

  function behaviorClass(snapshot, risk, profile, volatility) {
    const signals = (risk && risk.signals) || (snapshot && snapshot.signals) || {};
    const scripts = signals.scripts || {};
    const forms = signals.forms || {};
    const links = signals.links || {};
    const mutations = safeNumber(snapshot && snapshot.mutations, 0);
    const anomalies = safeNumber(snapshot && snapshot.anomalies, 0);
    const visits = safeNumber(profile && profile.visits, 0);
    if (safeNumber(links.dangerousDownloads, 0) > 0) return "download-sensitive surface";
    if (safeNumber(forms.passwordFields, 0) > 0 || safeNumber(forms.password, 0) > 0) return "credential-sensitive surface";
    if (safeNumber(scripts.trackers, 0) >= 4) return "tracking-heavy page";
    if (anomalies >= 3 || mutations >= 900) return "aggressive dynamic DOM";
    if (volatility >= 20) return "volatile known site";
    if (visits <= 1) return "new/local unknown site";
    return "known calm site";
  }

  function policyHint(reputation, trend, currentRisk, volatility, settings) {
    if (settings && settings.adaptivePolicyHints === false) return settings.policyMode || "balanced";
    if (currentRisk >= 85 || reputation === "CRITICAL_WATCH") return "strict";
    if (currentRisk >= 65 || reputation === "RISKY" || trend.direction === "WORSENING") return "protective";
    if (volatility >= 24 || reputation === "WATCHLIST") return "balanced";
    if (trend.direction === "IMPROVING" && currentRisk < 35) return "observe";
    return settings && settings.policyMode ? settings.policyMode : "balanced";
  }

  function makeRecommendations(intel) {
    const recs = [];
    if (intel.reputationLevel === "CRITICAL_WATCH" || intel.reputationLevel === "RISKY") {
      recs.push("Keep Policy Engine in protective/strict mode for this domain.");
    }
    if (intel.trendDirection === "WORSENING") recs.push("Risk trend is worsening; save a session report after interaction.");
    if (intel.behaviorClass.indexOf("credential") >= 0) recs.push("Use extra caution before entering credentials on this page.");
    if (intel.behaviorClass.indexOf("download") >= 0) recs.push("Verify download links before opening files.");
    if (!recs.length) recs.push("Continue observe mode; no strong local site-level concern yet.");
    return recs.slice(0, 4);
  }

  function analyze(input) {
    input = input || {};
    const snapshot = input.snapshot || {};
    const risk = input.risk || {};
    const profile = input.profile || {};
    const settings = input.settings || {};
    const currentRisk = safeNumber(risk.score, safeNumber(snapshot.riskScore, 0));
    const avgRisk = safeNumber(profile.avgRisk, currentRisk);
    const maxRisk = safeNumber(profile.maxRisk, currentRisk);
    const visits = safeNumber(profile.visits, 0);
    const totalAnomalies = safeNumber(profile.totalAnomalies, 0) + safeNumber(snapshot.anomalies, 0);
    const trustBonus = profile.trusted ? 12 : 0;
    const anomalyPenalty = clamp(totalAnomalies / Math.max(1, visits + 1), 0, 14);
    const maxPenalty = clamp((maxRisk - avgRisk) * 0.18, 0, 9);
    const reputationScore = clamp(100 - (currentRisk * 0.42) - (avgRisk * 0.33) - (maxRisk * 0.14) - anomalyPenalty - maxPenalty + trustBonus, 0, 100);
    const trend = trendFrom(profile, currentRisk);
    const scores = (Array.isArray(profile.riskTrend) ? profile.riskTrend : []).map((item) => safeNumber(item && item.riskScore, null)).filter((n) => Number.isFinite(n)).concat([currentRisk]);
    const volatility = round(clamp(stdev(scores), 0, 60), 1);
    const reputation = reputationLevel(reputationScore, currentRisk, profile);
    const behavior = behaviorClass(snapshot, risk, profile, volatility);
    const hint = policyHint(reputation, trend, currentRisk, volatility, settings);
    const fam = familiarity(visits);
    const notes = [];
    notes.push(`${compactHost(snapshot.site || profile.site)}: ${fam.toLowerCase().replace(/_/g, " ")} domain profile.`);
    notes.push(`Current risk ${currentRisk}/100, local average ${round(avgRisk, 1)}/100, max ${round(maxRisk, 1)}/100.`);
    notes.push(`Trend ${trend.direction.toLowerCase().replace(/_/g, " ")} with volatility ${volatility}.`);
    if (profile.trusted) notes.push("Domain is marked trusted locally; risk discount is still bounded.");
    if (hint !== (settings.policyMode || "balanced")) notes.push(`Adaptive policy hint differs from current mode: ${hint}.`);

    const intel = {
      id: "site-intel-" + Date.now() + "-" + Math.random().toString(16).slice(2),
      version: VERSION,
      at: nowIso(),
      site: snapshot.site || profile.site || "unknown",
      currentRisk,
      averageRisk: round(avgRisk, 1),
      maxRisk: round(maxRisk, 1),
      visits,
      familiarity: fam,
      reputationScore: round(reputationScore, 1),
      reputationLevel: reputation,
      trendDirection: trend.direction,
      trendDelta: trend.delta,
      trendConfidence: trend.confidence,
      volatilityScore: volatility,
      behaviorClass: behavior,
      policyHint: hint,
      trusted: Boolean(profile.trusted),
      summary: `${reputation.replace(/_/g, " ")} · ${trend.direction.replace(/_/g, " ")} · ${behavior}`,
      notes,
      recommendations: []
    };
    intel.recommendations = makeRecommendations(intel);
    return intel;
  }

  window.AetherionSiteIntelligence = { VERSION, analyze };
})();
