/*
 * Aetherion DevOS v18 - Risk Engine
 * Local heuristic analysis. Produces explainable signals, not certainty.
 */
(function () {
  "use strict";

  const TRACKING_PATTERNS = [
    "doubleclick", "googletagmanager", "google-analytics", "analytics",
    "facebook.net", "connect.facebook", "fbq", "hotjar", "segment",
    "mixpanel", "amplitude", "clarity", "adservice", "adsystem",
    "taboola", "outbrain", "pixel", "tracker", "tracking", "beacon",
    "scorecardresearch", "quantserve", "adnxs", "criteo", "matomo"
  ];

  const CRYPTO_PATTERNS = [
    "coinhive", "cryptonight", "minero", "webmine", "crypto-loot", "jsecoin",
    "miner", "monero"
  ];

  const PHISHING_WORDS = [
    "verify", "verification", "secure", "security", "login", "signin",
    "account", "update", "confirm", "wallet", "billing", "recover",
    "support", "unlock", "suspended", "limited", "urgent", "password",
    "2fa", "seed", "phrase", "restore", "kyc"
  ];

  const BRAND_WORDS = [
    "paypal", "google", "microsoft", "apple", "facebook", "instagram",
    "whatsapp", "telegram", "binance", "metamask", "netflix", "amazon",
    "icloud", "outlook", "office", "github", "coinbase", "revolut"
  ];

  const DARK_PATTERN_WORDS = [
    "accept all", "allow all", "continue", "only today", "last chance",
    "limited time", "subscribe now", "claim", "urgent", "don't miss",
    "no thanks", "remind me later", "are you sure", "recommended",
    "exclusive", "almost gone", "act now", "free trial", "cancel anytime"
  ];

  const DANGEROUS_DOWNLOAD_EXTENSIONS = [
    ".apk", ".exe", ".msi", ".scr", ".bat", ".cmd", ".ps1", ".vbs", ".js", ".jar"
  ];

  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function textOf(el) {
    return (el && (el.innerText || el.value || el.getAttribute("aria-label") || el.title || "") || "")
      .toString()
      .trim()
      .toLowerCase();
  }

  function isIPAddress(hostname) {
    return /^(\d{1,3}\.){3}\d{1,3}$/.test(hostname || "");
  }

  function hostnameParts(hostname) {
    return (hostname || "").split(".").filter(Boolean);
  }

  function normalizeHost(host) {
    return (host || "").toLowerCase().replace(/^www\./, "");
  }

  function sameSite(hostA, hostB) {
    const a = normalizeHost(hostA);
    const b = normalizeHost(hostB);
    return a === b || a.endsWith("." + b) || b.endsWith("." + a);
  }

  function countSuspiciousScripts() {
    const scripts = Array.from(document.scripts || []);
    let trackers = 0;
    let crypto = 0;
    let external = 0;
    let inlineLarge = 0;
    const examples = [];

    for (const script of scripts) {
      const src = (script.src || "").toLowerCase();
      if (!src) {
        const txt = script.textContent || "";
        if (txt.length > 5000) inlineLarge += 1;
        continue;
      }
      try {
        const url = new URL(src, location.href);
        if (url.hostname && !sameSite(url.hostname, location.hostname)) external += 1;
      } catch (_) {}

      if (TRACKING_PATTERNS.some((pattern) => src.includes(pattern))) {
        trackers += 1;
        if (examples.length < 5) examples.push(script.src);
      }
      if (CRYPTO_PATTERNS.some((pattern) => src.includes(pattern))) {
        crypto += 1;
        if (examples.length < 5) examples.push(script.src);
      }
    }

    return { total: scripts.length, external, trackers, crypto, inlineLarge, examples };
  }

  function analyzeForms() {
    const forms = Array.from(document.forms || []);
    let passwordFields = 0;
    let externalPostForms = 0;
    let insecurePasswordForms = 0;
    let sensitiveInputs = 0;
    let hiddenInputs = 0;
    const formExamples = [];

    for (const form of forms) {
      const passwordNodes = Array.from(form.querySelectorAll('input[type="password"]'));
      const hiddenNodes = Array.from(form.querySelectorAll('input[type="hidden"]'));
      const sensitiveNodes = Array.from(form.querySelectorAll("input, textarea")).filter((input) => {
        const joined = [input.name, input.id, input.placeholder, input.autocomplete, input.getAttribute("aria-label")]
          .join(" ")
          .toLowerCase();
        return /password|pass|card|credit|cvv|cvc|wallet|seed|phrase|token|otp|2fa|iban|ssn|pin/.test(joined);
      });

      const hasPassword = passwordNodes.length > 0;
      if (hasPassword) passwordFields += passwordNodes.length;
      hiddenInputs += hiddenNodes.length;
      sensitiveInputs += sensitiveNodes.length;

      let actionHost = location.hostname;
      try {
        const actionUrl = new URL(form.getAttribute("action") || location.href, location.href);
        actionHost = actionUrl.hostname;
      } catch (_) {}

      const external = actionHost && !sameSite(actionHost, location.hostname);
      if (external) externalPostForms += 1;
      if (hasPassword && location.protocol !== "https:") insecurePasswordForms += 1;

      if ((external || hasPassword || sensitiveNodes.length > 0) && formExamples.length < 4) {
        formExamples.push({
          actionHost,
          hasPassword,
          sensitiveInputs: sensitiveNodes.length,
          hiddenInputs: hiddenNodes.length,
          method: (form.method || "GET").toUpperCase()
        });
      }
    }

    return {
      total: forms.length,
      passwordFields,
      externalPostForms,
      insecurePasswordForms,
      sensitiveInputs,
      hiddenInputs,
      examples: formExamples
    };
  }

  function analyzePhishingSurface() {
    const host = location.hostname.toLowerCase();
    const href = location.href.toLowerCase();
    const path = location.pathname.toLowerCase();
    const title = (document.title || "").toLowerCase();
    const parts = hostnameParts(host);
    const indicators = [];

    if (location.protocol !== "https:" && location.protocol !== "chrome-extension:") {
      indicators.push({ type: "insecure_protocol", weight: 12, detail: "Page is not HTTPS." });
    }
    if (host.includes("xn--")) {
      indicators.push({ type: "punycode_domain", weight: 18, detail: "Hostname uses punycode; possible homograph risk." });
    }
    if (isIPAddress(host)) {
      indicators.push({ type: "ip_hostname", weight: 14, detail: "Hostname is a raw IP address." });
    }
    if (parts.length >= 5) {
      indicators.push({ type: "many_subdomains", weight: 8, detail: "Hostname has many subdomains." });
    }
    if (/[-_](login|secure|verify|wallet|account)|((login|secure|verify|wallet|account)[-_])/.test(host)) {
      indicators.push({ type: "credential_host_words", weight: 10, detail: "Hostname contains login/security/wallet style terms." });
    }

    const keywordHits = PHISHING_WORDS.filter((word) => href.includes(word) || title.includes(word));
    if (keywordHits.length >= 2) {
      indicators.push({
        type: "suspicious_keywords",
        weight: clamp(keywordHits.length * 3, 6, 18),
        detail: "Login/security/payment style keywords detected: " + keywordHits.slice(0, 6).join(", ")
      });
    }

    const brandHits = BRAND_WORDS.filter((word) => host.includes(word) || path.includes(word) || title.includes(word));
    if (brandHits.length > 0) {
      const officialish = brandHits.some((brand) => host === brand + ".com" || host.endsWith("." + brand + ".com"));
      if (!officialish) {
        indicators.push({
          type: "brand_like_surface",
          weight: 8,
          detail: "Brand-like terms appear outside a simple official-looking domain: " + brandHits.slice(0, 4).join(", ")
        });
      }
    }

    return indicators;
  }

  function analyzeDarkPatterns() {
    const controls = Array.from(document.querySelectorAll("button, a, input[type='button'], input[type='submit'], [role='button']"));
    const fixedPanels = Array.from(document.querySelectorAll("body *")).filter((el) => {
      try {
        const style = getComputedStyle(el);
        const rect = el.getBoundingClientRect();
        return ["fixed", "sticky"].includes(style.position) && rect.width > window.innerWidth * 0.35 && rect.height > 80;
      } catch (_) {
        return false;
      }
    }).length;

    const hits = [];
    let asymmetryHints = 0;
    for (const control of controls.slice(0, 800)) {
      const txt = textOf(control);
      if (!txt) continue;
      const matched = DARK_PATTERN_WORDS.find((word) => txt.includes(word));
      if (matched && hits.length < 12) hits.push({ text: txt.slice(0, 80), matched });
      if (/accept|allow|yes|continue/.test(txt) && txt.length < 24) asymmetryHints += 1;
    }

    return {
      controlCount: controls.length,
      fixedPanels,
      hits,
      asymmetryHints: clamp(asymmetryHints, 0, 30),
      scoreHint: clamp(hits.length * 3 + fixedPanels * 2 + Math.floor(asymmetryHints / 8), 0, 24)
    };
  }

  function analyzeIframes() {
    const frames = Array.from(document.querySelectorAll("iframe"));
    let external = 0;
    let hidden = 0;
    const examples = [];
    for (const frame of frames) {
      try {
        const src = frame.getAttribute("src");
        const rect = frame.getBoundingClientRect();
        if (rect.width < 5 || rect.height < 5) hidden += 1;
        if (!src) continue;
        const url = new URL(src, location.href);
        if (!sameSite(url.hostname, location.hostname)) {
          external += 1;
          if (examples.length < 5) examples.push(url.hostname);
        }
      } catch (_) {}
    }
    return { total: frames.length, external, hidden, examples };
  }

  function analyzeLinks() {
    const links = Array.from(document.querySelectorAll("a[href]")).slice(0, 1500);
    let external = 0;
    let newTabExternal = 0;
    let javascriptLinks = 0;
    let dangerousDownloads = 0;
    let emptyOrMasked = 0;
    const examples = [];

    for (const link of links) {
      const raw = link.getAttribute("href") || "";
      const text = textOf(link);
      if (raw.startsWith("javascript:")) javascriptLinks += 1;
      if (!raw || raw === "#" || raw.trim() === "") emptyOrMasked += 1;
      const isDownload = Boolean(link.download) || DANGEROUS_DOWNLOAD_EXTENSIONS.some((ext) => raw.toLowerCase().split(/[?#]/)[0].endsWith(ext));
      if (isDownload) dangerousDownloads += 1;
      try {
        const url = new URL(raw, location.href);
        const ext = !sameSite(url.hostname, location.hostname);
        if (ext) external += 1;
        if (ext && (link.target || "").toLowerCase() === "_blank") newTabExternal += 1;
        if (examples.length < 5 && (isDownload || (ext && /login|verify|wallet|account|secure/.test(text + " " + raw.toLowerCase())))) {
          examples.push({ host: url.hostname, text: text.slice(0, 60), download: isDownload });
        }
      } catch (_) {}
    }

    return {
      total: links.length,
      external,
      newTabExternal,
      javascriptLinks,
      dangerousDownloads,
      emptyOrMasked,
      examples
    };
  }

  function analyzeStorageSurface() {
    let localStorageSize = 0;
    let sessionStorageSize = 0;
    try {
      for (let i = 0; i < localStorage.length; i += 1) {
        const key = localStorage.key(i);
        localStorageSize += String(key || "").length + String(localStorage.getItem(key) || "").length;
      }
    } catch (_) {}
    try {
      for (let i = 0; i < sessionStorage.length; i += 1) {
        const key = sessionStorage.key(i);
        sessionStorageSize += String(key || "").length + String(sessionStorage.getItem(key) || "").length;
      }
    } catch (_) {}
    return { localStorageSize, sessionStorageSize };
  }

  function levelFromScore(score) {
    if (score >= 80) return "CRITICAL";
    if (score >= 55) return "HIGH";
    if (score >= 30) return "MEDIUM";
    return "LOW";
  }

  function computeRisk(input) {
    const settings = input.settings || {};
    const profile = input.profile || null;
    const mutations = Number(input.mutations || 0);
    const anomalies = Number(input.anomalies || 0);
    const userEvents = input.userEvents || {};

    const scripts = countSuspiciousScripts();
    const forms = analyzeForms();
    const phishingIndicators = analyzePhishingSurface();
    const darkPatterns = analyzeDarkPatterns();
    const iframes = analyzeIframes();
    const links = analyzeLinks();
    const storageSurface = analyzeStorageSurface();

    const reasons = [];
    const categories = {
      behavior: 0,
      tracking: 0,
      credential: 0,
      domain: 0,
      deception: 0,
      embedding: 0,
      downloads: 0
    };
    let score = 0;

    const highMutationThreshold = Number(settings.highMutationThreshold || 120);
    const criticalMutationThreshold = Number(settings.criticalMutationThreshold || 350);

    function add(points, reason, category) {
      const clean = clamp(Number(points || 0), 0, 100);
      score += clean;
      if (category && categories[category] !== undefined) categories[category] += clean;
      if (reason) reasons.push(reason);
    }

    if (mutations > criticalMutationThreshold) {
      add(20, "Critical DOM mutation volume detected.", "behavior");
    } else if (mutations > highMutationThreshold) {
      add(10, "High DOM mutation volume detected.", "behavior");
    }

    if (anomalies > 0) add(clamp(anomalies * 6, 6, 24), "Activity spikes/anomalies observed: " + anomalies + ".", "behavior");
    if (scripts.trackers > 0) add(clamp(scripts.trackers * 3, 3, 18), "Tracking/analytics-like scripts found: " + scripts.trackers + ".", "tracking");
    if (scripts.crypto > 0) add(25, "Crypto-mining-like script pattern detected.", "tracking");
    if (scripts.inlineLarge >= 4) add(6, "Several large inline scripts detected.", "tracking");

    if (forms.insecurePasswordForms > 0) add(25, "Password form appears on a non-HTTPS page.", "credential");
    if (forms.externalPostForms > 0) add(clamp(forms.externalPostForms * 8, 8, 20), "Forms post to external domains: " + forms.externalPostForms + ".", "credential");
    if (forms.sensitiveInputs >= 3) add(8, "Multiple sensitive-looking input fields detected.", "credential");
    if (forms.hiddenInputs > 20 && forms.passwordFields > 0) add(5, "Login form has many hidden inputs.", "credential");

    for (const indicator of phishingIndicators) {
      add(indicator.weight, indicator.detail, indicator.type === "brand_like_surface" || indicator.type === "suspicious_keywords" ? "deception" : "domain");
    }

    if (darkPatterns.scoreHint > 0) add(darkPatterns.scoreHint, "Dark-pattern-like UI hints detected: " + darkPatterns.hits.length + ".", "deception");
    if (iframes.external >= 5) add(8, "Many external iframes detected.", "embedding");
    if (iframes.hidden >= 3) add(6, "Hidden/small iframe surfaces detected.", "embedding");
    if (links.dangerousDownloads > 0) add(clamp(links.dangerousDownloads * 10, 10, 30), "Potentially dangerous download links detected: " + links.dangerousDownloads + ".", "downloads");
    if (links.javascriptLinks > 25) add(5, "Many javascript: links detected.", "deception");
    if (links.newTabExternal > 30) add(5, "Many external links open new tabs.", "tracking");

    const interactionBalance = Number(userEvents.clicks || 0) + Number(userEvents.keys || 0) + Number(userEvents.scrolls || 0);
    if (mutations > highMutationThreshold && interactionBalance < 2) {
      add(8, "Page changed heavily with little user interaction.", "behavior");
    }

    if (profile && profile.trusted) {
      const discount = clamp(Number(settings.trustedRiskDiscount || 10), 0, 30);
      score -= discount;
      reasons.push("Trusted site discount applied: -" + discount + ".");
    }

    score = clamp(Math.round(score), 0, 100);

    return {
      score,
      level: levelFromScore(score),
      reasons: reasons.slice(0, 14),
      categories,
      signals: {
        scripts,
        forms,
        phishingIndicators,
        darkPatterns,
        iframes,
        links,
        storageSurface,
        userEvents,
        mutations,
        anomalies
      },
      generatedAt: new Date().toISOString(),
      heuristic: true
    };
  }

  window.AetherionRiskEngine = {
    computeRisk,
    levelFromScore,
    countSuspiciousScripts,
    analyzeForms,
    analyzePhishingSurface,
    analyzeDarkPatterns,
    analyzeIframes,
    analyzeLinks,
    analyzeStorageSurface
  };
})();
