/*
 * Aetherion DevOS v18 - Content Runtime
 * Browser Guardian overlay + risk engine + local agent + action planner + policy engine with auto-mode guard + Site Intelligence+, Learning Profiles+, Rule Composer+, Trust Calibration+, and Report Intelligence+ and Timeline Intelligence+ and Causal Guard+ and Evidence Graph+ and Counterfactual Guard+.
 */
(function () {
  "use strict";

  if (window.__AETHERION_V18_ACTIVE__) return;
  window.__AETHERION_V18_ACTIVE__ = true;

  const STATE = {
    startedAt: Date.now(),
    mutationCount: 0,
    anomalyCount: 0,
    lastMutationBurstAt: 0,
    burstWindowStartedAt: Date.now(),
    burstMutationCount: 0,
    lastPanelUpdateAt: 0,
    lastRiskComputeAt: 0,
    lastAgentComputeAt: 0,
    lastPlanComputeAt: 0,
    lastRisk: null,
    lastAgentDecision: null,
    lastActionPlan: null,
    lastPolicyDecision: null,
    lastSiteIntelligence: null,
    lastSiteIntelComputeAt: 0,
    lastLearningProfile: null,
    lastLearningComputeAt: 0,
    lastTrustCalibration: null,
    lastTrustComputeAt: 0,
    lastRuleDecision: null,
    lastRuleComputeAt: 0,
    lastReportIntelligence: null,
    lastReportComputeAt: 0,
    lastTimelineIntelligence: null,
    lastTimelineComputeAt: 0,
    lastCausalGuard: null,
    lastCausalComputeAt: 0,
    lastEvidenceGraph: null,
    lastEvidenceGraphComputeAt: 0,
    lastCounterfactualGuard: null,
    lastCounterfactualComputeAt: 0,
    lastTimelinePointAt: 0,
    timelinePoints: [],
    rules: [],
    lastAutoModeAt: 0,
    autoAppliedActionIds: {},
    settings: Object.assign({}, window.AetherionMemory ? window.AetherionMemory.DEFAULT_SETTINGS : {}),
    siteProfile: null,
    appliedActions: [],
    hiddenNodes: [],
    highlightedNodes: [],
    injectedNodes: [],
    userEvents: {
      clicks: 0,
      scrolls: 0,
      keys: 0,
      formsFocused: 0,
      passwordFieldsFocused: 0,
      downloadsClicked: 0,
      externalLinksClicked: 0
    }
  };

  const PANEL_ID = "aetherion-v18-panel";
  const BANNER_ID = "aetherion-v18-guard-banner";
  const STYLE_ID = "aetherion-v18-style";

  function safeCall(fn, fallback) {
    try { return fn(); } catch (error) { console.warn("[Aetherion] safeCall failed", error); return fallback; }
  }

  function hostname() {
    return window.AetherionMemory && window.AetherionMemory.safeHostname
      ? window.AetherionMemory.safeHostname(location.href)
      : location.hostname;
  }

  function escapeHTML(value) {
    return String(value || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function riskEmoji(level) {
    if (level === "CRITICAL") return "🔴";
    if (level === "HIGH") return "🟠";
    if (level === "MEDIUM") return "🟡";
    return "🟢";
  }

  function ensureStyle() {
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      .aetherion-v18-highlight-form { outline: 3px solid rgba(255, 190, 92, .96) !important; box-shadow: 0 0 0 6px rgba(255, 190, 92, .22) !important; }
      .aetherion-v18-download-mark { outline: 2px solid rgba(255, 95, 95, .92) !important; box-shadow: 0 0 0 4px rgba(255, 95, 95, .18) !important; }
      .aetherion-v18-label { font-family: Arial, sans-serif !important; font-size: 11px !important; line-height: 1.2 !important; color: #fff !important; background: rgba(21, 27, 42, .96) !important; border: 1px solid rgba(143,199,255,.35) !important; border-radius: 8px !important; padding: 4px 6px !important; margin: 4px 0 !important; display: inline-block !important; z-index: 2147483647 !important; }
      .aetherion-v18-intel-chip { color:#e7ddff !important; border-color:rgba(196,167,255,.45) !important; background:rgba(38,28,64,.96) !important; }
    `;
    document.documentElement.appendChild(style);
  }

  function createPanel() {
    if (document.getElementById(PANEL_ID)) return document.getElementById(PANEL_ID);
    const panel = document.createElement("div");
    panel.id = PANEL_ID;
    panel.style.cssText = [
      "position:fixed", "right:10px", "bottom:10px", "z-index:2147483647",
      "background:rgba(7,10,20,0.94)", "color:#e9f1ff", "font-family:Arial,sans-serif",
      "font-size:12px", "line-height:1.35", "padding:10px 12px",
      "border:1px solid rgba(111,180,255,0.65)", "border-radius:12px",
      "box-shadow:0 6px 24px rgba(0,0,0,0.35)", "min-width:225px", "max-width:330px",
      "pointer-events:none"
    ].join(";");
    document.documentElement.appendChild(panel);
    return panel;
  }

  function createBanner() {
    if (document.getElementById(BANNER_ID)) return document.getElementById(BANNER_ID);
    const banner = document.createElement("div");
    banner.id = BANNER_ID;
    banner.style.cssText = [
      "position:fixed", "left:12px", "right:12px", "top:12px", "z-index:2147483647",
      "background:linear-gradient(135deg, rgba(25,8,13,.96), rgba(48,22,8,.96))",
      "color:#fff", "font-family:Arial,sans-serif", "font-size:13px", "line-height:1.35",
      "padding:12px 14px", "border:1px solid rgba(255,144,88,.75)", "border-radius:14px",
      "box-shadow:0 10px 30px rgba(0,0,0,.38)", "pointer-events:auto"
    ].join(";");
    document.documentElement.appendChild(banner);
    return banner;
  }

  function removeBanner() {
    const old = document.getElementById(BANNER_ID);
    if (old) old.remove();
  }

  function renderGuardBanner() {
    const decision = STATE.lastAgentDecision;
    const effective = activeSettings();
    if (!decision || !decision.shouldShowGuardBanner || effective.guardBannerEnabled === false) {
      removeBanner();
      return;
    }
    const banner = createBanner();
    const primary = decision.recommendations && decision.recommendations[0]
      ? decision.recommendations[0]
      : { title: "Aetherion guard", detail: decision.summary || "Caution recommended." };
    const plan = STATE.lastActionPlan || { actions: [] };
    const actionHint = plan.actions && plan.actions.length ? `${plan.actions.length} action card(s) ready in popup.` : "No action card required.";
    banner.innerHTML = `
      <div style="display:flex;gap:12px;align-items:flex-start;justify-content:space-between;">
        <div>
          <div style="font-weight:700;letter-spacing:.05em;color:#ffd7a1;">AETHERION v18 GUARD · ${escapeHTML(decision.riskLevel)} ${decision.riskScore}/100</div>
          <div style="font-weight:700;margin-top:3px;">${escapeHTML(primary.title)}</div>
          <div style="opacity:.9;margin-top:2px;max-width:760px;">${escapeHTML(primary.detail)}</div>
          <div style="opacity:.78;margin-top:4px;">Policy Planner: ${escapeHTML(actionHint)}</div>
        </div>
        <button id="aetherion-v18-hide-banner" style="background:rgba(255,255,255,.12);color:#fff;border:1px solid rgba(255,255,255,.3);border-radius:9px;padding:6px 9px;">Hide</button>
      </div>
    `;
    const btn = document.getElementById("aetherion-v18-hide-banner");
    if (btn && !btn.__aetherionBound) {
      btn.__aetherionBound = true;
      btn.addEventListener("click", removeBanner);
    }
  }

  function renderPanel() {
    if (!STATE.settings.overlayEnabled) {
      const old = document.getElementById(PANEL_ID);
      if (old) old.remove();
      removeBanner();
      return;
    }

    const now = Date.now();
    if (now - STATE.lastPanelUpdateAt < 500) return;
    STATE.lastPanelUpdateAt = now;

    const panel = createPanel();
    const risk = STATE.lastRisk || { score: 0, level: "LOW", reasons: [] };
    const agent = STATE.lastAgentDecision || { stance: "OBSERVE", summary: "Local agent warming up.", confidence: 0, recommendations: [] };
    const plan = STATE.lastActionPlan || { actions: [], summary: "Planner warming up." };
    const policy = STATE.lastPolicyDecision || { status: "WARMING", summary: "Policy warming up.", autoActions: [], blockedActions: [] };
    const intel = STATE.lastSiteIntelligence || { reputationLevel: "NEW", trendDirection: "NEW", policyHint: STATE.settings.policyMode || "balanced", reputationScore: 0, behaviorClass: "warming up" };
    const learning = STATE.lastLearningProfile || { learningClass: "WARMING_UP", confidence: 0, policyHint: STATE.settings.policyMode || "balanced", suspicionIndex: 0, summary: "Learning profile warming up." };
    const rules = STATE.lastRuleDecision || { status: "WARMING", matchedRules: [], summary: "Rule Composer+ warming up." };
    const report = STATE.lastReportIntelligence || { healthBand: "WARMING", reportGrade: "--", reportScore: 0, confidence: 0, executiveSummary: "Report Intelligence+ warming up." };
    const timeline = STATE.lastTimelineIntelligence || computeTimelineIntelligence(false, "panel") || { status: "WARMING", momentum: "STABLE", volatilityScore: 0, riskDelta: 0, eventCount: 0, summary: "Timeline Intelligence+ warming up." };
    const causal = STATE.lastCausalGuard || computeCausalGuard(false, "panel") || { status: "WARMING", causalConfidence: 0, primaryCause: null, summary: "Causal Guard+ warming up." };
    const evidenceGraph = STATE.lastEvidenceGraph || computeEvidenceGraph(false, "panel") || { status: "WARMING", graphConfidence: 0, nodeCount: 0, edgeCount: 0, healthBand: "WARMING", summary: "Evidence Graph+ warming up." };
    const counterfactual = STATE.lastCounterfactualGuard || computeCounterfactualGuard(false, "panel") || { status: "WARMING", counterfactualConfidence: 0, bestScenario: null, avoidedRiskEstimate: 0, summary: "Counterfactual Guard+ warming up." };
    const trust = STATE.lastTrustCalibration || { effectiveTrustLevel: (STATE.siteProfile && STATE.siteProfile.trustLevel) || (STATE.siteProfile && STATE.siteProfile.trusted ? "trusted" : "local"), trustScore: 50, policyHint: STATE.settings.policyMode || "balanced", summary: "Trust Calibration+ and Report Intelligence+ and Timeline Intelligence+ and Causal Guard+ and Evidence Graph+ and Counterfactual Guard+ warming up." };
    const trusted = STATE.siteProfile && STATE.siteProfile.trusted;
    const reason = risk.reasons && risk.reasons[0] ? risk.reasons[0] : "Local heuristic scan active.";
    const rec = agent.recommendations && agent.recommendations[0] ? agent.recommendations[0].title : agent.summary;

    if (STATE.settings.compactOverlay) {
      panel.innerHTML = `<div style="font-weight:700;color:#8fc7ff;">AETHERION v18 ${trusted ? "✅" : ""}</div><div>${riskEmoji(risk.level)} ${risk.score}/100 · ${escapeHTML(agent.stance)} · A:${plan.actions ? plan.actions.length : 0} · P:${policy.autoActions ? policy.autoActions.length : 0} · I:${escapeHTML(intel.reputationLevel || "NEW")} · L:${escapeHTML((learning.learningClass || "LEARN").slice(0,10))} · T:${escapeHTML((trust.effectiveTrustLevel || "local").slice(0,9))} · R:${rules.matchedRules ? rules.matchedRules.length : 0} · G:${evidenceGraph.nodeCount || 0}/${evidenceGraph.edgeCount || 0} · CF:${counterfactual.counterfactualConfidence || 0}%</div>`;
    } else {
      panel.innerHTML = `
        <div style="font-weight:700;letter-spacing:.08em;color:#8fc7ff;">AETHERION v18 ${trusted ? "✅" : ""}</div>
        <div>${riskEmoji(risk.level)} Risk: <b>${risk.score}</b>/100 · ${risk.level}</div>
        <div>Agent: <b>${escapeHTML(agent.stance)}</b> · ${agent.confidence || 0}%</div>
        <div>Planner: <b>${escapeHTML(plan.status || "READY")}</b> · ${plan.actions ? plan.actions.length : 0} action(s)</div>
        <div>Policy: <b>${escapeHTML(policy.status || "ACTIVE")}</b> · auto ${policy.autoActions ? policy.autoActions.length : 0} · blocked ${policy.blockedActions ? policy.blockedActions.length : 0}</div>
        <div>Intel: <b>${escapeHTML(intel.reputationLevel || "NEW")}</b> · ${escapeHTML(intel.trendDirection || "NEW")} · hint ${escapeHTML(intel.policyHint || "balanced")}</div>
        <div>Learn: <b>${escapeHTML(learning.learningClass || "WARMING_UP")}</b> · ${learning.confidence || 0}% · hint ${escapeHTML(learning.policyHint || "balanced")}</div>
        <div>Trust: <b>${escapeHTML(trust.effectiveTrustLevel || "local")}</b> · score ${trust.trustScore ?? "--"} · ${escapeHTML(trust.policyHint || "balanced")}</div>
        <div>Report: <b>${escapeHTML(report.healthBand || "WARMING")}</b> · grade ${escapeHTML(report.reportGrade || "--")} · ${report.reportScore ?? "--"}/100</div>
        <div>Timeline: <b>${escapeHTML(timeline.status || "WARMING")}</b> · Δ ${timeline.riskDelta ?? 0} · vol ${timeline.volatilityScore ?? 0}</div>
        <div>Causal: <b>${escapeHTML(causal.status || "WARMING")}</b> · ${causal.causalConfidence ?? 0}% · ${escapeHTML(causal.primaryCause && causal.primaryCause.type || "none")}</div>
        <div>Graph: <b>${escapeHTML(evidenceGraph.healthBand || "WARMING")}</b> · ${evidenceGraph.graphConfidence ?? 0}% · N ${evidenceGraph.nodeCount || 0}/E ${evidenceGraph.edgeCount || 0}</div>
        <div>Counterfactual: <b>${escapeHTML(counterfactual.healthBand || counterfactual.status || "WARMING")}</b> · ${counterfactual.counterfactualConfidence ?? 0}% · avoid ${counterfactual.avoidedRiskEstimate ?? 0}</div>
        <div>Rules: <b>${escapeHTML(rules.status || "WARMING")}</b> · matched ${rules.matchedRules ? rules.matchedRules.length : 0}/${rules.allRulesCount || 0}</div>
        <div>DOM: ${STATE.mutationCount} · Anom: ${STATE.anomalyCount}</div>
        <div>Clicks: ${STATE.userEvents.clicks} · Scrolls: ${STATE.userEvents.scrolls} · Keys: ${STATE.userEvents.keys}</div>
        <div style="opacity:.78;margin-top:4px;">${escapeHTML(rec).slice(0, 96)}</div>
        <div style="opacity:.58;margin-top:3px;">${escapeHTML(reason).slice(0, 96)}</div>
      `;
    }
    renderGuardBanner();
  }

  function computeRisk(force) {
    const now = Date.now();
    if (!force && now - STATE.lastRiskComputeAt < 1200) return STATE.lastRisk;
    STATE.lastRiskComputeAt = now;
    if (!window.AetherionRiskEngine) return null;
    STATE.lastRisk = window.AetherionRiskEngine.computeRisk({
      mutations: STATE.mutationCount,
      anomalies: STATE.anomalyCount,
      userEvents: STATE.userEvents,
      settings: STATE.settings,
      profile: STATE.siteProfile
    });
    return STATE.lastRisk;
  }


  function buildIntelligenceSnapshot() {
    const risk = STATE.lastRisk || { score: 0, level: "UNKNOWN", signals: {}, categories: {}, reasons: [] };
    return {
      site: hostname(),
      url: location.href,
      title: document.title || "",
      startedAt: new Date(STATE.startedAt).toISOString(),
      durationMs: Date.now() - STATE.startedAt,
      mutations: STATE.mutationCount,
      anomalies: STATE.anomalyCount,
      riskScore: risk.score,
      riskLevel: risk.level,
      riskReasons: risk.reasons || [],
      riskCategories: risk.categories || {},
      signals: risk.signals || {},
      userEvents: Object.assign({}, STATE.userEvents),
      causalGuard: STATE.lastCausalGuard || null,
      evidenceGraph: STATE.lastEvidenceGraph || null,
      counterfactualGuard: STATE.lastCounterfactualGuard || null,
      version: "18.0.0"
    };
  }

  function computeSiteIntelligence(force) {
    const now = Date.now();
    if (!force && STATE.lastSiteIntelligence && now - STATE.lastSiteIntelComputeAt < 2400) return STATE.lastSiteIntelligence;
    STATE.lastSiteIntelComputeAt = now;
    if (!window.AetherionSiteIntelligence || STATE.settings.siteIntelligenceEnabled === false) return STATE.lastSiteIntelligence;
    const risk = computeRisk(true) || { score: 0, level: "LOW", reasons: [], signals: {}, categories: {} };
    STATE.lastSiteIntelligence = window.AetherionSiteIntelligence.analyze({ snapshot: buildIntelligenceSnapshot(), risk, profile: STATE.siteProfile || {}, settings: STATE.settings });
    return STATE.lastSiteIntelligence;
  }



  function computeLearningProfile(force) {
    const now = Date.now();
    if (!force && STATE.lastLearningProfile && now - STATE.lastLearningComputeAt < 2600) return STATE.lastLearningProfile;
    STATE.lastLearningComputeAt = now;
    if (!window.AetherionLearningProfiles || STATE.settings.learningProfilesEnabled === false) return STATE.lastLearningProfile;
    const risk = computeRisk(true) || { score: 0, level: "LOW", reasons: [], signals: {}, categories: {} };
    const intel = computeSiteIntelligence(false) || STATE.lastSiteIntelligence;
    STATE.lastLearningProfile = window.AetherionLearningProfiles.learn({ snapshot: buildIntelligenceSnapshot(), risk, profile: STATE.siteProfile || {}, siteIntelligence: intel, settings: STATE.settings });
    return STATE.lastLearningProfile;
  }

  function computeTrustCalibration(force) {
    const now = Date.now();
    if (!force && STATE.lastTrustCalibration && now - STATE.lastTrustComputeAt < 2300) return STATE.lastTrustCalibration;
    STATE.lastTrustComputeAt = now;
    if (!window.AetherionTrustCalibration || STATE.settings.trustCalibrationEnabled === false) return STATE.lastTrustCalibration;
    const risk = computeRisk(true) || { score: 0, level: "LOW", reasons: [], signals: {}, categories: {} };
    const intel = computeSiteIntelligence(false) || STATE.lastSiteIntelligence;
    const learning = computeLearningProfile(false) || STATE.lastLearningProfile;
    STATE.lastTrustCalibration = window.AetherionTrustCalibration.calibrate({ snapshot: buildIntelligenceSnapshot(), risk, profile: STATE.siteProfile || {}, siteIntelligence: intel, learningProfile: learning, settings: STATE.settings });
    return STATE.lastTrustCalibration;
  }



  function computeRuleDecision(force) {
    const now = Date.now();
    if (!force && STATE.lastRuleDecision && now - STATE.lastRuleComputeAt < 2200) return STATE.lastRuleDecision;
    STATE.lastRuleComputeAt = now;
    if (!window.AetherionRuleComposer || STATE.settings.ruleComposerEnabled === false) {
      STATE.lastRuleDecision = { status: "DISABLED", matchedRules: [], allRulesCount: STATE.rules.length, enabledRulesCount: 0, settingsPatch: {}, blockedActionTypes: [], summary: "Rule Composer+ disabled." };
      return STATE.lastRuleDecision;
    }
    const risk = STATE.lastRisk || computeRisk(true) || { score: 0, level: "LOW", reasons: [], signals: {}, categories: {} };
    const intel = STATE.lastSiteIntelligence || computeSiteIntelligence(false);
    const learning = STATE.lastLearningProfile || computeLearningProfile(false);
    STATE.lastRuleDecision = window.AetherionRuleComposer.evaluate(STATE.rules, {
      site: hostname(),
      url: location.href,
      settings: STATE.settings,
      profile: STATE.siteProfile || {},
      risk,
      siteIntelligence: intel,
      learningProfile: learning,
      trustCalibration: STATE.lastTrustCalibration || computeTrustCalibration(false)
    });
    return STATE.lastRuleDecision;
  }

  function activeSettings() {
    const rule = STATE.lastRuleDecision || computeRuleDecision(false);
    const trust = STATE.lastTrustCalibration || computeTrustCalibration(false);
    return Object.assign({}, STATE.settings, trust && trust.settingsPatch ? trust.settingsPatch : {}, rule && rule.settingsPatch ? rule.settingsPatch : {});
  }

  function computeAgent(force) {
    const now = Date.now();
    if (!force && now - STATE.lastAgentComputeAt < 1800) return STATE.lastAgentDecision;
    STATE.lastAgentComputeAt = now;
    if (!window.AetherionAgentEngine || STATE.settings.agentEnabled === false) return null;
    const risk = computeRisk(true) || { score: 0, level: "LOW", reasons: [], signals: {}, categories: {} };
    computeLearningProfile(false);
    computeTrustCalibration(false);
    const snapshot = buildSessionSnapshot(false, false, false);
    computeRuleDecision(false);
    STATE.lastAgentDecision = window.AetherionAgentEngine.decide({ snapshot, risk, profile: STATE.siteProfile, settings: activeSettings() });
    return STATE.lastAgentDecision;
  }

  function computeActionPlan(force) {
    const now = Date.now();
    if (!force && now - STATE.lastPlanComputeAt < 2200) return STATE.lastActionPlan;
    STATE.lastPlanComputeAt = now;
    if (!window.AetherionActionPlanner) return null;
    const risk = computeRisk(true) || { score: 0, level: "LOW", reasons: [], signals: {}, categories: {} };
    const agent = computeAgent(true) || STATE.lastAgentDecision;
    const snapshot = buildSessionSnapshot(false, false, false);
    computeRuleDecision(false);
    STATE.lastActionPlan = window.AetherionActionPlanner.makePlan({ snapshot, risk, agent, profile: STATE.siteProfile, settings: activeSettings() });
    return STATE.lastActionPlan;
  }



  function strongerPolicyMode(currentMode, hintMode) {
    const order = { observe: 0, balanced: 1, protective: 2, strict: 3 };
    const current = currentMode || "balanced";
    const hint = hintMode || current;
    return (order[hint] || 0) > (order[current] || 0) ? hint : current;
  }

  function computePolicy(force) {
    const now = Date.now();
    if (!force && STATE.lastPolicyDecision && now - STATE.lastPlanComputeAt < 2400) return STATE.lastPolicyDecision;
    if (!window.AetherionPolicyEngine) return null;
    const risk = computeRisk(true) || { score: 0, level: "LOW", reasons: [], signals: {}, categories: {} };
    const agent = computeAgent(true) || STATE.lastAgentDecision;
    const plan = computeActionPlan(true) || STATE.lastActionPlan || { actions: [] };
    const intel = computeSiteIntelligence(false) || STATE.lastSiteIntelligence;
    const learning = computeLearningProfile(false) || STATE.lastLearningProfile;
    const trust = computeTrustCalibration(false) || STATE.lastTrustCalibration;
    const snapshot = buildSessionSnapshot(false, false, false);
    const ruleDecision = computeRuleDecision(false);
    const policySettings = Object.assign({}, STATE.settings, trust && trust.settingsPatch ? trust.settingsPatch : {}, ruleDecision && ruleDecision.settingsPatch ? ruleDecision.settingsPatch : {});
    policySettings.ruleComposerDecision = ruleDecision || null;
    policySettings.trustCalibrationDecision = trust || null;
    if (policySettings.adaptivePolicyHints !== false && trust && trust.policyHint) {
      policySettings.policyMode = strongerPolicyMode(policySettings.policyMode || "balanced", trust.policyHint);
    }
    if (policySettings.adaptivePolicyHints !== false && intel && intel.policyHint) {
      policySettings.policyMode = strongerPolicyMode(policySettings.policyMode || "balanced", intel.policyHint);
    }
    if (policySettings.adaptivePolicyHints !== false && learning && learning.policyHint) {
      policySettings.policyMode = strongerPolicyMode(policySettings.policyMode || "balanced", learning.policyHint);
    }
    STATE.lastPolicyDecision = window.AetherionPolicyEngine.evaluate({ snapshot, risk, agent, plan, profile: STATE.siteProfile, settings: policySettings });
    if (STATE.lastPolicyDecision && intel) {
      STATE.lastPolicyDecision.sitePolicyHint = intel.policyHint;
      STATE.lastPolicyDecision.learningPolicyHint = learning && learning.policyHint;
      STATE.lastPolicyDecision.learningClass = learning && learning.learningClass;
      STATE.lastPolicyDecision.trustPolicyHint = trust && trust.policyHint;
      STATE.lastPolicyDecision.trustLevel = trust && trust.effectiveTrustLevel;
      STATE.lastPolicyDecision.trustCalibration = trust || null;
      STATE.lastPolicyDecision.ruleDecision = ruleDecision || null;
      STATE.lastPolicyDecision.effectivePolicyMode = policySettings.policyMode;
    }
    return STATE.lastPolicyDecision;
  }



  function computeReportIntelligence(force) {
    const now = Date.now();
    if (!force && STATE.lastReportIntelligence && now - STATE.lastReportComputeAt < 2600) return STATE.lastReportIntelligence;
    STATE.lastReportComputeAt = now;
    if (!window.AetherionReportIntelligence || STATE.settings.reportIntelligenceEnabled === false) return STATE.lastReportIntelligence || null;
    const risk = STATE.lastRisk || computeRisk(true) || { score: 0, level: "UNKNOWN", reasons: [], signals: {}, categories: {} };
    const snapshot = {
      site: hostname(),
      url: location.href,
      title: document.title || "",
      startedAt: new Date(STATE.startedAt).toISOString(),
      durationMs: Date.now() - STATE.startedAt,
      mutations: STATE.mutationCount,
      anomalies: STATE.anomalyCount,
      riskScore: risk.score,
      riskLevel: risk.level,
      riskReasons: risk.reasons || [],
      riskCategories: risk.categories || {},
      signals: risk.signals || {},
      agentDecision: STATE.lastAgentDecision || null,
      actionPlan: STATE.lastActionPlan || null,
      policyDecision: STATE.lastPolicyDecision || null,
      siteIntelligence: STATE.lastSiteIntelligence || computeSiteIntelligence(false) || null,
      learningProfile: STATE.lastLearningProfile || computeLearningProfile(false) || null,
      trustCalibration: STATE.lastTrustCalibration || computeTrustCalibration(false) || null,
      ruleDecision: STATE.lastRuleDecision || computeRuleDecision(false) || null,
      appliedActions: STATE.appliedActions.slice(-20),
      userEvents: Object.assign({}, STATE.userEvents),
      version: "18.0.0"
    };
    STATE.lastReportIntelligence = window.AetherionReportIntelligence.buildReport({
      snapshot,
      profile: STATE.siteProfile,
      settings: activeSettings()
    });
    return STATE.lastReportIntelligence;
  }


  function captureTimelinePoint(trigger) {
    if (!window.AetherionTimelineIntelligence || STATE.settings.timelineIntelligenceEnabled === false) return null;
    const now = Date.now();
    if (now - STATE.lastTimelinePointAt < 900 && trigger !== "force" && trigger !== "save") {
      return STATE.timelinePoints[STATE.timelinePoints.length - 1] || null;
    }
    const risk = STATE.lastRisk || computeRisk(true) || { score: 0, level: "UNKNOWN", reasons: [], signals: {}, categories: {} };
    const snapshot = buildIntelligenceSnapshot();
    const previousPoint = STATE.timelinePoints[STATE.timelinePoints.length - 1] || null;
    const point = window.AetherionTimelineIntelligence.capturePoint({
      trigger: trigger || "sample",
      snapshot,
      risk,
      previousPoint,
      settings: activeSettings()
    });
    if (point) {
      STATE.timelinePoints.push(point);
      STATE.timelinePoints = STATE.timelinePoints.slice(-80);
      STATE.lastTimelinePointAt = now;
    }
    return point;
  }

  function computeTimelineIntelligence(force, trigger) {
    const now = Date.now();
    if (!force && STATE.lastTimelineIntelligence && now - STATE.lastTimelineComputeAt < 1800) return STATE.lastTimelineIntelligence;
    STATE.lastTimelineComputeAt = now;
    if (!window.AetherionTimelineIntelligence || STATE.settings.timelineIntelligenceEnabled === false) return STATE.lastTimelineIntelligence || null;
    if (force || !STATE.timelinePoints.length || STATE.settings.timelineAutoCapture !== false) captureTimelinePoint(trigger || "sample");
    const risk = STATE.lastRisk || computeRisk(true) || { score: 0, level: "UNKNOWN", reasons: [], signals: {}, categories: {} };
    STATE.lastTimelineIntelligence = window.AetherionTimelineIntelligence.analyze({
      points: STATE.timelinePoints,
      snapshot: buildIntelligenceSnapshot(),
      risk,
      siteIntelligence: STATE.lastSiteIntelligence || null,
      learningProfile: STATE.lastLearningProfile || null,
      trustCalibration: STATE.lastTrustCalibration || null,
      policyDecision: STATE.lastPolicyDecision || null,
      actionPlan: STATE.lastActionPlan || null,
      reportIntelligence: STATE.lastReportIntelligence || null,
      settings: activeSettings()
    });
    return STATE.lastTimelineIntelligence;
  }



  function computeCausalGuard(force, trigger) {
    const now = Date.now();
    if (!force && STATE.lastCausalGuard && now - STATE.lastCausalComputeAt < 2100) return STATE.lastCausalGuard;
    STATE.lastCausalComputeAt = now;
    if (!window.AetherionCausalGuard || STATE.settings.causalGuardEnabled === false) return STATE.lastCausalGuard || null;
    const risk = STATE.lastRisk || computeRisk(true) || { score: 0, level: "UNKNOWN", reasons: [], signals: {}, categories: {} };
    const timeline = computeTimelineIntelligence(force, trigger || "causal") || STATE.lastTimelineIntelligence || null;
    STATE.lastCausalGuard = window.AetherionCausalGuard.analyze({
      snapshot: buildIntelligenceSnapshot(),
      risk,
      points: STATE.timelinePoints,
      timelineIntelligence: timeline,
      siteIntelligence: STATE.lastSiteIntelligence || null,
      learningProfile: STATE.lastLearningProfile || null,
      trustCalibration: STATE.lastTrustCalibration || null,
      policyDecision: STATE.lastPolicyDecision || null,
      actionPlan: STATE.lastActionPlan || null,
      reportIntelligence: STATE.lastReportIntelligence || null,
      profile: STATE.siteProfile || {},
      settings: activeSettings()
    });
    return STATE.lastCausalGuard;
  }


  function computeEvidenceGraph(force, trigger) {
    const now = Date.now();
    if (!force && STATE.lastEvidenceGraph && now - STATE.lastEvidenceGraphComputeAt < 2400) return STATE.lastEvidenceGraph;
    STATE.lastEvidenceGraphComputeAt = now;
    if (!window.AetherionEvidenceGraph || STATE.settings.evidenceGraphEnabled === false) return STATE.lastEvidenceGraph;
    const risk = computeRisk(true) || { score: 0, level: "LOW", reasons: [], signals: {}, categories: {} };
    const timeline = STATE.lastTimelineIntelligence || computeTimelineIntelligence(false, trigger || "graph");
    const causal = STATE.lastCausalGuard || computeCausalGuard(false, trigger || "graph");
    const report = STATE.lastReportIntelligence || computeReportIntelligence(false);
    STATE.lastEvidenceGraph = window.AetherionEvidenceGraph.build({
      snapshot: buildIntelligenceSnapshot(),
      risk,
      timelineIntelligence: timeline,
      causalGuard: causal,
      reportIntelligence: report,
      policyDecision: STATE.lastPolicyDecision || null,
      actionPlan: STATE.lastActionPlan || null,
      agentDecision: STATE.lastAgentDecision || null,
      trustCalibration: STATE.lastTrustCalibration || null,
      siteIntelligence: STATE.lastSiteIntelligence || null,
      learningProfile: STATE.lastLearningProfile || null,
      appliedActions: STATE.appliedActions || [],
      profile: STATE.siteProfile || {},
      settings: activeSettings()
    });
    return STATE.lastEvidenceGraph;
  }

  function computeCounterfactualGuard(force, trigger) {
    const now = Date.now();
    if (!force && STATE.lastCounterfactualGuard && now - STATE.lastCounterfactualComputeAt < 2600) return STATE.lastCounterfactualGuard;
    STATE.lastCounterfactualComputeAt = now;
    if (!window.AetherionCounterfactualGuard || STATE.settings.counterfactualGuardEnabled === false) return STATE.lastCounterfactualGuard || null;
    const risk = computeRisk(true) || { score: 0, level: "LOW", reasons: [], signals: {}, categories: {} };
    const timeline = STATE.lastTimelineIntelligence || computeTimelineIntelligence(false, trigger || "counterfactual");
    const causal = STATE.lastCausalGuard || computeCausalGuard(false, trigger || "counterfactual");
    const graph = STATE.lastEvidenceGraph || computeEvidenceGraph(false, trigger || "counterfactual");
    STATE.lastCounterfactualGuard = window.AetherionCounterfactualGuard.analyze({
      snapshot: buildIntelligenceSnapshot(),
      risk,
      timelineIntelligence: timeline,
      causalGuard: causal,
      evidenceGraph: graph,
      reportIntelligence: STATE.lastReportIntelligence || null,
      policyDecision: STATE.lastPolicyDecision || null,
      actionPlan: STATE.lastActionPlan || null,
      agentDecision: STATE.lastAgentDecision || null,
      trustCalibration: STATE.lastTrustCalibration || null,
      siteIntelligence: STATE.lastSiteIntelligence || null,
      learningProfile: STATE.lastLearningProfile || null,
      appliedActions: STATE.appliedActions || [],
      profile: STATE.siteProfile || {},
      settings: activeSettings()
    });
    return STATE.lastCounterfactualGuard;
  }

  async function savePolicy(reason) {
    if (!window.AetherionMemory || !window.AetherionMemory.savePolicyDecision || !STATE.lastPolicyDecision) return null;
    return window.AetherionMemory.savePolicyDecision(STATE.lastPolicyDecision, {
      reason: reason || "policy",
      riskScore: STATE.lastRisk && STATE.lastRisk.score,
      riskLevel: STATE.lastRisk && STATE.lastRisk.level,
      actionCount: STATE.lastActionPlan && STATE.lastActionPlan.actions ? STATE.lastActionPlan.actions.length : 0
    });
  }

  async function runAutoMode(reason) {
    const now = Date.now();
    if (!STATE.settings.autoModeEnabled || !window.AetherionPolicyEngine) return null;
    if (now - STATE.lastAutoModeAt < 6500) return null;
    STATE.lastAutoModeAt = now;
    computeRisk(true); computeSiteIntelligence(true); computeLearningProfile(true); computeTrustCalibration(true); computeRuleDecision(true); computeAgent(true); computeActionPlan(true); computePolicy(true); computeReportIntelligence(true); computeTimelineIntelligence(true, "auto_mode"); computeCausalGuard(true, "auto_mode"); computeEvidenceGraph(true, "auto_mode"); computeCounterfactualGuard(true, "auto_mode");
    const policy = STATE.lastPolicyDecision;
    const plan = STATE.lastActionPlan || { actions: [] };
    if (!policy || !Array.isArray(policy.autoActions) || !policy.autoActions.length) return { ok: true, applied: 0, reason: "no_policy_auto_actions" };
    const applied = [];
    for (const autoDecision of policy.autoActions.slice(0, 2)) {
      const action = (plan.actions || []).find((item) => item.id === autoDecision.id || item.type === autoDecision.type);
      if (!action || action.type === "NOOP") continue;
      const key = [hostname(), action.id || action.type, action.type === "SAVE_SESSION" ? Math.floor(now / 60000) : "page"].join("|");
      if (STATE.autoAppliedActionIds[key]) continue;
      const permit = window.AetherionPolicyEngine.canAutoApplyAction(action, policy, { reason: reason || "auto_mode" });
      if (!permit.allowed) continue;
      STATE.autoAppliedActionIds[key] = true;
      const result = await applyAction(action.id || action.type, { auto: true, policyPermit: permit });
      applied.push({ action: action.type, ok: result && result.ok, message: result && result.message });
    }
    if (applied.length) await savePolicy(reason || "auto_mode");
    return { ok: true, applied: applied.length, actions: applied };
  }

  function handleMutationBurst(mutations) {
    const now = Date.now();
    const elapsed = now - STATE.burstWindowStartedAt;
    STATE.burstMutationCount += mutations.length;
    if (elapsed >= 1000) {
      const highThreshold = Number(STATE.settings.highMutationThreshold || 120);
      if (STATE.burstMutationCount > highThreshold) {
        STATE.anomalyCount += 1;
        STATE.lastMutationBurstAt = now;
      }
      STATE.burstMutationCount = 0;
      STATE.burstWindowStartedAt = now;
    }
  }

  function attachMutationObserver() {
    const target = document.body || document.documentElement;
    if (!target || typeof MutationObserver === "undefined") return null;
    const observer = new MutationObserver((mutations) => {
      STATE.mutationCount += mutations.length;
      handleMutationBurst(mutations);
      computeRisk(false);
      computeSiteIntelligence(false);
      computeLearningProfile(false);
      computeRuleDecision(false);
      computeAgent(false);
      computeActionPlan(false);
      computePolicy(false);
      runAutoMode("mutation");
      computeTimelineIntelligence(false, "mutation");
      computeCausalGuard(false, "mutation"); computeEvidenceGraph(false, "mutation"); computeCounterfactualGuard(false, "mutation");
      renderPanel();
    });
    observer.observe(target, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["class", "style", "src", "href", "hidden", "aria-hidden", "target", "download"]
    });
    return observer;
  }

  function isExternalUrl(urlLike) {
    try {
      const url = new URL(urlLike, location.href);
      const a = url.hostname.replace(/^www\./, "");
      const b = location.hostname.replace(/^www\./, "");
      return a !== b && !a.endsWith("." + b) && !b.endsWith("." + a);
    } catch (_) { return false; }
  }

  function attachUserEventSensors() {
    document.addEventListener("click", (event) => {
      STATE.userEvents.clicks += 1;
      const target = event.target && event.target.closest ? event.target.closest("a[href]") : null;
      if (target) {
        const href = target.getAttribute("href") || "";
        if (target.download || /\.(apk|exe|msi|scr|bat|cmd|ps1|vbs|jar)([?#].*)?$/i.test(href)) STATE.userEvents.downloadsClicked += 1;
        if (isExternalUrl(href)) STATE.userEvents.externalLinksClicked += 1;
      }
      computeSiteIntelligence(false);
      computeLearningProfile(false);
      computeRuleDecision(false);
      computeAgent(false);
      computeActionPlan(false);
      computePolicy(false);
      runAutoMode("mutation");
      computeTimelineIntelligence(false, "mutation");
      computeCausalGuard(false, "mutation"); computeEvidenceGraph(false, "mutation"); computeCounterfactualGuard(false, "mutation");
      renderPanel();
    }, { capture: true, passive: true });

    let lastScroll = 0;
    document.addEventListener("scroll", () => {
      const now = Date.now();
      if (now - lastScroll > 500) {
        STATE.userEvents.scrolls += 1;
        lastScroll = now;
        computeTimelineIntelligence(false, "scroll");
        computeCausalGuard(false, "scroll"); computeEvidenceGraph(false, "scroll"); computeCounterfactualGuard(false, "scroll");
        renderPanel();
      }
    }, { capture: true, passive: true });

    document.addEventListener("keydown", () => { STATE.userEvents.keys += 1; computeTimelineIntelligence(false, "keydown"); computeCausalGuard(false, "keydown"); computeEvidenceGraph(false, "keydown"); computeCounterfactualGuard(false, "keydown"); renderPanel(); }, { capture: true, passive: true });

    document.addEventListener("focusin", (event) => {
      const target = event.target;
      if (!target || !target.matches) return;
      if (target.matches("input, textarea, select")) STATE.userEvents.formsFocused += 1;
      if (target.matches('input[type="password"]')) STATE.userEvents.passwordFieldsFocused += 1;
      computeSiteIntelligence(true);
      computeLearningProfile(true);
      computeTrustCalibration(true);
      computeRuleDecision(true);
      computeAgent(true);
      computeActionPlan(true);
      computePolicy(true);
      computeTimelineIntelligence(true, "focus");
      computeCausalGuard(true, "focus"); computeEvidenceGraph(true, "focus"); computeCounterfactualGuard(true, "focus");
      renderPanel();
    }, { capture: true, passive: true });
  }

  function buildSessionSnapshot(includeAgent, includePlan, includePolicy) {
    const risk = computeRisk(true) || { score: 0, level: "UNKNOWN", reasons: [], signals: {}, categories: {} };
    let agentDecision = STATE.lastAgentDecision;
    if (includeAgent !== false) agentDecision = computeAgent(true) || agentDecision;
    let actionPlan = STATE.lastActionPlan;
    if (includePlan !== false) actionPlan = computeActionPlan(true) || actionPlan;
    let policyDecision = STATE.lastPolicyDecision;
    if (includePolicy !== false && window.AetherionPolicyEngine) policyDecision = computePolicy(true) || policyDecision;
    return {
      site: hostname(),
      url: location.href,
      title: document.title || "",
      startedAt: new Date(STATE.startedAt).toISOString(),
      durationMs: Date.now() - STATE.startedAt,
      mutations: STATE.mutationCount,
      anomalies: STATE.anomalyCount,
      riskScore: risk.score,
      riskLevel: risk.level,
      riskReasons: risk.reasons || [],
      riskCategories: risk.categories || {},
      signals: risk.signals || {},
      agentDecision: agentDecision || null,
      actionPlan: actionPlan || null,
      policyDecision: policyDecision || null,
      siteIntelligence: computeSiteIntelligence(false) || STATE.lastSiteIntelligence || null,
      learningProfile: computeLearningProfile(false) || STATE.lastLearningProfile || null,
      trustCalibration: computeTrustCalibration(false) || STATE.lastTrustCalibration || null,
      ruleDecision: computeRuleDecision(false) || STATE.lastRuleDecision || null,
      reportIntelligence: computeReportIntelligence(false) || STATE.lastReportIntelligence || null,
      timelineIntelligence: computeTimelineIntelligence(false, "snapshot") || STATE.lastTimelineIntelligence || null,
      causalGuard: computeCausalGuard(false, "snapshot") || STATE.lastCausalGuard || null,
      evidenceGraph: computeEvidenceGraph(false, "snapshot") || STATE.lastEvidenceGraph || null,
      counterfactualGuard: computeCounterfactualGuard(false, "snapshot") || STATE.lastCounterfactualGuard || null,
      appliedActions: STATE.appliedActions.slice(-20),
      userEvents: Object.assign({}, STATE.userEvents),
      version: "18.0.0"
    };
  }

  async function saveSession(reason) {
    if (!window.AetherionMemory || !window.AetherionMemory.saveSession) return null;
    const snapshot = buildSessionSnapshot(true, true);
    snapshot.saveReason = reason || "manual";
    const saved = await window.AetherionMemory.saveSession(snapshot);
    if (snapshot.agentDecision && window.AetherionMemory.saveAgentDecision) {
      await window.AetherionMemory.saveAgentDecision(snapshot.agentDecision, {
        reason: snapshot.saveReason,
        riskScore: snapshot.riskScore,
        riskLevel: snapshot.riskLevel,
        actionCount: snapshot.actionPlan && snapshot.actionPlan.actions ? snapshot.actionPlan.actions.length : 0
      });
    }
    if (snapshot.policyDecision && window.AetherionMemory.savePolicyDecision) {
      await window.AetherionMemory.savePolicyDecision(snapshot.policyDecision, { reason: snapshot.saveReason, riskScore: snapshot.riskScore, riskLevel: snapshot.riskLevel });
    }
    if (snapshot.siteIntelligence && window.AetherionMemory.saveSiteIntelligence) {
      await window.AetherionMemory.saveSiteIntelligence(snapshot.siteIntelligence, { reason: snapshot.saveReason, riskScore: snapshot.riskScore, riskLevel: snapshot.riskLevel });
    }
    if (snapshot.learningProfile && window.AetherionMemory.saveLearningProfile) {
      await window.AetherionMemory.saveLearningProfile(snapshot.learningProfile, { reason: snapshot.saveReason, riskScore: snapshot.riskScore, riskLevel: snapshot.riskLevel });
    }
    if (snapshot.trustCalibration && window.AetherionMemory.saveTrustCalibration) {
      await window.AetherionMemory.saveTrustCalibration(snapshot.trustCalibration, { reason: snapshot.saveReason, riskScore: snapshot.riskScore, riskLevel: snapshot.riskLevel });
    }
    if (snapshot.reportIntelligence && window.AetherionMemory.saveReportIntelligence) {
      await window.AetherionMemory.saveReportIntelligence(snapshot.reportIntelligence, { reason: snapshot.saveReason, riskScore: snapshot.riskScore, riskLevel: snapshot.riskLevel });
    }
    if (snapshot.timelineIntelligence && window.AetherionMemory.saveTimelineIntelligence) {
      await window.AetherionMemory.saveTimelineIntelligence(snapshot.timelineIntelligence, { reason: snapshot.saveReason, riskScore: snapshot.riskScore, riskLevel: snapshot.riskLevel });
    }
    if (snapshot.causalGuard && window.AetherionMemory.saveCausalGuard) {
      await window.AetherionMemory.saveCausalGuard(snapshot.causalGuard, { reason: snapshot.saveReason, riskScore: snapshot.riskScore, riskLevel: snapshot.riskLevel });
    }
    if (snapshot.evidenceGraph && window.AetherionMemory.saveEvidenceGraph) {
      await window.AetherionMemory.saveEvidenceGraph(snapshot.evidenceGraph, { reason: snapshot.saveReason, riskScore: snapshot.riskScore, riskLevel: snapshot.riskLevel });
    }
    if (snapshot.counterfactualGuard && window.AetherionMemory.saveCounterfactualGuard) {
      await window.AetherionMemory.saveCounterfactualGuard(snapshot.counterfactualGuard, { reason: snapshot.saveReason, riskScore: snapshot.riskScore, riskLevel: snapshot.riskLevel });
    }
    STATE.siteProfile = await window.AetherionMemory.getSiteProfile(hostname());
    computeRisk(true); computeSiteIntelligence(true); computeLearningProfile(true); computeTrustCalibration(true); computeRuleDecision(true); computeAgent(true); computeActionPlan(true); computePolicy(true); computeReportIntelligence(true); computeTimelineIntelligence(true, "auto_mode"); computeCausalGuard(true, "auto_mode"); computeEvidenceGraph(true, "auto_mode"); computeCounterfactualGuard(true, "auto_mode"); computeTimelineIntelligence(true, "refresh"); computeCausalGuard(true, "refresh"); computeEvidenceGraph(true, "refresh"); computeCounterfactualGuard(true, "refresh"); renderPanel();
    return saved;
  }

  function visibleRect(el) {
    const rect = el.getBoundingClientRect();
    return { width: rect.width, height: rect.height, top: rect.top, left: rect.left, area: Math.max(0, rect.width) * Math.max(0, rect.height) };
  }

  function candidateOverlayNodes(maxNodes) {
    const nodes = Array.from(document.querySelectorAll("body *")).filter((node) => {
      if (!node || !node.style || node.id === PANEL_ID || node.id === BANNER_ID || node.closest && node.closest("#" + PANEL_ID + ",#" + BANNER_ID)) return false;
      const cs = window.getComputedStyle(node);
      if (!cs || !["fixed", "sticky"].includes(cs.position)) return false;
      const rect = visibleRect(node);
      const viewport = Math.max(1, window.innerWidth * window.innerHeight);
      const areaRatio = rect.area / viewport;
      const z = parseInt(cs.zIndex, 10);
      const text = (node.innerText || "").toLowerCase().slice(0, 500);
      const hasOverlayWords = /cookie|subscribe|sign up|login|newsletter|accept|allow|continue|ad|promo|offer|limited|consent/.test(text);
      return areaRatio > 0.10 || Number.isFinite(z) && z > 999 || hasOverlayWords;
    });
    return nodes.slice(0, Math.max(1, maxNodes || 8));
  }

  function hideIntrusiveOverlays(action) {
    const nodes = candidateOverlayNodes(action && action.data && action.data.maxNodes);
    const hidden = [];
    for (const node of nodes) {
      const prev = { node, display: node.style.display, visibility: node.style.visibility, opacity: node.style.opacity, pointerEvents: node.style.pointerEvents };
      node.style.display = "none";
      hidden.push(prev);
    }
    STATE.hiddenNodes.push(...hidden);
    return { ok: true, changed: hidden.length, message: hidden.length ? `Soft-hidden ${hidden.length} overlay node(s).` : "No overlay candidate found." };
  }

  function highlightForms() {
    ensureStyle();
    const nodes = Array.from(document.querySelectorAll("form, input[type='password'], input[name], textarea[name]")).filter((node) => {
      const text = [node.name, node.id, node.placeholder, node.autocomplete, node.getAttribute && node.getAttribute("aria-label")].join(" ").toLowerCase();
      return node.matches && (node.matches("form") || /password|pass|card|credit|cvv|cvc|wallet|seed|phrase|token|otp|2fa|iban|pin|email|login/.test(text));
    }).slice(0, 20);
    let count = 0;
    for (const node of nodes) {
      if (!node.classList.contains("aetherion-v18-highlight-form")) {
        node.classList.add("aetherion-v18-highlight-form");
        STATE.highlightedNodes.push(node);
        count += 1;
      }
      if (node.matches && node.matches("form") && !node.__aetherionV9Label) {
        let actionHost = location.hostname;
        try { actionHost = new URL(node.getAttribute("action") || location.href, location.href).hostname; } catch (_) {}
        const label = document.createElement("div");
        label.className = "aetherion-v18-label";
        label.textContent = "Aetherion: form destination → " + actionHost;
        node.insertAdjacentElement("beforebegin", label);
        node.__aetherionV9Label = label;
        STATE.injectedNodes.push(label);
      }
    }
    return { ok: true, changed: count, message: count ? `Highlighted ${count} sensitive/form node(s).` : "No sensitive form node found." };
  }

  function markDownloadLinks() {
    ensureStyle();
    const links = Array.from(document.querySelectorAll("a[href]")).filter((a) => /\.(apk|exe|msi|scr|bat|cmd|ps1|vbs|jar)([?#].*)?$/i.test(a.getAttribute("href") || "")).slice(0, 30);
    let count = 0;
    for (const link of links) {
      if (!link.classList.contains("aetherion-v18-download-mark")) {
        link.classList.add("aetherion-v18-download-mark");
        STATE.highlightedNodes.push(link);
        count += 1;
      }
      if (!link.__aetherionV9DownloadLabel) {
        const label = document.createElement("span");
        label.className = "aetherion-v18-label";
        label.textContent = "Aetherion: verify download before opening";
        link.insertAdjacentElement("afterend", label);
        link.__aetherionV9DownloadLabel = label;
        STATE.injectedNodes.push(label);
      }
    }
    return { ok: true, changed: count, message: count ? `Marked ${count} download link(s).` : "No risky download link found." };
  }

  function showPrivacyFocus(action) {
    ensureStyle();
    const old = document.getElementById("aetherion-v18-privacy-note");
    if (old) old.remove();
    const note = document.createElement("div");
    note.id = "aetherion-v18-privacy-note";
    note.className = "aetherion-v18-label";
    note.style.cssText += "position:fixed!important;left:10px!important;bottom:10px!important;max-width:320px!important;";
    const data = (action && action.data) || {};
    note.textContent = `Aetherion privacy note: tracker hints ${data.trackers || 0}, external iframes ${data.externalIframes || 0}.`;
    document.documentElement.appendChild(note);
    STATE.injectedNodes.push(note);
    return { ok: true, changed: 1, message: "Privacy focus note added." };
  }

  function setCompactOverlay(action) {
    STATE.settings.compactOverlay = Boolean(action && action.data && action.data.compactOverlay !== false);
    if (window.AetherionMemory) window.AetherionMemory.setSettings({ compactOverlay: STATE.settings.compactOverlay });
    renderPanel();
    return { ok: true, changed: 1, message: "Compact overlay enabled." };
  }

  function showGuardBannerAction() {
    renderGuardBanner();
    return { ok: true, changed: 1, message: "Guard banner kept visible." };
  }

  async function markTrustedSite(action) {
    if (!window.AetherionMemory) return { ok: false, changed: 0, message: "Memory layer unavailable." };
    STATE.siteProfile = await window.AetherionMemory.setTrustedSite(hostname(), Boolean(action && action.data && action.data.trusted !== false));
    computeRisk(true); computeSiteIntelligence(true); computeLearningProfile(true); computeTrustCalibration(true); computeRuleDecision(true); computeAgent(true); computeActionPlan(true); computePolicy(true); computeReportIntelligence(true); computeTimelineIntelligence(true, "auto_mode"); computeCausalGuard(true, "auto_mode"); computeEvidenceGraph(true, "auto_mode"); computeCounterfactualGuard(true, "auto_mode"); computeTimelineIntelligence(true, "refresh"); computeCausalGuard(true, "refresh"); computeEvidenceGraph(true, "refresh"); computeCounterfactualGuard(true, "refresh"); renderPanel();
    return { ok: true, changed: 1, message: STATE.siteProfile.trusted ? "Site marked trusted." : "Site trust removed." };
  }

  function undoVisualActions() {
    let restored = 0;
    for (const item of STATE.hiddenNodes.splice(0)) {
      if (!item.node) continue;
      item.node.style.display = item.display || "";
      item.node.style.visibility = item.visibility || "";
      item.node.style.opacity = item.opacity || "";
      item.node.style.pointerEvents = item.pointerEvents || "";
      restored += 1;
    }
    for (const node of STATE.highlightedNodes.splice(0)) {
      if (node && node.classList) {
        node.classList.remove("aetherion-v18-highlight-form");
        node.classList.remove("aetherion-v18-download-mark");
        restored += 1;
      }
    }
    for (const node of STATE.injectedNodes.splice(0)) {
      if (node && node.remove) { node.remove(); restored += 1; }
    }
    return { ok: true, changed: restored, message: restored ? `Restored/removed ${restored} visual change(s).` : "No visual action to undo." };
  }

  async function applyAction(actionId, options) {
    computeRisk(true); computeSiteIntelligence(true); computeLearningProfile(true); computeTrustCalibration(true); computeRuleDecision(true); computeAgent(true); computeActionPlan(true); computePolicy(true); computeReportIntelligence(true); computeTimelineIntelligence(true, "auto_mode"); computeCausalGuard(true, "auto_mode"); computeEvidenceGraph(true, "auto_mode"); computeCounterfactualGuard(true, "auto_mode"); computeTimelineIntelligence(true, "apply_action"); computeEvidenceGraph(true, "apply_action");
    options = options || {};
    const plan = STATE.lastActionPlan || { actions: [] };
    const action = (plan.actions || []).find((item) => item.id === actionId || item.type === actionId);
    if (!action) return { ok: false, message: "Action not found in current plan." };

    if (window.AetherionPolicyEngine) {
      const policy = STATE.lastPolicyDecision || computePolicy(true);
      const permit = options.policyPermit || (options.auto
        ? window.AetherionPolicyEngine.canAutoApplyAction(action, policy, { reason: "auto_apply" })
        : window.AetherionPolicyEngine.canApplyAction(action, policy, { reason: "manual_apply" }));
      if (!permit.allowed) {
        return { ok: false, message: "Blocked by Policy Engine: " + permit.reason, policyDecision: policy, status: buildSessionSnapshot(true, true, true) };
      }
    }

    let result;
    if (action.type === "HIDE_INTRUSIVE_OVERLAYS") result = hideIntrusiveOverlays(action);
    else if (action.type === "HIGHLIGHT_FORMS") result = highlightForms(action);
    else if (action.type === "MARK_DOWNLOAD_LINKS") result = markDownloadLinks(action);
    else if (action.type === "PRIVACY_FOCUS_OVERLAY") result = showPrivacyFocus(action);
    else if (action.type === "SET_COMPACT_OVERLAY") result = setCompactOverlay(action);
    else if (action.type === "SHOW_GUARD_BANNER") result = showGuardBannerAction(action);
    else if (action.type === "SAVE_SESSION") result = { ok: true, changed: 1, message: "Session saved.", saved: await saveSession("action_planner") };
    else if (action.type === "MARK_TRUSTED_SITE") result = await markTrustedSite(action);
    else result = { ok: true, changed: 0, message: "No operation needed." };

    const event = { action, result, auto: Boolean(options.auto), policyDecisionId: STATE.lastPolicyDecision && STATE.lastPolicyDecision.decisionId, planId: plan.planId, riskScore: STATE.lastRisk && STATE.lastRisk.score, riskLevel: STATE.lastRisk && STATE.lastRisk.level };
    STATE.appliedActions.push(Object.assign({ at: new Date().toISOString() }, event));
    if (window.AetherionMemory && window.AetherionMemory.saveActionEvent) await window.AetherionMemory.saveActionEvent(event);
    computeActionPlan(true); computePolicy(true); computeReportIntelligence(true); computeTimelineIntelligence(true, "refresh"); renderPanel();
    return Object.assign({ ok: true, action, status: buildSessionSnapshot(true, true) }, result || {});
  }

  function sendMessageResponse(sendResponse, payload) {
    try { sendResponse(payload); } catch (_) {}
  }

  function attachRuntimeMessages() {
    if (typeof chrome === "undefined" || !chrome.runtime || !chrome.runtime.onMessage) return;
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (!message || !message.type) return false;

      if (message.type === "AETHERION_GET_STATUS") {
        computeRisk(true); computeSiteIntelligence(true); computeLearningProfile(true); computeTrustCalibration(true); computeRuleDecision(true); computeAgent(true); computeActionPlan(true); computePolicy(true); computeReportIntelligence(true); computeTimelineIntelligence(true, "auto_mode"); computeCausalGuard(true, "auto_mode"); computeEvidenceGraph(true, "auto_mode"); computeCounterfactualGuard(true, "auto_mode"); computeTimelineIntelligence(true, "refresh"); computeEvidenceGraph(true, "refresh");
        sendMessageResponse(sendResponse, { ok: true, status: buildSessionSnapshot(true, true), profile: STATE.siteProfile, settings: STATE.settings, rules: STATE.rules });
        return false;
      }

      if (message.type === "AETHERION_ANALYZE_NOW") {
        computeRisk(true); computeSiteIntelligence(true); computeLearningProfile(true); computeTrustCalibration(true); computeRuleDecision(true); computeAgent(true); computeActionPlan(true); computePolicy(true); computeReportIntelligence(true); computeTimelineIntelligence(true, "auto_mode"); computeCausalGuard(true, "auto_mode"); computeEvidenceGraph(true, "auto_mode"); computeCounterfactualGuard(true, "auto_mode"); computeTimelineIntelligence(true, "refresh"); computeCausalGuard(true, "refresh"); computeEvidenceGraph(true, "refresh"); computeCounterfactualGuard(true, "refresh"); renderPanel();
        sendMessageResponse(sendResponse, { ok: true, status: buildSessionSnapshot(true, true), profile: STATE.siteProfile, settings: STATE.settings, rules: STATE.rules });
        return false;
      }

      if (message.type === "AETHERION_SAVE_SESSION") {
        saveSession("popup").then((saved) => sendMessageResponse(sendResponse, { ok: true, saved, status: buildSessionSnapshot(true, true), profile: STATE.siteProfile, settings: STATE.settings, rules: STATE.rules }));
        return true;
      }

      if (message.type === "AETHERION_APPLY_ACTION") {
        applyAction(message.actionId).then((payload) => sendMessageResponse(sendResponse, Object.assign({ profile: STATE.siteProfile, settings: STATE.settings, rules: STATE.rules }, payload)));
        return true;
      }

      if (message.type === "AETHERION_UNDO_ACTIONS") {
        const result = undoVisualActions();
        renderPanel();
        sendMessageResponse(sendResponse, { ok: true, result, status: buildSessionSnapshot(true, true), profile: STATE.siteProfile, settings: STATE.settings, rules: STATE.rules });
        return false;
      }

      if (message.type === "AETHERION_SET_OVERLAY") {
        STATE.settings.overlayEnabled = Boolean(message.enabled);
        if (window.AetherionMemory) window.AetherionMemory.setSettings({ overlayEnabled: STATE.settings.overlayEnabled });
        renderPanel();
        sendMessageResponse(sendResponse, { ok: true, settings: STATE.settings });
        return false;
      }

      if (message.type === "AETHERION_SET_SETTING") {
        const patch = message.patch || {};
        STATE.settings = Object.assign({}, STATE.settings, patch);
        if (window.AetherionMemory) window.AetherionMemory.setSettings(patch);
        computeRisk(true); computeSiteIntelligence(true); computeLearningProfile(true); computeTrustCalibration(true); computeRuleDecision(true); computeAgent(true); computeActionPlan(true); computePolicy(true); computeReportIntelligence(true); computeTimelineIntelligence(true, "auto_mode"); computeCausalGuard(true, "auto_mode"); computeEvidenceGraph(true, "auto_mode"); computeCounterfactualGuard(true, "auto_mode"); computeTimelineIntelligence(true, "refresh"); computeCausalGuard(true, "refresh"); computeEvidenceGraph(true, "refresh"); computeCounterfactualGuard(true, "refresh"); renderPanel();
        sendMessageResponse(sendResponse, { ok: true, settings: STATE.settings, status: buildSessionSnapshot(true, true), profile: STATE.siteProfile, rules: STATE.rules });
        return false;
      }

      if (message.type === "AETHERION_TRUST_SITE") {
        if (!window.AetherionMemory) { sendMessageResponse(sendResponse, { ok: false, error: "Memory layer unavailable" }); return false; }
        window.AetherionMemory.setTrustedSite(hostname(), Boolean(message.trusted)).then((profile) => {
          STATE.siteProfile = profile;
          computeRisk(true); computeSiteIntelligence(true); computeLearningProfile(true); computeTrustCalibration(true); computeRuleDecision(true); computeAgent(true); computeActionPlan(true); computePolicy(true); computeReportIntelligence(true); computeTimelineIntelligence(true, "auto_mode"); computeCausalGuard(true, "auto_mode"); computeEvidenceGraph(true, "auto_mode"); computeCounterfactualGuard(true, "auto_mode"); computeTimelineIntelligence(true, "refresh"); computeCausalGuard(true, "refresh"); computeEvidenceGraph(true, "refresh"); computeCounterfactualGuard(true, "refresh"); renderPanel();
          sendMessageResponse(sendResponse, { ok: true, profile, status: buildSessionSnapshot(true, true), settings: STATE.settings, rules: STATE.rules });
        });
        return true;
      }

      if (message.type === "AETHERION_SET_TRUST_LEVEL") {
        if (!window.AetherionMemory || !window.AetherionMemory.setTrustLevel) { sendMessageResponse(sendResponse, { ok: false, error: "Trust storage unavailable" }); return false; }
        window.AetherionMemory.setTrustLevel(hostname(), message.level || "local").then((profile) => {
          STATE.siteProfile = profile;
          computeRisk(true); computeSiteIntelligence(true); computeLearningProfile(true); computeTrustCalibration(true); computeRuleDecision(true); computeAgent(true); computeActionPlan(true); computePolicy(true); computeReportIntelligence(true); computeTimelineIntelligence(true, "auto_mode"); computeCausalGuard(true, "auto_mode"); computeEvidenceGraph(true, "auto_mode"); computeCounterfactualGuard(true, "auto_mode"); computeTimelineIntelligence(true, "refresh"); computeCausalGuard(true, "refresh"); computeEvidenceGraph(true, "refresh"); computeCounterfactualGuard(true, "refresh"); renderPanel();
          sendMessageResponse(sendResponse, { ok: true, profile, status: buildSessionSnapshot(true, true, true), settings: STATE.settings, rules: STATE.rules });
        });
        return true;
      }


      if (message.type === "AETHERION_RUN_AUTO_MODE") {
        runAutoMode("popup").then((result) => sendMessageResponse(sendResponse, { ok: true, result, status: buildSessionSnapshot(true, true, true), profile: STATE.siteProfile, settings: STATE.settings }));
        return true;
      }



      if (message.type === "AETHERION_GET_RULES") {
        if (!window.AetherionRuleComposer) { sendMessageResponse(sendResponse, { ok: false, error: "Rule Composer unavailable" }); return false; }
        window.AetherionRuleComposer.getRules().then((rules) => {
          STATE.rules = rules;
          computeRuleDecision(true); computePolicy(true); computeReportIntelligence(true); computeTimelineIntelligence(true, "refresh"); renderPanel();
          sendMessageResponse(sendResponse, { ok: true, rules: STATE.rules, status: buildSessionSnapshot(true, true, true), settings: STATE.settings, profile: STATE.siteProfile });
        });
        return true;
      }

      if (message.type === "AETHERION_ADD_RULE_PRESET") {
        if (!window.AetherionRuleComposer) { sendMessageResponse(sendResponse, { ok: false, error: "Rule Composer unavailable" }); return false; }
        window.AetherionRuleComposer.addPreset(message.presetType || "PROTECTIVE_HERE", hostname()).then(async (rule) => {
          STATE.rules = await window.AetherionRuleComposer.getRules();
          computeRuleDecision(true); computePolicy(true); computeReportIntelligence(true); computeTimelineIntelligence(true, "refresh"); renderPanel();
          sendMessageResponse(sendResponse, { ok: true, rule, rules: STATE.rules, status: buildSessionSnapshot(true, true, true), settings: STATE.settings, profile: STATE.siteProfile });
        });
        return true;
      }

      if (message.type === "AETHERION_REMOVE_RULE") {
        if (!window.AetherionRuleComposer) { sendMessageResponse(sendResponse, { ok: false, error: "Rule Composer unavailable" }); return false; }
        window.AetherionRuleComposer.removeRule(message.ruleId).then((rules) => {
          STATE.rules = rules;
          computeRuleDecision(true); computePolicy(true); computeReportIntelligence(true); computeTimelineIntelligence(true, "refresh"); renderPanel();
          sendMessageResponse(sendResponse, { ok: true, rules: STATE.rules, status: buildSessionSnapshot(true, true, true), settings: STATE.settings, profile: STATE.siteProfile });
        });
        return true;
      }

      if (message.type === "AETHERION_CLEAR_SITE_RULES") {
        if (!window.AetherionRuleComposer) { sendMessageResponse(sendResponse, { ok: false, error: "Rule Composer unavailable" }); return false; }
        window.AetherionRuleComposer.clearRulesForSite(hostname()).then((rules) => {
          STATE.rules = rules;
          computeRuleDecision(true); computePolicy(true); computeReportIntelligence(true); computeTimelineIntelligence(true, "refresh"); renderPanel();
          sendMessageResponse(sendResponse, { ok: true, rules: STATE.rules, status: buildSessionSnapshot(true, true, true), settings: STATE.settings, profile: STATE.siteProfile });
        });
        return true;
      }

      if (message.type === "AETHERION_HIDE_GUARD") {
        removeBanner(); sendMessageResponse(sendResponse, { ok: true }); return false;
      }

      return false;
    });
  }

  async function bootstrap() {
    if (window.AetherionMemory) {
      STATE.settings = await window.AetherionMemory.getSettings();
      STATE.siteProfile = await window.AetherionMemory.getSiteProfile(hostname());
    }
    if (window.AetherionRuleComposer) {
      STATE.rules = await window.AetherionRuleComposer.getRules();
      computeRuleDecision(true);
    }
    attachUserEventSensors();
    attachMutationObserver();
    attachRuntimeMessages();
    computeRisk(true); computeSiteIntelligence(true); computeLearningProfile(true); computeTrustCalibration(true); computeRuleDecision(true); computeAgent(true); computeActionPlan(true); computePolicy(true); computeReportIntelligence(true); computeTimelineIntelligence(true, "auto_mode"); computeCausalGuard(true, "auto_mode"); computeEvidenceGraph(true, "auto_mode"); computeCounterfactualGuard(true, "auto_mode"); computeTimelineIntelligence(true, "refresh"); computeCausalGuard(true, "refresh"); computeEvidenceGraph(true, "refresh"); computeCounterfactualGuard(true, "refresh"); renderPanel();
    setInterval(() => { computeRisk(true); computeSiteIntelligence(true); computeLearningProfile(true); computeTrustCalibration(true); computeRuleDecision(true); computeAgent(true); computeActionPlan(true); computePolicy(true); computeReportIntelligence(true); computeTimelineIntelligence(true, "auto_mode"); computeCausalGuard(true, "auto_mode"); computeEvidenceGraph(true, "auto_mode"); computeCounterfactualGuard(true, "auto_mode"); computeTimelineIntelligence(true, "interval"); computeEvidenceGraph(true, "interval"); computeCounterfactualGuard(true, "interval"); runAutoMode("interval"); renderPanel(); }, 3000);
    window.addEventListener("beforeunload", () => {
      if (STATE.settings.autoSaveSessions && window.AetherionMemory) {
        const snapshot = buildSessionSnapshot(true, true, true);
        snapshot.saveReason = "beforeunload";
        window.AetherionMemory.saveSession(snapshot);
      }
    });
  }

  safeCall(bootstrap, null);
})();
