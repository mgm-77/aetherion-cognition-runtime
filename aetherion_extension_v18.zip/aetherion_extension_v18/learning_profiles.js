/*
 * Aetherion DevOS v18 - Learning Profiles+ and Rule Composer+ Engine
 * Local-only adaptive classifier. Builds a small behavioral model per domain from current signals + stored profile history.
 */
(function () {
  "use strict";

  function nowIso() { return new Date().toISOString(); }
  function clamp(value, min, max) { return Math.max(min, Math.min(max, Number(value) || 0)); }
  function safeNumber(value, fallback) { const n = Number(value); return Number.isFinite(n) ? n : fallback; }
  function arr(value) { return Array.isArray(value) ? value : []; }
  function avg(values) {
    const clean = arr(values).map(Number).filter(Number.isFinite);
    if (!clean.length) return 0;
    return clean.reduce((a, b) => a + b, 0) / clean.length;
  }
  function std(values) {
    const clean = arr(values).map(Number).filter(Number.isFinite);
    if (clean.length < 2) return 0;
    const mean = avg(clean);
    return Math.sqrt(clean.reduce((s, v) => s + Math.pow(v - mean, 2), 0) / clean.length);
  }
  function slope(values) {
    const clean = arr(values).map(Number).filter(Number.isFinite);
    if (clean.length < 3) return 0;
    const n = clean.length;
    const meanX = (n - 1) / 2;
    const meanY = avg(clean);
    let num = 0, den = 0;
    for (let i = 0; i < n; i++) { num += (i - meanX) * (clean[i] - meanY); den += Math.pow(i - meanX, 2); }
    return den ? num / den : 0;
  }
  function levelFromRisk(score) {
    if (score >= 78) return "CRITICAL";
    if (score >= 58) return "HIGH";
    if (score >= 32) return "MEDIUM";
    return "LOW";
  }
  function sensitivityMultiplier(settings) {
    const s = (settings && settings.learningSensitivity) || "balanced";
    if (s === "relaxed") return 0.88;
    if (s === "strict") return 1.15;
    return 1;
  }
  function deriveFeatures(snapshot, risk, profile, siteIntelligence, settings) {
    const signals = (risk && risk.signals) || (snapshot && snapshot.signals) || {};
    const scripts = signals.scripts || {};
    const forms = signals.forms || {};
    const links = signals.links || {};
    const iframes = signals.iframes || {};
    const userEvents = (snapshot && snapshot.userEvents) || {};
    const durationSec = Math.max(1, safeNumber(snapshot && snapshot.durationMs, 0) / 1000);
    const mutations = safeNumber(snapshot && snapshot.mutations, 0);
    const anomalies = safeNumber(snapshot && snapshot.anomalies, 0);
    const visits = safeNumber(profile && profile.visits, 0);
    const trend = arr(profile && profile.riskTrend).slice(-12).map((x) => safeNumber(x && x.riskScore, 0));
    const intelHistory = arr(profile && profile.intelHistory).slice(-12);
    const learningHistory = arr(profile && profile.learningHistory).slice(-12);
    const riskScore = safeNumber(risk && risk.score, safeNumber(snapshot && snapshot.riskScore, 0));
    const trackerHints = safeNumber(scripts.trackers, 0);
    const externalScripts = safeNumber(scripts.external, 0);
    const externalIframes = safeNumber(iframes.external, 0);
    const formCount = safeNumber(forms.total, 0);
    const passwordFields = safeNumber(forms.passwordFields, 0);
    const dangerousDownloads = safeNumber(links.dangerousDownloads, 0);
    const externalLinks = safeNumber(links.externalLinks, 0);
    const clickCount = safeNumber(userEvents.clicks, 0);
    const keyCount = safeNumber(userEvents.keys, 0);
    const scrollCount = safeNumber(userEvents.scrolls, 0);
    const interactionTotal = clickCount + keyCount + scrollCount;
    const mutRate = mutations / durationSec;
    const anomalyRate = anomalies / Math.max(1, mutations / 100);
    const riskStd = std(trend.concat([riskScore]));
    const riskSlope = slope(trend.concat([riskScore]));
    const intelVolatility = safeNumber(siteIntelligence && siteIntelligence.volatilityScore, safeNumber(profile && profile.volatilityScore, 0));
    const learnedSuspicionAvg = avg(learningHistory.map((x) => safeNumber(x && x.suspicionIndex, 0)));
    const dynamicIndex = clamp((mutRate / 18) * 32 + (mutations / 1800) * 18 + (scrollCount > 0 ? 7 : 0), 0, 100);
    const trackingIndex = clamp((trackerHints * 15) + (externalScripts * 4) + (externalIframes * 7), 0, 100);
    const sensitiveSurfaceIndex = clamp((passwordFields * 26) + (formCount * 7) + (externalLinks > 20 ? 10 : 0), 0, 100);
    const downloadIndex = clamp(dangerousDownloads * 35, 0, 100);
    const instabilityIndex = clamp(riskStd + Math.abs(riskSlope * 6) + intelVolatility * 0.45 + anomalyRate * 8, 0, 100);
    const userNormalityIndex = clamp(interactionTotal ? 100 - Math.abs((mutations / Math.max(1, interactionTotal)) - 80) * 0.55 : 42, 0, 100);
    const suspicionIndex = clamp((riskScore * 0.38 + trackingIndex * 0.18 + sensitiveSurfaceIndex * 0.14 + downloadIndex * 0.11 + instabilityIndex * 0.13 + learnedSuspicionAvg * 0.06) * sensitivityMultiplier(settings), 0, 100);
    return {
      visits, mutations, anomalies, riskScore, riskLevel: (risk && risk.level) || levelFromRisk(riskScore), trend, riskStd, riskSlope,
      dynamicIndex: Number(dynamicIndex.toFixed(2)), trackingIndex: Number(trackingIndex.toFixed(2)), sensitiveSurfaceIndex: Number(sensitiveSurfaceIndex.toFixed(2)),
      downloadIndex: Number(downloadIndex.toFixed(2)), instabilityIndex: Number(instabilityIndex.toFixed(2)), userNormalityIndex: Number(userNormalityIndex.toFixed(2)),
      suspicionIndex: Number(suspicionIndex.toFixed(2)), mutRate: Number(mutRate.toFixed(2)), anomalyRate: Number(anomalyRate.toFixed(2)),
      trackerHints, externalScripts, externalIframes, formCount, passwordFields, dangerousDownloads, interactionTotal,
      intelClass: siteIntelligence && siteIntelligence.behaviorClass,
      intelReputation: siteIntelligence && siteIntelligence.reputationLevel,
      previousLearningClass: profile && profile.learningClass,
      trusted: Boolean(profile && profile.trusted)
    };
  }
  function classify(features) {
    if (features.trusted && features.riskScore < 45 && features.suspicionIndex < 45) return "TRUSTED_LEARNED_SAFE";
    if (features.visits < 2 && features.riskScore < 34 && features.suspicionIndex < 38) return "NEW_LOW_RISK";
    if (features.dynamicIndex > 62 && features.suspicionIndex < 42 && features.trackingIndex < 45) return "DYNAMIC_BUT_SAFE";
    if (features.suspicionIndex >= 74 || features.riskScore >= 78) return "REPEATED_SUSPICIOUS";
    if (features.dynamicIndex > 65 && features.trackingIndex > 52) return "AGGRESSIVE_DYNAMIC";
    if (features.sensitiveSurfaceIndex > 55 && features.trackingIndex > 35) return "SENSITIVE_AND_TRACKED";
    if (features.downloadIndex > 40) return "DOWNLOAD_RISK_SURFACE";
    if (features.instabilityIndex > 58 || features.riskStd > 25) return "VOLATILE_BEHAVIOR";
    if (features.riskScore < 28 && features.suspicionIndex < 30) return "STABLE_NORMAL";
    return "WATCHLIST_BALANCED";
  }
  function policyHintFor(features, learningClass, settings) {
    const baseMode = (settings && settings.policyMode) || "balanced";
    if (["REPEATED_SUSPICIOUS", "SENSITIVE_AND_TRACKED", "DOWNLOAD_RISK_SURFACE"].includes(learningClass)) return "strict";
    if (["AGGRESSIVE_DYNAMIC", "VOLATILE_BEHAVIOR", "WATCHLIST_BALANCED"].includes(learningClass)) return "protective";
    if (["TRUSTED_LEARNED_SAFE", "STABLE_NORMAL", "DYNAMIC_BUT_SAFE", "NEW_LOW_RISK"].includes(learningClass)) return baseMode === "strict" ? "protective" : "balanced";
    return baseMode;
  }
  function buildNotes(features, learningClass) {
    const notes = [];
    if (learningClass === "DYNAMIC_BUT_SAFE") notes.push("High DOM activity appears locally normal for this page pattern.");
    if (features.trackingIndex > 50) notes.push("Tracking/external script surface is a strong learning signal.");
    if (features.sensitiveSurfaceIndex > 50) notes.push("Sensitive form surface should remain highlighted or audited.");
    if (features.instabilityIndex > 55) notes.push("Risk volatility is high across local history.");
    if (features.visits < 2) notes.push("Learning confidence is limited until more sessions are saved.");
    if (!notes.length) notes.push("Learning profile is stable enough for balanced local guidance.");
    return notes;
  }
  function recommendationsFor(features, learningClass) {
    const recs = [];
    if (["REPEATED_SUSPICIOUS", "AGGRESSIVE_DYNAMIC", "SENSITIVE_AND_TRACKED"].includes(learningClass)) recs.push("Keep Policy Engine+ protective/strict for this domain.");
    if (learningClass === "DYNAMIC_BUT_SAFE") recs.push("Avoid over-penalizing DOM churn; monitor trackers and forms instead.");
    if (features.dangerousDownloads > 0) recs.push("Mark and verify download links before opening them.");
    if (features.passwordFields > 0 || features.formCount > 0) recs.push("Highlight form destinations and avoid external form submissions unless trusted.");
    if (features.visits < 3) recs.push("Save a few more sessions to raise confidence.");
    return recs.slice(0, 5);
  }
  function confidenceFor(features) {
    const visitConfidence = clamp(features.visits * 16, 0, 54);
    const signalConfidence = clamp((features.interactionTotal > 0 ? 12 : 0) + (features.mutations > 0 ? 10 : 0) + (features.trend.length * 3), 0, 36);
    const stabilityPenalty = clamp(features.instabilityIndex * 0.18, 0, 14);
    return Math.round(clamp(34 + visitConfidence + signalConfidence - stabilityPenalty, 25, 96));
  }
  function learn(input) {
    const snapshot = (input && input.snapshot) || {};
    const risk = (input && input.risk) || {};
    const profile = (input && input.profile) || {};
    const siteIntelligence = input && input.siteIntelligence;
    const settings = (input && input.settings) || {};
    const features = deriveFeatures(snapshot, risk, profile, siteIntelligence, settings);
    const learningClass = classify(features);
    const confidence = confidenceFor(features);
    const policyHint = policyHintFor(features, learningClass, settings);
    const notes = buildNotes(features, learningClass);
    const recommendations = recommendationsFor(features, learningClass);
    const label = learningClass.replace(/_/g, " ").toLowerCase();
    return {
      id: "learning-" + Date.now() + "-" + Math.random().toString(16).slice(2),
      at: nowIso(),
      engine: "Learning Profiles+ and Rule Composer+",
      version: "18.0.0",
      site: snapshot.site || (profile && profile.site) || "unknown",
      learningClass,
      confidence,
      policyHint,
      suspicionIndex: features.suspicionIndex,
      adaptiveClass: label,
      summary: `Learning Profiles+ and Rule Composer+ classifies this domain as ${label} with ${confidence}% confidence.`,
      features,
      notes,
      recommendations,
      nextLearningGoals: [
        "Save session after meaningful page interaction.",
        "Compare risk trend after 3+ visits.",
        "Keep trusted flag manual, not automatic."
      ]
    };
  }

  window.AetherionLearningProfiles = { learn };
})();
