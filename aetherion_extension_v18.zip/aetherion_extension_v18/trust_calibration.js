/*
 * Aetherion DevOS v18 - Trust Calibration+ and Report Intelligence+ and Timeline Intelligence+ and Causal Guard+ and Evidence Graph+ and Counterfactual Guard+
 * Local-only domain trust calibration: local, trusted, watched, sensitive, blocked.
 */
(function () {
  "use strict";

  const VERSION = "18.0.0";
  const LEVELS = ["local", "trusted", "watched", "sensitive", "blocked"];

  function clamp(value, min, max) {
    const n = Number(value);
    if (!Number.isFinite(n)) return min;
    return Math.max(min, Math.min(max, n));
  }

  function normalizeLevel(level, fallback) {
    const raw = String(level || fallback || "local").toLowerCase();
    return LEVELS.includes(raw) ? raw : "local";
  }

  function riskBand(score) {
    if (score >= 80) return "critical";
    if (score >= 55) return "high";
    if (score >= 30) return "medium";
    return "low";
  }

  function baseLevelFromProfile(profile) {
    if (!profile) return "local";
    if (profile.trustLevel) return normalizeLevel(profile.trustLevel, "local");
    if (profile.blocked) return "blocked";
    if (profile.sensitive) return "sensitive";
    if (profile.watched) return "watched";
    if (profile.trusted) return "trusted";
    return "local";
  }

  function signalsFrom(risk, snapshot) {
    return (risk && risk.signals) || (snapshot && snapshot.signals) || {};
  }

  function hasSensitiveSurface(risk, snapshot) {
    const signals = signalsFrom(risk, snapshot);
    const forms = signals.forms || {};
    const phishing = Array.isArray(signals.phishingIndicators) ? signals.phishingIndicators : [];
    return Number(forms.passwordFields || 0) > 0 || Number(forms.externalActionForms || 0) > 0 || phishing.length > 0;
  }

  function hasDownloadSurface(risk, snapshot) {
    const links = (signalsFrom(risk, snapshot).links || {});
    return Number(links.dangerousDownloads || 0) > 0;
  }

  function strongerMode(a, b) {
    const order = { observe: 0, relaxed: 0, balanced: 1, protective: 2, strict: 3 };
    const left = String(a || "balanced").toLowerCase();
    const right = String(b || left).toLowerCase();
    return (order[right] || 0) > (order[left] || 0) ? right : left;
  }

  function computeTrustScore(profile, risk, intel, learning) {
    const score = clamp(risk && risk.score, 0, 100);
    let trust = 55;
    const level = baseLevelFromProfile(profile);
    if (level === "trusted") trust += 24;
    if (level === "watched") trust -= 6;
    if (level === "sensitive") trust -= 16;
    if (level === "blocked") trust -= 42;
    if (profile && Number(profile.visits || 0) >= 3) trust += 6;
    if (profile && Number(profile.visits || 0) >= 10) trust += 6;
    if (intel && typeof intel.reputationScore !== "undefined") trust += (clamp(intel.reputationScore, 0, 100) - 50) * 0.25;
    if (learning && typeof learning.suspicionIndex !== "undefined") trust -= clamp(learning.suspicionIndex, 0, 100) * 0.25;
    trust -= score * 0.35;
    return Math.round(clamp(trust, 0, 100));
  }

  function effectiveLevel(userLevel, trustScore, risk, snapshot, intel, learning) {
    const score = clamp(risk && risk.score, 0, 100);
    const level = normalizeLevel(userLevel, "local");
    const learningClass = String((learning && learning.learningClass) || "").toUpperCase();
    const trend = String((intel && intel.trendDirection) || "").toUpperCase();

    if (level === "blocked") return { level: "blocked", reason: "Domain is manually calibrated as blocked." };
    if (level === "sensitive") return { level: "sensitive", reason: "Domain is manually calibrated as sensitive." };
    if (score >= 85 || hasSensitiveSurface(risk, snapshot) && score >= 60 || hasDownloadSurface(risk, snapshot) && score >= 55) {
      return { level: "sensitive", reason: "Risk surface temporarily upgrades trust posture to sensitive." };
    }
    if (learningClass.includes("REPEATED_SUSPICIOUS") || learningClass.includes("SENSITIVE_AND_TRACKED")) {
      return { level: "sensitive", reason: "Learning profile indicates repeated sensitive or suspicious behavior." };
    }
    if (trend === "WORSENING" && score >= 40) {
      return { level: "watched", reason: "Site trend is worsening; calibrated to watched." };
    }
    if (level === "trusted" && (score >= 45 || trustScore < 55)) {
      return { level: "watched", reason: "Trusted site was temporarily downgraded to watched because current risk is not low." };
    }
    if (level === "trusted") return { level: "trusted", reason: "Domain is manually trusted and current risk did not force a downgrade." };
    if (level === "watched") return { level: "watched", reason: "Domain is manually watched." };
    if (trustScore <= 25) return { level: "watched", reason: "Low local trust score keeps the domain watched." };
    return { level: "local", reason: "Neutral local trust calibration." };
  }

  function settingsPatchFor(level, baseSettings, risk) {
    const patch = {};
    const currentMode = (baseSettings && baseSettings.policyMode) || "balanced";
    const score = clamp(risk && risk.score, 0, 100);
    if (level === "trusted") {
      patch.guardBannerCriticalOnly = true;
      patch.trustedRiskDiscount = Math.max(Number((baseSettings && baseSettings.trustedRiskDiscount) || 10), 12);
    }
    if (level === "watched") {
      patch.guardBannerEnabled = true;
      patch.policyMode = strongerMode(currentMode, score >= 55 ? "protective" : "balanced");
    }
    if (level === "sensitive") {
      patch.guardBannerEnabled = true;
      patch.guardBannerCriticalOnly = false;
      patch.policyMode = strongerMode(currentMode, "strict");
      patch.autoModeEnabled = false;
      patch.actionSafeMode = true;
    }
    if (level === "blocked") {
      patch.guardBannerEnabled = true;
      patch.guardBannerCriticalOnly = false;
      patch.policyMode = "strict";
      patch.autoModeEnabled = false;
      patch.actionSafeMode = true;
      patch.ruleBlockedActionTypes = ["MARK_TRUSTED_SITE", "HIDE_INTRUSIVE_OVERLAYS"];
    }
    return patch;
  }

  function policyHintFor(level, risk) {
    const score = clamp(risk && risk.score, 0, 100);
    if (level === "blocked" || level === "sensitive") return "strict";
    if (level === "watched" || score >= 55) return "protective";
    return "balanced";
  }

  function calibrate(input) {
    const snapshot = input.snapshot || {};
    const risk = input.risk || { score: snapshot.riskScore || 0, level: snapshot.riskLevel || "LOW", signals: snapshot.signals || {} };
    const profile = input.profile || {};
    const settings = input.settings || {};
    const intel = input.siteIntelligence || null;
    const learning = input.learningProfile || null;
    const userLevel = baseLevelFromProfile(profile);
    const score = clamp(risk.score || snapshot.riskScore || 0, 0, 100);
    const trustScore = computeTrustScore(profile, risk, intel, learning);
    const effective = effectiveLevel(userLevel, trustScore, risk, snapshot, intel, learning);
    const patch = settingsPatchFor(effective.level, settings, risk);
    const policyHint = policyHintFor(effective.level, risk);
    const reasons = [effective.reason];
    const restrictions = [];

    if (effective.level === "trusted") restrictions.push("low_noise_trusted_mode");
    if (effective.level === "watched") restrictions.push("watched_domain_extra_observation");
    if (effective.level === "sensitive") restrictions.push("sensitive_domain_strict_policy");
    if (effective.level === "blocked") restrictions.push("blocked_domain_strict_warning_posture");
    if (hasSensitiveSurface(risk, snapshot)) restrictions.push("sensitive_surface_detected");
    if (hasDownloadSurface(risk, snapshot)) restrictions.push("download_surface_detected");
    if (userLevel !== effective.level) reasons.push(`Effective level changed from ${userLevel} to ${effective.level} by local evidence.`);

    return {
      calibrationId: "trust-" + Date.now() + "-" + Math.random().toString(16).slice(2),
      version: VERSION,
      site: snapshot.site || (profile && profile.site) || "unknown",
      userTrustLevel: userLevel,
      effectiveTrustLevel: effective.level,
      trustScore,
      confidence: clamp(55 + (profile && Number(profile.visits || 0) > 0 ? 12 : 0) + (intel ? 8 : 0) + (learning ? 8 : 0) - (riskBand(score) === "critical" ? 10 : 0), 35, 98),
      riskScore: score,
      riskBand: riskBand(score),
      policyHint,
      settingsPatch: Object.assign({}, patch, { trustCalibrationDecision: { userTrustLevel: userLevel, effectiveTrustLevel: effective.level, trustScore, policyHint } }),
      restrictions,
      reasons,
      summary: `${effective.level} trust · score ${trustScore}/100 · ${policyHint} policy hint`,
      createdAt: new Date().toISOString()
    };
  }

  window.AetherionTrustCalibration = { VERSION, LEVELS, calibrate, normalizeLevel };
})();
