# Termux install commands

```bash
cd /storage/emulated/0/Download
unzip aetherion_extension_v18.zip -d aetherion_extension_v18
```

Then open Kiwi Browser:

```text
chrome://extensions
Developer mode ON
Load unpacked
Select aetherion_extension_v18
```
