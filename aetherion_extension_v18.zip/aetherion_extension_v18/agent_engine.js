/*
 * Aetherion DevOS v18 - Agent Engine
 * Converts risk signals into explainable guidance and non-destructive guard actions.
 */
(function () {
  "use strict";

  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function trendFromProfile(profile) {
    const trend = profile && Array.isArray(profile.riskTrend) ? profile.riskTrend : [];
    if (trend.length < 2) return "unknown";
    const recent = trend.slice(-5).map((item) => Number(item.riskScore || 0));
    const first = recent[0];
    const last = recent[recent.length - 1];
    if (last - first >= 15) return "rising";
    if (first - last >= 15) return "falling";
    return "stable";
  }

  function topCategories(categories) {
    const entries = Object.entries(categories || {})
      .filter((entry) => Number(entry[1]) > 0)
      .sort((a, b) => Number(b[1]) - Number(a[1]));
    return entries.slice(0, 3).map((entry) => ({ name: entry[0], score: Number(entry[1]) }));
  }

  function confidenceFromRisk(risk, profile) {
    const reasonCount = risk && Array.isArray(risk.reasons) ? risk.reasons.length : 0;
    const visits = profile ? Number(profile.visits || 0) : 0;
    let confidence = 35 + Math.min(reasonCount * 7, 35) + Math.min(visits * 3, 20);
    if (risk && risk.score >= 80) confidence += 10;
    return clamp(confidence, 25, 96);
  }

  function stanceFromRisk(score, trusted) {
    if (trusted && score < 70) return "TRUSTED_OBSERVE";
    if (score >= 80) return "GUARD_STRONG";
    if (score >= 55) return "CAUTION";
    if (score >= 30) return "WATCH";
    return "OBSERVE";
  }

  function guardLevelFromStance(stance) {
    if (stance === "GUARD_STRONG") return "strong";
    if (stance === "CAUTION") return "medium";
    if (stance === "WATCH") return "light";
    return "none";
  }

  function makeRecommendation(id, severity, title, detail, action) {
    return { id, severity, title, detail, action };
  }

  function decide(input) {
    const snapshot = input.snapshot || {};
    const risk = input.risk || snapshot.risk || { score: 0, level: "LOW", reasons: [], signals: {}, categories: {} };
    const profile = input.profile || null;
    const settings = input.settings || {};
    const trusted = Boolean(profile && profile.trusted);
    const score = Number(risk.score || snapshot.riskScore || 0);
    const stance = stanceFromRisk(score, trusted);
    const guardLevel = guardLevelFromStance(stance);
    const recommendations = [];
    const suggestedActions = [];
    const nextChecks = [];
    const evidenceCards = [];
    const categories = topCategories(risk.categories || {});
    const signals = risk.signals || {};
    const forms = signals.forms || {};
    const scripts = signals.scripts || {};
    const links = signals.links || {};
    const iframes = signals.iframes || {};
    const dark = signals.darkPatterns || {};
    const phishing = signals.phishingIndicators || [];
    const trend = trendFromProfile(profile);
    const confidence = confidenceFromRisk(risk, profile);

    if (score >= 80) {
      recommendations.push(makeRecommendation(
        "critical_guard",
        "critical",
        "Nu introduce date sensibile încă",
        "Pagina are scor critic local. Aetherion recomandă verificarea domeniului și evitarea parolelor/cardurilor până confirmi manual site-ul.",
        "verify_domain_first"
      ));
      suggestedActions.push("Avoid passwords, card data, wallet seed phrases, and file downloads on this page until verified.");
    } else if (score >= 55) {
      recommendations.push(makeRecommendation(
        "high_caution",
        "high",
        "Folosește pagina cu atenție",
        "Sunt mai multe semnale locale de risc. Continuă doar dacă domeniul și scopul paginii sunt clare.",
        "review_risk_reasons"
      ));
      suggestedActions.push("Review the top risk reasons before interacting with forms or downloads.");
    } else if (score >= 30) {
      recommendations.push(makeRecommendation(
        "medium_watch",
        "medium",
        "Ține pagina sub observație",
        "Pagina nu pare critică, dar are comportamente care merită urmărite.",
        "watch_page_behavior"
      ));
    } else {
      recommendations.push(makeRecommendation(
        "low_observe",
        "low",
        "Observare normală",
        "Nu există semnale locale majore în analiza curentă.",
        "continue_observing"
      ));
    }

    if (forms.passwordFields > 0 || forms.sensitiveInputs > 0) {
      recommendations.push(makeRecommendation(
        "credential_surface",
        score >= 55 ? "high" : "medium",
        "Formular sensibil detectat",
        "Există câmpuri de parolă sau câmpuri care par sensibile. Verifică URL-ul complet înainte de completare.",
        "inspect_credentials_surface"
      ));
      nextChecks.push("Check whether the full URL, protocol, and domain match the service you intended to use.");
    }

    if (forms.externalPostForms > 0) {
      recommendations.push(makeRecommendation(
        "external_form_post",
        "high",
        "Formularul trimite către alt domeniu",
        "Un formular pare să trimită date către un host diferit de pagina curentă.",
        "avoid_form_until_verified"
      ));
      nextChecks.push("Inspect form destination host before submitting.");
    }

    if (scripts.trackers > 0) {
      recommendations.push(makeRecommendation(
        "tracking_surface",
        scripts.trackers >= 6 ? "medium" : "low",
        "Tracking/analytics detectat",
        "Pagina conține scripturi care seamănă cu tracking sau analytics.",
        "privacy_caution"
      ));
    }

    if (links.dangerousDownloads > 0) {
      recommendations.push(makeRecommendation(
        "download_guard",
        "high",
        "Link de descărcare potențial riscant",
        "Au fost detectate extensii executabile sau instalabile. Nu descărca fără verificare.",
        "avoid_download"
      ));
      suggestedActions.push("Do not run downloaded files from this page unless you trust the source.");
    }

    if (phishing.length > 0) {
      recommendations.push(makeRecommendation(
        "phishing_surface",
        "high",
        "Suprafață de phishing posibilă",
        "URL-ul/titlul/domeniul conține termeni de autentificare, securitate sau brand care merită verificați.",
        "verify_identity"
      ));
    }

    if (dark && dark.hits && dark.hits.length > 0) {
      recommendations.push(makeRecommendation(
        "dark_pattern_watch",
        "medium",
        "Dark-pattern hints",
        "Unele butoane sau texte par construite pentru presiune psihologică sau acceptare rapidă.",
        "slow_down"
      ));
    }

    if (iframes.external >= 5) {
      recommendations.push(makeRecommendation(
        "iframe_surface",
        "medium",
        "Multe iframe-uri externe",
        "Pagina încarcă mai multe suprafețe externe în interiorul ei.",
        "monitor_embeds"
      ));
    }

    if (trend === "rising") {
      recommendations.push(makeRecommendation(
        "risk_trend_rising",
        "medium",
        "Riscul acestui site pare în creștere",
        "Memoria locală arată că ultimele scoruri au crescut față de vizitele precedente.",
        "compare_sessions"
      ));
    }

    if (trusted && score >= 70) {
      recommendations.push(makeRecommendation(
        "trusted_but_high",
        "high",
        "Site marcat trusted, dar risc ridicat acum",
        "Aetherion vede semnale noi pe un site de încredere. Poate fi o pagină diferită, conținut injectat sau schimbare legitimă.",
        "recheck_trust"
      ));
      nextChecks.push("Reconsider trusted status if this high score repeats.");
    }

    if (categories.length > 0) {
      evidenceCards.push({
        title: "Top risk categories",
        value: categories.map((item) => item.name + ": " + item.score).join(" · ")
      });
    }
    evidenceCards.push({
      title: "Site memory",
      value: profile ? ("visits " + (profile.visits || 0) + " · avg risk " + (profile.avgRisk || 0) + " · trend " + trend) : "no profile yet"
    });
    evidenceCards.push({
      title: "Primary reason",
      value: risk.reasons && risk.reasons[0] ? risk.reasons[0] : "No major reason yet."
    });

    if (settings.recommendationMode === "strict" && score >= 55) {
      suggestedActions.push("Treat this page as untrusted until manually verified.");
    }
    if (settings.recommendationMode === "relaxed" && score < 55) {
      suggestedActions.push("Keep passive monitoring; no strong intervention needed.");
    }

    const summary = (function () {
      if (stance === "GUARD_STRONG") return "Aetherion recomandă protecție puternică pe pagina asta.";
      if (stance === "CAUTION") return "Aetherion recomandă prudență înainte de interacțiuni sensibile.";
      if (stance === "WATCH") return "Aetherion urmărește pagina; există semnale moderate.";
      if (stance === "TRUSTED_OBSERVE") return "Site trusted: monitorizare ușoară, fără intervenții mari.";
      return "Pagina este în monitorizare normală.";
    })();

    return {
      version: "18.0.0",
      createdAt: new Date().toISOString(),
      stance,
      guardLevel,
      confidence,
      summary,
      recommendations: recommendations.slice(0, 8),
      suggestedActions: suggestedActions.slice(0, 6),
      nextChecks: nextChecks.slice(0, 6),
      evidenceCards,
      topCategories: categories,
      trend,
      trusted,
      riskScore: score,
      riskLevel: risk.level || "LOW",
      shouldShowGuardBanner: Boolean(
        settings.agentEnabled !== false &&
        settings.guardBannerEnabled !== false &&
        !trusted &&
        (score >= (settings.guardBannerCriticalOnly ? 80 : 55))
      )
    };
  }

  window.AetherionAgentEngine = {
    decide,
    trendFromProfile,
    topCategories
  };
})();
