/*
 * Aetherion DevOS v18 - Timeline Intelligence+ and Causal Guard+ and Evidence Graph+ and Counterfactual Guard+
 * Local-only temporal analysis engine. Builds a compact, privacy-preserving
 * timeline of page risk changes, DOM bursts, user events, policy shifts, and
 * action outcomes. No network calls, no API key, no server.
 */
(function () {
  "use strict";

  function clamp(value, min, max) {
    const n = Number(value);
    if (!Number.isFinite(n)) return min;
    return Math.max(min, Math.min(max, n));
  }

  function nowIso() { return new Date().toISOString(); }

  function safeArray(value) { return Array.isArray(value) ? value : []; }

  function levelWeight(level) {
    return { LOW: 1, MEDIUM: 2, HIGH: 3, CRITICAL: 4, UNKNOWN: 0 }[String(level || "UNKNOWN").toUpperCase()] || 0;
  }

  function classifyDelta(delta) {
    if (delta >= 25) return "SHARP_RISE";
    if (delta >= 10) return "RISING";
    if (delta <= -25) return "SHARP_DROP";
    if (delta <= -10) return "COOLING";
    return "STABLE";
  }

  function dominantTrigger(points) {
    const counts = {};
    for (const p of safeArray(points)) counts[p.trigger || p.kind || "sample"] = (counts[p.trigger || p.kind || "sample"] || 0) + 1;
    return Object.entries(counts).sort((a, b) => b[1] - a[1])[0]?.[0] || "sample";
  }

  function capturePoint(args) {
    args = args || {};
    const snapshot = args.snapshot || {};
    const risk = args.risk || {};
    const prev = args.previousPoint || null;
    const riskScore = clamp(risk.score ?? snapshot.riskScore ?? 0, 0, 100);
    const mutations = Number(snapshot.mutations || 0);
    const anomalies = Number(snapshot.anomalies || 0);
    const now = Date.now();
    const point = {
      id: "tl-" + now + "-" + Math.random().toString(16).slice(2),
      at: nowIso(),
      t: now,
      trigger: args.trigger || "sample",
      riskScore,
      riskLevel: risk.level || snapshot.riskLevel || "UNKNOWN",
      levelWeight: levelWeight(risk.level || snapshot.riskLevel),
      mutations,
      anomalies,
      userEvents: Object.assign({}, snapshot.userEvents || {}),
      trackerHints: risk.signals && risk.signals.scripts ? Number(risk.signals.scripts.trackers || 0) : 0,
      formCount: risk.signals && risk.signals.forms ? Number(risk.signals.forms.total || 0) : 0,
      downloadRisk: risk.signals && risk.signals.links ? Number(risk.signals.links.dangerousDownloads || 0) : 0,
      deltaRisk: prev ? riskScore - Number(prev.riskScore || 0) : 0,
      deltaMutations: prev ? mutations - Number(prev.mutations || 0) : 0,
      deltaAnomalies: prev ? anomalies - Number(prev.anomalies || 0) : 0,
      notes: []
    };
    if (point.deltaRisk >= 10) point.notes.push("Risk rose since last timeline point.");
    if (point.deltaRisk <= -10) point.notes.push("Risk cooled since last timeline point.");
    if (point.deltaMutations > 80) point.notes.push("Large DOM-change step detected.");
    if (point.deltaAnomalies > 0) point.notes.push("New anomaly burst detected.");
    if (point.downloadRisk > 0) point.notes.push("Risky download surface present.");
    return point;
  }

  function analyze(args) {
    args = args || {};
    const points = safeArray(args.points).slice(-80);
    const snapshot = args.snapshot || {};
    const risk = args.risk || {};
    const report = args.reportIntelligence || {};
    const settings = args.settings || {};
    const first = points[0] || null;
    const last = points[points.length - 1] || null;
    const riskDelta = first && last ? Number(last.riskScore || 0) - Number(first.riskScore || 0) : 0;
    const mutationsDelta = first && last ? Number(last.mutations || 0) - Number(first.mutations || 0) : Number(snapshot.mutations || 0);
    const anomalyDelta = first && last ? Number(last.anomalies || 0) - Number(first.anomalies || 0) : Number(snapshot.anomalies || 0);
    const scores = points.map(p => Number(p.riskScore || 0));
    const minScore = scores.length ? Math.min.apply(null, scores) : 0;
    const maxScore = scores.length ? Math.max.apply(null, scores) : 0;
    const volatility = clamp((maxScore - minScore) + Math.min(35, anomalyDelta * 8) + Math.min(25, mutationsDelta / 80), 0, 100);
    const momentum = classifyDelta(riskDelta);
    const dominant = dominantTrigger(points);
    const recent = points.slice(-10);
    const significant = recent.filter(p => Math.abs(Number(p.deltaRisk || 0)) >= 10 || Number(p.deltaAnomalies || 0) > 0 || Number(p.deltaMutations || 0) > 90);

    let status = "QUIET";
    if (volatility >= 70 || String(risk.level || snapshot.riskLevel || "").toUpperCase() === "CRITICAL") status = "VOLATILE";
    else if (volatility >= 40 || riskDelta >= 15) status = "SHIFTING";
    else if (points.length < 3) status = "WARMING";
    else status = "STABLE";

    const redFlags = [];
    const greenFlags = [];
    if (riskDelta >= 20) redFlags.push("Risk rose sharply during this page session.");
    if (anomalyDelta > 0) redFlags.push("Timeline recorded new anomaly bursts.");
    if (volatility >= 70) redFlags.push("High temporal volatility: page behavior changed strongly over time.");
    if (riskDelta <= -15) greenFlags.push("Risk cooled during the session.");
    if (status === "STABLE" && (risk.score || snapshot.riskScore || 0) < 35) greenFlags.push("Timeline is stable and current risk is low.");
    if (points.length >= 5 && significant.length === 0) greenFlags.push("No major temporal jumps detected in recent samples.");

    const recommendations = [];
    if (status === "VOLATILE") recommendations.push({ title: "Keep protective posture", detail: "Page behavior changed strongly; avoid trusting the site until the pattern stabilizes." });
    if (riskDelta >= 15) recommendations.push({ title: "Review what changed", detail: "Risk increased after recent events; check forms, overlays, downloads, or injected scripts." });
    if (anomalyDelta > 0) recommendations.push({ title: "Save session report", detail: "An anomaly burst was recorded; exporting the report preserves the timeline for comparison." });
    if (!recommendations.length) recommendations.push({ title: "Timeline stable", detail: "No strong temporal change detected. Continue observing normally." });

    return {
      id: "timeline-" + Date.now() + "-" + Math.random().toString(16).slice(2),
      at: nowIso(),
      version: "18.0.0",
      status,
      momentum,
      volatilityScore: Math.round(volatility),
      riskDelta: Math.round(riskDelta),
      mutationDelta: Math.round(mutationsDelta),
      anomalyDelta: Math.round(anomalyDelta),
      dominantTrigger: dominant,
      eventCount: points.length,
      significantEventCount: significant.length,
      latestPoint: last,
      firstPoint: first,
      recentPoints: recent,
      significantEvents: significant.slice(-6),
      redFlags,
      greenFlags,
      recommendations,
      summary: `Timeline ${status.toLowerCase()}: risk ${riskDelta >= 0 ? "+" : ""}${Math.round(riskDelta)}, volatility ${Math.round(volatility)}, dominant trigger ${dominant}.`,
      compression: {
        minScore, maxScore,
        currentScore: risk.score ?? snapshot.riskScore ?? 0,
        currentLevel: risk.level || snapshot.riskLevel || "UNKNOWN",
        reportGrade: report.reportGrade || null,
        reportHealthBand: report.healthBand || null,
        captureMode: settings.timelineAutoCapture === false ? "manual-ish" : "auto"
      }
    };
  }

  window.AetherionTimelineIntelligence = { capturePoint, analyze };
})();
