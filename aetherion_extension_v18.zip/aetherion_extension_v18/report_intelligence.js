/*
 * Aetherion DevOS v18 - Report Intelligence+ and Timeline Intelligence+ and Causal Guard+ and Evidence Graph+ and Counterfactual Guard+
 * Local-only report generator: session/domain summary, timeline, score breakdown,
 * risk/trust/policy narrative, and export-ready payload.
 */
(function () {
  "use strict";

  const VERSION = "18.0.0";

  function clamp(value, min, max) {
    const n = Number(value);
    if (!Number.isFinite(n)) return min;
    return Math.max(min, Math.min(max, n));
  }

  function safeArray(value) { return Array.isArray(value) ? value : []; }
  function safeObject(value) { return value && typeof value === "object" && !Array.isArray(value) ? value : {}; }
  function round(value) { return Math.round(Number(value) || 0); }

  function riskBand(score) {
    const s = clamp(score, 0, 100);
    if (s >= 85) return "CRITICAL";
    if (s >= 65) return "HIGH";
    if (s >= 35) return "MEDIUM";
    return "LOW";
  }

  function reportGrade(score) {
    const s = clamp(score, 0, 100);
    if (s >= 85) return "A";
    if (s >= 70) return "B";
    if (s >= 55) return "C";
    if (s >= 40) return "D";
    return "E";
  }

  function severityFromRisk(score) {
    const s = clamp(score, 0, 100);
    if (s >= 85) return "critical";
    if (s >= 65) return "high";
    if (s >= 35) return "medium";
    return "low";
  }

  function scoreBreakdown(snapshot) {
    const signals = safeObject(snapshot.signals);
    const scripts = safeObject(signals.scripts);
    const forms = safeObject(signals.forms);
    const links = safeObject(signals.links);
    const network = safeObject(signals.network);
    const userEvents = safeObject(snapshot.userEvents);
    const learning = safeObject(snapshot.learningProfile);
    const intel = safeObject(snapshot.siteIntelligence);
    const trust = safeObject(snapshot.trustCalibration);
    const policy = safeObject(snapshot.policyDecision);

    const risk = clamp(snapshot.riskScore, 0, 100);
    const trackerPressure = clamp((Number(scripts.trackers) || 0) * 8 + (Number(network.externalIframes) || 0) * 5, 0, 100);
    const sensitiveSurface = clamp((Number(forms.passwordFields) || 0) * 22 + (Number(forms.sensitiveFields) || 0) * 9 + (Number(forms.externalActions) || 0) * 16, 0, 100);
    const downloadSurface = clamp((Number(links.dangerousDownloads) || 0) * 30 + (Number(userEvents.downloadsClicked) || 0) * 16, 0, 100);
    const instability = clamp((Number(snapshot.anomalies) || 0) * 18 + (Number(learning.suspicionIndex) || 0) * 0.6 + (Number(intel.volatilityScore) || 0) * 0.4, 0, 100);
    const trustDrag = clamp(100 - (Number(trust.trustScore) || 50), 0, 100);
    const policyPressure = policy.status === "STRICT" || policy.effectivePolicyMode === "strict" ? 75 : policy.effectivePolicyMode === "protective" ? 58 : policy.mode === "observe" ? 18 : 35;

    return {
      risk,
      trackerPressure: round(trackerPressure),
      sensitiveSurface: round(sensitiveSurface),
      downloadSurface: round(downloadSurface),
      instability: round(instability),
      trustDrag: round(trustDrag),
      policyPressure: round(policyPressure)
    };
  }

  function makeTimeline(snapshot) {
    const risk = clamp(snapshot.riskScore, 0, 100);
    const intel = safeObject(snapshot.siteIntelligence);
    const learning = safeObject(snapshot.learningProfile);
    const trust = safeObject(snapshot.trustCalibration);
    const policy = safeObject(snapshot.policyDecision);
    const actionPlan = safeObject(snapshot.actionPlan);
    const actions = safeArray(actionPlan.actions);
    const applied = safeArray(snapshot.appliedActions);
    const reasons = safeArray(snapshot.riskReasons);
    return [
      {
        label: "Page scan",
        level: severityFromRisk(risk),
        value: riskBand(risk) + " " + round(risk) + "/100",
        detail: reasons[0] || "Local heuristic scan completed."
      },
      {
        label: "Site intelligence",
        level: severityFromRisk(100 - (Number(intel.reputationScore) || 50)),
        value: (intel.reputationLevel || "NEW") + " · " + (intel.trendDirection || "NEW"),
        detail: intel.summary || "Domain profile compared with local memory."
      },
      {
        label: "Learning profile",
        level: severityFromRisk(Number(learning.suspicionIndex) || 0),
        value: (learning.learningClass || "WARMING_UP") + " · " + (learning.confidence || 0) + "%",
        detail: learning.summary || "Learning classifier warming up."
      },
      {
        label: "Trust calibration",
        level: severityFromRisk(100 - (Number(trust.trustScore) || 50)),
        value: (trust.effectiveTrustLevel || "local") + " · " + (trust.trustScore ?? "--") + "/100",
        detail: trust.summary || "Trust posture evaluated locally."
      },
      {
        label: "Policy gate",
        level: policy.blockedActions && policy.blockedActions.length ? "medium" : "low",
        value: (policy.effectivePolicyMode || policy.mode || "balanced") + " · " + (policy.status || "READY"),
        detail: policy.summary || "Policy Engine reviewed possible actions."
      },
      {
        label: "Action planner",
        level: actions.length ? "medium" : "low",
        value: actions.length + " proposed · " + applied.length + " applied",
        detail: actionPlan.summary || "No action cards required yet."
      }
    ];
  }

  function makeFlags(snapshot, breakdown) {
    const signals = safeObject(snapshot.signals);
    const scripts = safeObject(signals.scripts);
    const forms = safeObject(signals.forms);
    const links = safeObject(signals.links);
    const trust = safeObject(snapshot.trustCalibration);
    const intel = safeObject(snapshot.siteIntelligence);
    const learning = safeObject(snapshot.learningProfile);
    const red = [];
    const green = [];

    if ((Number(snapshot.riskScore) || 0) >= 65) red.push("High local risk score.");
    if ((Number(scripts.trackers) || 0) > 0) red.push("Tracker/analytics script hints detected.");
    if ((Number(forms.passwordFields) || 0) > 0 || (Number(forms.sensitiveFields) || 0) > 0) red.push("Sensitive form surface detected.");
    if ((Number(links.dangerousDownloads) || 0) > 0) red.push("Risky download links found.");
    if ((Number(snapshot.anomalies) || 0) > 0) red.push("DOM activity anomaly burst observed.");
    if (learning.learningClass === "REPEATED_SUSPICIOUS" || learning.learningClass === "VOLATILE_BEHAVIOR") red.push("Learning profile indicates repeated/volatile suspicious behavior.");
    if (trust.effectiveTrustLevel === "blocked" || trust.effectiveTrustLevel === "sensitive") red.push("Trust level asks for stronger handling.");

    if ((Number(snapshot.riskScore) || 0) < 35) green.push("Low risk score in the current scan.");
    if ((Number(scripts.trackers) || 0) === 0) green.push("No obvious tracker hints from simple local scan.");
    if ((Number(links.dangerousDownloads) || 0) === 0) green.push("No risky executable download links detected.");
    if (intel.trendDirection === "IMPROVING" || intel.reputationLevel === "GOOD") green.push("Local site intelligence is positive.");
    if (trust.effectiveTrustLevel === "trusted") green.push("User trust calibration marks this domain as trusted.");

    return {
      redFlags: red.slice(0, 8),
      greenFlags: green.slice(0, 8),
      mainPressure: Object.entries(breakdown).sort((a, b) => b[1] - a[1])[0] || ["risk", Number(snapshot.riskScore) || 0]
    };
  }

  function makeRecommendations(snapshot, breakdown, flags) {
    const recs = [];
    const risk = Number(snapshot.riskScore) || 0;
    const policy = safeObject(snapshot.policyDecision);
    const trust = safeObject(snapshot.trustCalibration);
    const learning = safeObject(snapshot.learningProfile);

    if (risk >= 65) recs.push({ title: "Use protective posture", detail: "Keep Policy Engine in protective/strict mode for this domain until risk stabilizes.", severity: "high" });
    if (breakdown.sensitiveSurface >= 35) recs.push({ title: "Review sensitive forms", detail: "Check form destinations and avoid entering sensitive data unless the page is expected and trusted.", severity: "high" });
    if (breakdown.trackerPressure >= 35) recs.push({ title: "Privacy review", detail: "Tracker hints or external frames are present; keep privacy note/action cards enabled.", severity: "medium" });
    if (breakdown.downloadSurface > 0) recs.push({ title: "Verify downloads", detail: "Executable or package-style downloads should be verified before opening.", severity: "high" });
    if (learning.learningClass === "DYNAMIC_BUT_SAFE") recs.push({ title: "Avoid over-blocking", detail: "This site may be highly dynamic but locally learned as relatively normal.", severity: "low" });
    if (trust.effectiveTrustLevel === "blocked") recs.push({ title: "Blocked trust posture", detail: "Avoid auto-actions that increase trust or reduce protection on this site.", severity: "critical" });
    if ((policy.blockedActions || []).length) recs.push({ title: "Policy blocked actions", detail: "Some actions were blocked locally; review policy mode and site rules if needed.", severity: "medium" });
    if (!recs.length) recs.push({ title: "Continue observing", detail: "No urgent action. Save the session to strengthen the local profile.", severity: "low" });
    return recs.slice(0, 8);
  }

  function makeNarrative(snapshot, breakdown, flags) {
    const risk = Number(snapshot.riskScore) || 0;
    const band = riskBand(risk);
    const intel = safeObject(snapshot.siteIntelligence);
    const learning = safeObject(snapshot.learningProfile);
    const trust = safeObject(snapshot.trustCalibration);
    const policy = safeObject(snapshot.policyDecision);
    const main = flags.mainPressure || ["risk", risk];

    return {
      executiveSummary: `Current page is ${band} risk (${round(risk)}/100). Main pressure: ${main[0]} ${round(main[1])}/100.`,
      riskNarrative: safeArray(snapshot.riskReasons).slice(0, 3).join(" ") || "Risk model did not produce a major reason yet.",
      trustNarrative: trust.summary || `Trust level: ${trust.effectiveTrustLevel || "local"} with score ${trust.trustScore ?? "--"}/100.`,
      policyNarrative: policy.summary || `Policy mode: ${policy.effectivePolicyMode || policy.mode || "balanced"}.`,
      learningNarrative: learning.summary || `Learning class: ${learning.learningClass || "WARMING_UP"}.`,
      siteNarrative: intel.summary || `Site reputation: ${intel.reputationLevel || "NEW"}; trend: ${intel.trendDirection || "NEW"}.`
    };
  }

  function confidence(snapshot) {
    const visits = Number((snapshot.siteIntelligence || {}).visits) || 0;
    const learningConfidence = Number((snapshot.learningProfile || {}).confidence) || 0;
    const eventCount = Object.values(safeObject(snapshot.userEvents)).reduce((sum, value) => sum + (Number(value) || 0), 0);
    return clamp(25 + Math.min(25, visits * 4) + Math.min(25, learningConfidence * 0.25) + Math.min(25, eventCount * 0.5), 15, 99);
  }

  function buildReport(input) {
    input = input || {};
    const snapshot = safeObject(input.snapshot);
    const profile = safeObject(input.profile);
    const breakdown = scoreBreakdown(snapshot);
    const flags = makeFlags(snapshot, breakdown);
    const narrative = makeNarrative(snapshot, breakdown, flags);
    const timeline = makeTimeline(snapshot);
    const recommendations = makeRecommendations(snapshot, breakdown, flags);
    const risk = clamp(snapshot.riskScore, 0, 100);
    const trustScore = Number((snapshot.trustCalibration || {}).trustScore);
    const reportScore = clamp(100 - risk + (Number.isFinite(trustScore) ? (trustScore - 50) * 0.15 : 0) - (Number(snapshot.anomalies) || 0) * 2, 0, 100);
    return {
      reportId: "report-" + Date.now() + "-" + Math.random().toString(16).slice(2),
      at: new Date().toISOString(),
      version: VERSION,
      site: snapshot.site || profile.site || "unknown",
      url: snapshot.url || "",
      title: snapshot.title || "",
      reportScore: round(reportScore),
      reportGrade: reportGrade(reportScore),
      healthBand: reportScore >= 75 ? "HEALTHY" : reportScore >= 55 ? "WATCH" : reportScore >= 35 ? "RISKY" : "DANGER",
      riskBand: riskBand(risk),
      confidence: round(confidence(snapshot)),
      executiveSummary: narrative.executiveSummary,
      narrative,
      scoreBreakdown: breakdown,
      timeline,
      redFlags: flags.redFlags,
      greenFlags: flags.greenFlags,
      recommendations,
      domainDigest: {
        visits: profile.visits || (snapshot.siteIntelligence && snapshot.siteIntelligence.visits) || 0,
        avgRisk: profile.avgRisk,
        maxRisk: profile.maxRisk,
        trustLevel: profile.trustLevel || (snapshot.trustCalibration && snapshot.trustCalibration.effectiveTrustLevel) || "local",
        reputationLevel: snapshot.siteIntelligence && snapshot.siteIntelligence.reputationLevel,
        learningClass: snapshot.learningProfile && snapshot.learningProfile.learningClass,
        policyMode: snapshot.policyDecision && (snapshot.policyDecision.effectivePolicyMode || snapshot.policyDecision.mode)
      },
      exportPayload: {
        generatedAt: new Date().toISOString(),
        product: "Aetherion DevOS",
        version: VERSION,
        snapshot,
        profile
      }
    };
  }

  function toMarkdown(report) {
    report = safeObject(report);
    const lines = [];
    lines.push("# Aetherion Report Intelligence+ and Timeline Intelligence+ and Causal Guard+ and Evidence Graph+ and Counterfactual Guard+");
    lines.push("");
    lines.push(`- Site: ${report.site || "unknown"}`);
    lines.push(`- URL: ${report.url || ""}`);
    lines.push(`- Generated: ${report.at || ""}`);
    lines.push(`- Health: ${report.healthBand || "--"} · Grade ${report.reportGrade || "--"} · Score ${report.reportScore ?? "--"}/100`);
    lines.push(`- Risk: ${report.riskBand || "--"} · Confidence ${report.confidence ?? "--"}%`);
    lines.push("");
    lines.push("## Executive summary");
    lines.push(report.executiveSummary || "No summary.");
    lines.push("");
    lines.push("## Timeline");
    for (const item of safeArray(report.timeline)) lines.push(`- ${item.label}: ${item.value} — ${item.detail}`);
    lines.push("");
    lines.push("## Red flags");
    const red = safeArray(report.redFlags);
    lines.push(red.length ? red.map((x) => `- ${x}`).join("\n") : "- None.");
    lines.push("");
    lines.push("## Green flags");
    const green = safeArray(report.greenFlags);
    lines.push(green.length ? green.map((x) => `- ${x}`).join("\n") : "- None.");
    lines.push("");
    lines.push("## Recommendations");
    for (const rec of safeArray(report.recommendations)) lines.push(`- [${rec.severity || "info"}] ${rec.title}: ${rec.detail}`);
    return lines.join("\n");
  }

  window.AetherionReportIntelligence = { VERSION, buildReport, toMarkdown };
})();
