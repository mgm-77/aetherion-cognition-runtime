/*
 * Aetherion DevOS v18 - Policy Engine+
 * Local-only policy layer: permits, denies, explains, and safely gates manual/auto actions.
 */
(function () {
  "use strict";

  const VERSION = "18.0.0";

  const ACTION_CLASSES = {
    NOOP: { family: "observe", reversible: true, autoSafe: false, manualSafe: true },
    SHOW_GUARD_BANNER: { family: "guard", reversible: true, autoSafe: true, manualSafe: true },
    PRIVACY_FOCUS_OVERLAY: { family: "visual", reversible: true, autoSafe: true, manualSafe: true },
    SET_COMPACT_OVERLAY: { family: "comfort", reversible: true, autoSafe: true, manualSafe: true },
    SAVE_SESSION: { family: "memory", reversible: false, autoSafe: true, manualSafe: true },
    HIGHLIGHT_FORMS: { family: "visual", reversible: true, autoSafe: false, manualSafe: true },
    MARK_DOWNLOAD_LINKS: { family: "visual", reversible: true, autoSafe: false, manualSafe: true },
    HIDE_INTRUSIVE_OVERLAYS: { family: "page_cleanup", reversible: true, autoSafe: false, manualSafe: true },
    MARK_TRUSTED_SITE: { family: "trust", reversible: true, autoSafe: false, manualSafe: true }
  };

  function clamp(value, min, max) {
    const n = Number(value);
    if (!Number.isFinite(n)) return min;
    return Math.max(min, Math.min(max, n));
  }

  function riskBand(score) {
    if (score >= 80) return "critical";
    if (score >= 55) return "high";
    if (score >= 30) return "medium";
    return "low";
  }

  function getSignals(risk, snapshot) {
    return (risk && risk.signals) || (snapshot && snapshot.signals) || {};
  }

  function hasPhishingSurface(risk, snapshot) {
    const signals = getSignals(risk, snapshot);
    const items = signals.phishingIndicators || [];
    const forms = signals.forms || {};
    return items.length > 0 || Number(forms.passwordFields || 0) > 0 && Number(forms.externalActionForms || 0) > 0;
  }

  function hasDangerousDownloadSurface(risk, snapshot) {
    const signals = getSignals(risk, snapshot);
    const links = signals.links || {};
    return Number(links.dangerousDownloads || 0) > 0;
  }

  function hasDarkPatternSurface(risk, snapshot) {
    const signals = getSignals(risk, snapshot);
    const dark = signals.darkPatterns || {};
    return Array.isArray(dark.hits) && dark.hits.length > 0;
  }

  function modeValue(settings) {
    const mode = String(settings.policyMode || settings.recommendationMode || "balanced").toLowerCase();
    if (["observe", "relaxed", "balanced", "protective", "strict"].includes(mode)) return mode;
    return "balanced";
  }

  function isPolicyEnabled(settings) {
    return settings.policyEnabled !== false;
  }

  function classFor(action) {
    return ACTION_CLASSES[action && action.type] || { family: "unknown", reversible: false, autoSafe: false, manualSafe: false };
  }

  function evaluateAction(action, context) {
    const settings = context.settings || {};
    const profile = context.profile || null;
    const risk = context.risk || {};
    const snapshot = context.snapshot || {};
    const score = clamp(risk.score || snapshot.riskScore || 0, 0, 100);
    const band = riskBand(score);
    const mode = context.mode;
    const trusted = Boolean(profile && profile.trusted);
    const kind = classFor(action);
    const trace = [];
    const decision = {
      id: action.id || action.type || "unknown_action",
      type: action.type || "UNKNOWN",
      title: action.title || action.type || "Unknown action",
      family: kind.family,
      severity: action.severity || "low",
      requiresConfirm: Boolean(action.requiresConfirm),
      reversible: Boolean(kind.reversible),
      manualAllowed: false,
      autoAllowed: false,
      blocked: false,
      reasons: [],
      ruleIds: []
    };

    if (action.type === "NOOP") {
      decision.manualAllowed = true;
      decision.reasons.push("Observation-only action.");
      decision.ruleIds.push("P0_NOOP_ALLOW");
      return decision;
    }

    if (Array.isArray(settings.ruleBlockedActionTypes) && settings.ruleBlockedActionTypes.includes(action.type)) {
      decision.manualAllowed = false;
      decision.autoAllowed = false;
      decision.blocked = true;
      decision.reasons.push("Blocked by Rule Composer+ for this site.");
      decision.ruleIds.push("RC1_SITE_RULE_BLOCK");
      return decision;
    }

    const trust = settings.trustCalibrationDecision || {};
    const effectiveTrustLevel = String(trust.effectiveTrustLevel || "local").toLowerCase();
    if (effectiveTrustLevel === "blocked" && !["NOOP", "SHOW_GUARD_BANNER", "SAVE_SESSION", "SET_COMPACT_OVERLAY", "PRIVACY_FOCUS_OVERLAY"].includes(action.type)) {
      decision.manualAllowed = false;
      decision.autoAllowed = false;
      decision.blocked = true;
      decision.reasons.push("Blocked-site trust calibration allows only observation, guard, compact, privacy note, or session save.");
      decision.ruleIds.push("TC1_BLOCKED_TRUST_LEVEL_RESTRICTS_ACTION");
      return decision;
    }
    if ((effectiveTrustLevel === "sensitive" || effectiveTrustLevel === "blocked") && action.type === "MARK_TRUSTED_SITE") {
      decision.manualAllowed = false;
      decision.autoAllowed = false;
      decision.blocked = true;
      decision.reasons.push("Trust promotion blocked while Trust Calibration+ and Report Intelligence+ and Timeline Intelligence+ and Causal Guard+ and Evidence Graph+ and Counterfactual Guard+ is sensitive/blocked.");
      decision.ruleIds.push("TC2_NO_TRUST_PROMOTION_ON_SENSITIVE_OR_BLOCKED");
      return decision;
    }

    if (!isPolicyEnabled(settings)) {
      decision.manualAllowed = true;
      decision.autoAllowed = false;
      decision.reasons.push("Policy engine disabled: manual action allowed, auto action disabled.");
      decision.ruleIds.push("P0_POLICY_DISABLED_MANUAL_ONLY");
      return decision;
    }

    // Manual gate: allow most local/reversible actions, deny trust promotion on risky pages.
    if (kind.manualSafe) {
      decision.manualAllowed = true;
      decision.ruleIds.push("P1_LOCAL_MANUAL_ALLOWED");
      trace.push("manual local action allowed");
    }

    if (action.type === "MARK_TRUSTED_SITE") {
      if (score >= 35 || hasPhishingSurface(risk, snapshot) || hasDangerousDownloadSurface(risk, snapshot)) {
        decision.manualAllowed = false;
        decision.blocked = true;
        decision.reasons.push("Trust promotion blocked because this page still has risk/phishing/download signals.");
        decision.ruleIds.push("P2_BLOCK_TRUST_PROMOTION_ON_RISK");
      } else {
        decision.reasons.push("Trust promotion allowed only because current local risk is low.");
        decision.ruleIds.push("P2_LOW_RISK_TRUST_ALLOWED");
      }
    }

    if (action.type === "HIDE_INTRUSIVE_OVERLAYS") {
      if (mode === "observe" || mode === "relaxed" && score < 70) {
        decision.reasons.push("Overlay hiding remains manual in observe/relaxed mode.");
        decision.ruleIds.push("P3_OVERLAY_MANUAL_ONLY_BY_MODE");
      } else if (score >= 55 || hasDarkPatternSurface(risk, snapshot)) {
        decision.reasons.push("Overlay cleanup allowed manually because risk/dark-pattern surface is present.");
        decision.ruleIds.push("P3_OVERLAY_MANUAL_ALLOWED_ON_RISK");
      }
    }

    if (trusted && score < 45 && ["HIGHLIGHT_FORMS", "MARK_DOWNLOAD_LINKS", "HIDE_INTRUSIVE_OVERLAYS"].includes(action.type)) {
      decision.reasons.push("Trusted low-risk site: keep assist manual to avoid noise.");
      decision.ruleIds.push("P4_TRUSTED_LOW_RISK_MANUAL_ONLY");
    }

    // Auto gate: conservative by design.
    const autoMode = settings.autoModeEnabled === true;
    const dryRun = settings.policyDryRun === true;
    if (!autoMode) {
      decision.autoAllowed = false;
      decision.reasons.push("Auto-mode disabled.");
      decision.ruleIds.push("A0_AUTO_DISABLED");
    } else if (dryRun) {
      decision.autoAllowed = false;
      decision.reasons.push("Policy dry-run enabled: would evaluate auto-action but will not execute.");
      decision.ruleIds.push("A0_DRY_RUN");
    } else if (kind.family === "visual" && settings.autoApplyVisualSafeActions === false) {
      decision.autoAllowed = false;
      decision.reasons.push("Auto visual assists disabled by policy settings.");
      decision.ruleIds.push("A1_VISUAL_AUTO_DISABLED");
    } else if (!kind.autoSafe) {
      decision.autoAllowed = false;
      decision.reasons.push("Action is not in the auto-safe allowlist.");
      decision.ruleIds.push("A1_NOT_AUTO_SAFE");
    } else if (action.requiresConfirm) {
      decision.autoAllowed = false;
      decision.reasons.push("Action requires confirmation, so auto-mode cannot execute it.");
      decision.ruleIds.push("A2_CONFIRMATION_REQUIRED");
    } else if (trusted && score < 45 && action.type !== "SET_COMPACT_OVERLAY") {
      decision.autoAllowed = false;
      decision.reasons.push("Trusted low-risk page: auto-mode suppressed to avoid noise.");
      decision.ruleIds.push("A3_TRUSTED_LOW_RISK_SUPPRESS");
    } else if (action.type === "SAVE_SESSION" && settings.autoApplyMemoryActions === false) {
      decision.autoAllowed = false;
      decision.reasons.push("Auto-save policy actions disabled.");
      decision.ruleIds.push("A4_MEMORY_AUTO_DISABLED");
    } else if (["PRIVACY_FOCUS_OVERLAY", "SHOW_GUARD_BANNER", "SAVE_SESSION", "SET_COMPACT_OVERLAY"].includes(action.type)) {
      decision.autoAllowed = true;
      decision.reasons.push("Auto-safe local action permitted by policy.");
      decision.ruleIds.push("A5_AUTO_SAFE_ALLOWED");
    }

    if ((mode === "protective" || mode === "strict") && score >= 80 && action.type === "SHOW_GUARD_BANNER" && autoMode && !dryRun) {
      decision.autoAllowed = true;
      decision.reasons.push("Protective/strict critical-risk rule keeps the guard visible automatically.");
      decision.ruleIds.push("A6_CRITICAL_GUARD_AUTO");
    }

    if (decision.blocked) decision.autoAllowed = false;
    if (!decision.reasons.length) decision.reasons.push(trace[0] || "Allowed by default local policy.");
    return decision;
  }

  function summarize(decisions, score, mode, settings) {
    if (settings.policyEnabled === false) return "Policy engine disabled: manual-only fallback.";
    const blocked = decisions.filter((d) => d.blocked).length;
    const auto = decisions.filter((d) => d.autoAllowed).length;
    const manual = decisions.filter((d) => d.manualAllowed && !d.blocked).length;
    const dry = settings.policyDryRun ? " · dry-run" : "";
    return `${mode} policy · risk ${score}/100 · manual ${manual} · auto ${auto} · blocked ${blocked}${dry}`;
  }

  function evaluate(input) {
    const snapshot = input.snapshot || {};
    const risk = input.risk || { score: snapshot.riskScore || 0, level: snapshot.riskLevel || "LOW", signals: snapshot.signals || {} };
    const plan = input.plan || snapshot.actionPlan || { actions: [] };
    const settings = input.settings || {};
    const profile = input.profile || null;
    const score = clamp(risk.score || snapshot.riskScore || 0, 0, 100);
    const mode = modeValue(settings);
    const actions = Array.isArray(plan.actions) ? plan.actions : [];
    const context = { snapshot, risk, plan, settings, profile, mode };
    const decisions = actions.map((action) => evaluateAction(action, context));
    const allowedActions = decisions.filter((d) => d.manualAllowed && !d.blocked);
    const blockedActions = decisions.filter((d) => d.blocked || !d.manualAllowed);
    const autoActions = decisions.filter((d) => d.autoAllowed && !d.blocked);
    const wouldAutoActions = decisions.filter((d) => d.reasons.some((r) => /dry-run/i.test(r)) || d.autoAllowed);

    const restrictions = [];
    if (settings.policyDryRun) restrictions.push("dry_run_no_auto_execution");
    if (settings.actionSafeMode !== false) restrictions.push("safe_mode_on");
    if (profile && profile.trusted) restrictions.push("trusted_site_noise_reduction");
    const trustDecision = settings.trustCalibrationDecision || null;
    if (trustDecision && trustDecision.effectiveTrustLevel) restrictions.push("trust_calibration_" + trustDecision.effectiveTrustLevel);
    if (score >= 80) restrictions.push("critical_risk_guard_priority");
    if (hasPhishingSurface(risk, snapshot)) restrictions.push("phishing_surface_present");
    if (hasDangerousDownloadSurface(risk, snapshot)) restrictions.push("download_surface_present");

    return {
      decisionId: "policy-" + Date.now() + "-" + Math.random().toString(16).slice(2),
      version: VERSION,
      enabled: isPolicyEnabled(settings),
      mode,
      status: isPolicyEnabled(settings) ? "ACTIVE" : "DISABLED",
      riskScore: score,
      riskBand: riskBand(score),
      summary: summarize(decisions, score, mode, settings),
      allowedActions,
      blockedActions,
      autoActions,
      wouldAutoActions,
      restrictions,
      decisions,
      confidence: clamp(70 + (actions.length ? 10 : 0) - (blockedActions.length * 4), 35, 98),
      createdAt: new Date().toISOString(),
      ruleDecision: settings.ruleComposerDecision || null,
      trustCalibration: settings.trustCalibrationDecision || null
    };
  }

  function findDecision(action, policy) {
    if (!action || !policy) return null;
    const decisions = Array.isArray(policy.decisions) ? policy.decisions : [];
    return decisions.find((d) => d.id === action.id || d.type === action.type) || null;
  }

  function canApplyAction(action, policy, context) {
    const d = findDecision(action, policy);
    if (!d) return { allowed: false, reason: "No policy decision found for this action." };
    if (d.blocked || !d.manualAllowed) return { allowed: false, reason: (d.reasons && d.reasons[0]) || "Blocked by policy." };
    return { allowed: true, reason: (d.reasons && d.reasons[0]) || "Allowed by policy.", decision: d, context: context || null };
  }

  function canAutoApplyAction(action, policy, context) {
    const d = findDecision(action, policy);
    if (!d) return { allowed: false, reason: "No policy decision found for this action." };
    if (!d.autoAllowed) return { allowed: false, reason: (d.reasons && d.reasons[0]) || "Auto-action blocked by policy." };
    return { allowed: true, reason: (d.reasons && d.reasons[0]) || "Auto-action allowed by policy.", decision: d, context: context || null };
  }

  window.AetherionPolicyEngine = {
    VERSION,
    ACTION_CLASSES,
    evaluate,
    canApplyAction,
    canAutoApplyAction
  };
})();
