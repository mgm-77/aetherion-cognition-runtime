/*
 * Aetherion DevOS v18 - Evidence Graph+ and Counterfactual Guard+
 * Local-only graph builder: risk -> cause -> evidence -> policy/action -> effect.
 * This is not a remote reputation system. It only links local heuristics and session evidence.
 */
(function () {
  "use strict";

  function clamp(value, min, max) { return Math.max(min, Math.min(max, Number(value || 0))); }
  function safeArray(value) { return Array.isArray(value) ? value : []; }
  function safeNumber(value, fallback) { const n = Number(value); return Number.isFinite(n) ? n : fallback; }
  function text(value, fallback) { return String(value || fallback || ""); }

  function makeId(prefix, raw) {
    return prefix + "-" + String(raw || Math.random().toString(16).slice(2)).toLowerCase().replace(/[^a-z0-9_-]+/g, "-").slice(0, 42);
  }

  function pushNode(nodes, id, type, label, weight, meta) {
    if (!id) return null;
    if (nodes.some((node) => node.id === id)) return id;
    nodes.push({ id, type, label: text(label, type), weight: clamp(weight, 0, 100), meta: meta || {} });
    return id;
  }

  function pushEdge(edges, from, to, relation, weight, evidence) {
    if (!from || !to || from === to) return;
    edges.push({ from, to, relation: text(relation, "links_to"), weight: clamp(weight, 0, 100), evidence: safeArray(evidence).slice(0, 4) });
  }

  function strongestCategory(categories) {
    let best = { name: "unknown", score: 0 };
    Object.keys(categories || {}).forEach((key) => {
      const value = safeNumber(categories[key], 0);
      if (value > best.score) best = { name: key, score: value };
    });
    return best;
  }

  function makeHealthBand(confidence, gapsCount, nodeCount, edgeCount) {
    if (nodeCount < 2 || edgeCount < 1) return "NO_GRAPH";
    if (confidence >= 78 && gapsCount <= 1) return "COHERENT";
    if (confidence >= 55 && gapsCount <= 3) return "PARTIAL";
    if (confidence >= 35) return "WEAK";
    return "LOW_EVIDENCE";
  }

  function build(input) {
    const snapshot = input.snapshot || {};
    const risk = input.risk || { score: snapshot.riskScore || 0, level: snapshot.riskLevel || "UNKNOWN", reasons: [], signals: {}, categories: {} };
    const timeline = input.timelineIntelligence || {};
    const causal = input.causalGuard || {};
    const report = input.reportIntelligence || {};
    const policy = input.policyDecision || {};
    const plan = input.actionPlan || {};
    const agent = input.agentDecision || {};
    const trust = input.trustCalibration || {};
    const intel = input.siteIntelligence || {};
    const learning = input.learningProfile || {};
    const profile = input.profile || {};
    const appliedActions = safeArray(input.appliedActions);
    const nodes = [];
    const edges = [];
    const category = strongestCategory(risk.categories || snapshot.riskCategories || {});
    const riskScore = safeNumber(risk.score, snapshot.riskScore || 0);
    const riskLevel = risk.level || snapshot.riskLevel || "UNKNOWN";

    const riskNode = pushNode(nodes, "risk-current", "risk", `Risk ${riskScore}/100 · ${riskLevel}`, riskScore, {
      level: riskLevel,
      category: category.name,
      reasons: safeArray(risk.reasons || snapshot.riskReasons).slice(0, 5)
    });

    const trendLabel = timeline.momentum || timeline.status || "timeline";
    const timelineWeight = clamp(Math.abs(safeNumber(timeline.riskDelta, 0)) * 5 + safeNumber(timeline.volatilityScore, 0) / 2, 0, 100);
    const timelineNode = pushNode(nodes, "timeline-current", "timeline", `Timeline ${trendLabel} · Δ ${timeline.riskDelta ?? 0}`, timelineWeight, {
      volatilityScore: timeline.volatilityScore,
      eventCount: timeline.eventCount,
      dominantTrigger: timeline.dominantTrigger
    });
    pushEdge(edges, timelineNode, riskNode, "updates_risk", timelineWeight, [timeline.summary]);

    const cause = causal.primaryCause || null;
    let causeNode = null;
    if (cause && cause.type) {
      causeNode = pushNode(nodes, makeId("cause", cause.type), "cause", cause.label || cause.type, cause.impact || causal.causalConfidence || 0, {
        type: cause.type,
        confidence: causal.causalConfidence,
        recommendation: cause.recommendation
      });
      pushEdge(edges, causeNode, riskNode, "explains", causal.causalConfidence || cause.impact || 0, safeArray(cause.evidence));
      safeArray(cause.evidence).slice(0, 5).forEach((ev, index) => {
        const evNode = pushNode(nodes, makeId("evidence", cause.type + "-" + index), "evidence", ev, 45 + index * 3, { source: "causal_guard", causeType: cause.type });
        pushEdge(edges, evNode, causeNode, "supports", 58 - index * 3, [ev]);
      });
    }

    safeArray(causal.causalChain).slice(0, 4).forEach((step) => {
      const id = makeId("chain", step.type || step.step);
      const node = pushNode(nodes, id, "cause_chain", `${step.step || "?"}. ${step.label || step.type}`, step.impact || 0, { step: step.step, evidence: safeArray(step.evidence) });
      pushEdge(edges, node, riskNode, "secondary_explanation", step.impact || 0, step.evidence);
      if (causeNode && node !== causeNode) pushEdge(edges, causeNode, node, "related_cause", Math.min(60, step.impact || 20), []);
    });

    const policyNode = pushNode(nodes, "policy-current", "policy", `Policy ${policy.status || "WARMING"} · ${policy.mode || "balanced"}`, policy.confidence || 35, {
      autoActions: safeArray(policy.autoActions).length,
      blockedActions: safeArray(policy.blockedActions).length,
      summary: policy.summary
    });
    pushEdge(edges, riskNode, policyNode, "gates", policy.confidence || 35, [policy.summary]);

    const actionCount = safeArray(plan.actions).length;
    const planNode = pushNode(nodes, "plan-current", "action_plan", `Action plan · ${actionCount} action(s)`, actionCount ? 55 + actionCount * 4 : 25, { status: plan.status, summary: plan.summary });
    pushEdge(edges, policyNode, planNode, "permits_or_blocks", policy.confidence || 35, [plan.summary]);

    safeArray(plan.actions).slice(0, 6).forEach((action, index) => {
      const node = pushNode(nodes, makeId("action", action.id || action.type || index), "action", action.title || action.type || "Action", action.severity === "critical" ? 90 : action.severity === "high" ? 75 : action.severity === "medium" ? 55 : 35, {
        actionType: action.type,
        severity: action.severity,
        reversible: action.reversible !== false
      });
      pushEdge(edges, planNode, node, "proposes", 50, [action.detail]);
      if (causeNode) pushEdge(edges, causeNode, node, "motivates_action", 45, [cause && cause.recommendation]);
    });

    appliedActions.slice(-5).forEach((entry, index) => {
      const action = entry.action || {};
      const node = pushNode(nodes, makeId("effect", (action.type || "action") + "-" + index), "effect", `Effect: ${entry.result && entry.result.message || action.type || "applied action"}`, entry.result && entry.result.ok ? 65 : 35, {
        auto: Boolean(entry.auto),
        ok: entry.result && entry.result.ok,
        changed: entry.result && entry.result.changed
      });
      pushEdge(edges, planNode, node, "produced_effect", entry.result && entry.result.ok ? 65 : 25, [entry.result && entry.result.message]);
    });

    const trustNode = pushNode(nodes, "trust-current", "trust", `Trust ${trust.effectiveTrustLevel || profile.trustLevel || "local"} · ${trust.trustScore ?? 50}`, trust.trustScore || 50, { policyHint: trust.policyHint, confidence: trust.confidence });
    pushEdge(edges, trustNode, policyNode, "adjusts_policy", trust.confidence || 40, safeArray(trust.reasons));

    const learningNode = pushNode(nodes, "learning-current", "learning", `Learning ${learning.learningClass || "WARMING"}`, learning.confidence || 25, { suspicionIndex: learning.suspicionIndex, policyHint: learning.policyHint });
    pushEdge(edges, learningNode, trustNode, "calibrates_trust", learning.confidence || 25, safeArray(learning.notes));

    const intelNode = pushNode(nodes, "site-intel-current", "site_intelligence", `Site intel ${intel.reputationLevel || "NEW"}`, intel.reputationScore || 25, { trendDirection: intel.trendDirection, visits: intel.visits, behaviorClass: intel.behaviorClass });
    pushEdge(edges, intelNode, learningNode, "feeds_learning", intel.reputationScore || 25, safeArray(intel.notes));

    const reportNode = pushNode(nodes, "report-current", "report", `Report ${report.reportGrade || "--"} · ${report.reportScore ?? "--"}`, report.confidence || 30, { healthBand: report.healthBand, redFlags: safeArray(report.redFlags).length, greenFlags: safeArray(report.greenFlags).length });
    pushEdge(edges, riskNode, reportNode, "summarizes", report.confidence || 30, [report.executiveSummary]);
    if (causeNode) pushEdge(edges, causeNode, reportNode, "documented_by", causal.causalConfidence || 35, [causal.summary]);

    const agentNode = pushNode(nodes, "agent-current", "agent", `Agent ${agent.stance || "OBSERVE"}`, agent.confidence || 35, { summary: agent.summary });
    pushEdge(edges, reportNode, agentNode, "informs_recommendation", agent.confidence || 35, [agent.summary]);

    const gaps = [];
    if (!causeNode) gaps.push("No primary causal node was isolated yet.");
    if (!safeArray(causal.primaryCause && causal.primaryCause.evidence).length) gaps.push("Primary cause has little direct evidence.");
    if (!actionCount) gaps.push("No concrete action cards are currently linked.");
    if (!policy.status) gaps.push("Policy decision is still warming up.");
    if (!timeline.eventCount) gaps.push("Timeline has too few points for strong graph confidence.");

    const avgEdge = edges.length ? edges.reduce((sum, edge) => sum + safeNumber(edge.weight, 0), 0) / edges.length : 0;
    const graphConfidence = clamp(Math.round(
      (causal.causalConfidence || 0) * 0.36 +
      (report.confidence || 0) * 0.18 +
      (agent.confidence || 0) * 0.14 +
      avgEdge * 0.18 +
      Math.min(16, nodes.length) - gaps.length * 4
    ), 0, 99);
    const healthBand = makeHealthBand(graphConfidence, gaps.length, nodes.length, edges.length);

    const topPath = [];
    if (timelineNode) topPath.push("timeline");
    if (causeNode) topPath.push(cause.type || "cause");
    topPath.push("risk");
    if (policyNode) topPath.push("policy");
    if (planNode) topPath.push("action_plan");
    const recommendations = [];
    if (healthBand === "COHERENT") recommendations.push({ title: "Evidence chain coherent", detail: "Risk, cause, policy, and action plan are linked strongly enough for a clear local report." });
    if (gaps.length) recommendations.push({ title: "Graph gaps visible", detail: gaps[0] });
    if (riskScore >= 60 && causeNode) recommendations.push({ title: "Save graph evidence", detail: "Export the report now to preserve cause/evidence/action links for this session." });
    if (!actionCount && riskScore >= 45) recommendations.push({ title: "No action path", detail: "Run Analyze now or switch policy to protective to generate clearer action cards." });
    if (!recommendations.length) recommendations.push({ title: "Continue observing", detail: "The graph has no urgent gap; keep passive monitoring active." });

    return {
      status: healthBand === "NO_GRAPH" ? "WARMING" : "GRAPH_READY",
      graphId: "egraph-" + Date.now() + "-" + Math.random().toString(16).slice(2),
      site: snapshot.site || "",
      riskScore,
      riskLevel,
      healthBand,
      graphConfidence,
      nodeCount: nodes.length,
      edgeCount: edges.length,
      topPath: topPath.join(" → "),
      nodes: nodes.slice(0, 40),
      edges: edges.slice(0, 60),
      gaps: gaps.slice(0, 5),
      recommendations: recommendations.slice(0, 4),
      summary: causeNode
        ? `Evidence Graph links ${cause.label || cause.type} → risk ${riskScore}/100 → ${policy.mode || "balanced"} policy → ${actionCount} action(s).`
        : `Evidence Graph has ${nodes.length} nodes but no strong primary cause yet.`,
      generatedAt: new Date().toISOString(),
      heuristic: true,
      version: "18.0.0"
    };
  }

  window.AetherionEvidenceGraph = { build };
})();
