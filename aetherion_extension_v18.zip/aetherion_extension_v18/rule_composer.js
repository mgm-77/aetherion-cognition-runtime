/*
 * Aetherion DevOS v18 - Rule Composer+
 * Local-only per-site rules. No network, no API key.
 */
(function () {
  "use strict";

  const VERSION = "18.0.0";
  const STORAGE_KEYS = {
    rules: "aetherion.rules.v15",
    ruleLog: "aetherion.ruleLog.v15",
    legacyRulesV11: "aetherion.rules.v11",
    legacyRuleLogV11: "aetherion.ruleLog.v11"
  };

  const PRESETS = {
    NO_BANNER_HERE: {
      label: "No guard banner here",
      description: "Suppress the visible guard banner on this domain while keeping scanning active.",
      settingsPatch: { guardBannerEnabled: false }
    },
    PROTECTIVE_HERE: {
      label: "Protective on this site",
      description: "Use a stronger policy mode on this domain.",
      settingsPatch: { policyMode: "protective", recommendationMode: "strict", guardBannerEnabled: true }
    },
    OBSERVE_HERE: {
      label: "Observe only here",
      description: "Keep this domain calm: observe, no auto-mode, relaxed recommendations.",
      settingsPatch: { policyMode: "observe", recommendationMode: "relaxed", autoModeEnabled: false, policyDryRun: true }
    },
    COMPACT_HERE: {
      label: "Compact overlay here",
      description: "Force compact overlay for this domain.",
      settingsPatch: { compactOverlay: true }
    },
    AUTO_OFF_HERE: {
      label: "Auto-mode off here",
      description: "Disable auto-mode for this domain.",
      settingsPatch: { autoModeEnabled: false, policyDryRun: true }
    },
    BLOCK_VISUAL_ASSISTS_HERE: {
      label: "Block visual assists here",
      description: "Keep analysis but prevent local visual assists from changing the page.",
      settingsPatch: {},
      blockActionTypes: ["HIDE_INTRUSIVE_OVERLAYS", "HIGHLIGHT_FORMS", "MARK_DOWNLOAD_LINKS", "PRIVACY_FOCUS_OVERLAY", "SHOW_GUARD_BANNER"]
    },
    STRICT_SENSITIVE_HERE: {
      label: "Strict sensitive site",
      description: "Use strict policy and block trust promotion on this domain.",
      settingsPatch: { policyMode: "strict", recommendationMode: "strict", guardBannerEnabled: true, autoModeEnabled: false },
      blockActionTypes: ["MARK_TRUSTED_SITE"]
    }
  };

  function hasChromeStorage() {
    return typeof chrome !== "undefined" && chrome.storage && chrome.storage.local;
  }

  function storageGet(keys) {
    return new Promise((resolve) => {
      if (!hasChromeStorage()) return resolve({});
      try { chrome.storage.local.get(keys, (result) => resolve(result || {})); }
      catch (error) { console.warn("[Aetherion RuleComposer] storageGet failed", error); resolve({}); }
    });
  }

  function storageSet(payload) {
    return new Promise((resolve) => {
      if (!hasChromeStorage()) return resolve(false);
      try { chrome.storage.local.set(payload, () => resolve(true)); }
      catch (error) { console.warn("[Aetherion RuleComposer] storageSet failed", error); resolve(false); }
    });
  }

  function safeHostname(urlLike) {
    try { return new URL(urlLike || location.href).hostname; }
    catch (_) { return location.hostname || "unknown"; }
  }

  function safeId(prefix) {
    return prefix + "-" + Date.now() + "-" + Math.random().toString(16).slice(2);
  }

  function normalizeRule(rule) {
    const clean = Object.assign({
      id: safeId("rule"),
      version: VERSION,
      enabled: true,
      label: "Custom Aetherion rule",
      description: "Local rule",
      sitePattern: safeHostname(location.href),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      presetType: "CUSTOM",
      settingsPatch: {},
      blockActionTypes: [],
      priority: 50
    }, rule || {});
    clean.enabled = clean.enabled !== false;
    clean.sitePattern = String(clean.sitePattern || safeHostname(location.href)).trim();
    clean.settingsPatch = clean.settingsPatch && typeof clean.settingsPatch === "object" && !Array.isArray(clean.settingsPatch) ? clean.settingsPatch : {};
    clean.blockActionTypes = Array.isArray(clean.blockActionTypes) ? clean.blockActionTypes : [];
    clean.priority = Number.isFinite(Number(clean.priority)) ? Number(clean.priority) : 50;
    return clean;
  }

  function globToRegExp(pattern) {
    const escaped = String(pattern).replace(/[.+?^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*");
    return new RegExp("^" + escaped + "$", "i");
  }

  function matchesPattern(pattern, site, url) {
    const p = String(pattern || "").trim().toLowerCase();
    const host = String(site || safeHostname(url)).toLowerCase();
    const href = String(url || location.href).toLowerCase();
    if (!p) return false;
    if (p === "*" || p === "<all_urls>") return true;
    if (p.startsWith("/") && p.lastIndexOf("/") > 0) {
      try {
        const last = p.lastIndexOf("/");
        const rx = new RegExp(p.slice(1, last), p.slice(last + 1) || "i");
        return rx.test(host) || rx.test(href);
      } catch (_) { return false; }
    }
    if (p.includes("*")) {
      try { return globToRegExp(p).test(host) || globToRegExp(p).test(href); }
      catch (_) { return false; }
    }
    const bare = p.replace(/^https?:\/\//, "").replace(/\/.*$/, "");
    return host === bare || host.endsWith("." + bare) || href.includes(p);
  }

  async function migrateLegacyIfNeeded() {
    const data = await storageGet([STORAGE_KEYS.rules, STORAGE_KEYS.legacyRulesV11, STORAGE_KEYS.ruleLog, STORAGE_KEYS.legacyRuleLogV11]);
    const payload = {};
    if (!Array.isArray(data[STORAGE_KEYS.rules]) && Array.isArray(data[STORAGE_KEYS.legacyRulesV11])) {
      payload[STORAGE_KEYS.rules] = data[STORAGE_KEYS.legacyRulesV11].map((r) => normalizeRule(Object.assign({}, r, { migratedTo: "v15", migratedAt: new Date().toISOString() })));
    }
    if (!Array.isArray(data[STORAGE_KEYS.ruleLog]) && Array.isArray(data[STORAGE_KEYS.legacyRuleLogV11])) {
      payload[STORAGE_KEYS.ruleLog] = data[STORAGE_KEYS.legacyRuleLogV11];
    }
    if (Object.keys(payload).length) await storageSet(payload);
  }

  async function getRules() {
    await migrateLegacyIfNeeded();
    const data = await storageGet([STORAGE_KEYS.rules]);
    const rules = Array.isArray(data[STORAGE_KEYS.rules]) ? data[STORAGE_KEYS.rules] : [];
    return rules.map(normalizeRule).sort((a, b) => b.priority - a.priority || String(a.label).localeCompare(String(b.label)));
  }

  async function saveRules(rules) {
    const clean = Array.isArray(rules) ? rules.map(normalizeRule) : [];
    await storageSet({ [STORAGE_KEYS.rules]: clean });
    return clean;
  }

  async function addRule(rule) {
    const rules = await getRules();
    const clean = normalizeRule(rule);
    rules.push(clean);
    await saveRules(rules);
    await logEvent({ type: "ADD_RULE", ruleId: clean.id, label: clean.label, sitePattern: clean.sitePattern, presetType: clean.presetType });
    return clean;
  }

  async function addPreset(presetType, sitePattern) {
    const preset = PRESETS[presetType] || PRESETS.PROTECTIVE_HERE;
    const site = sitePattern || safeHostname(location.href);
    return addRule(Object.assign({}, preset, {
      id: safeId("rule"),
      presetType,
      sitePattern: site,
      source: "popup_preset",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }));
  }

  async function removeRule(ruleId) {
    const rules = await getRules();
    const next = rules.filter((r) => r.id !== ruleId);
    await saveRules(next);
    await logEvent({ type: "REMOVE_RULE", ruleId });
    return next;
  }

  async function toggleRule(ruleId, enabled) {
    const rules = await getRules();
    const next = rules.map((r) => r.id === ruleId ? Object.assign({}, r, { enabled: Boolean(enabled), updatedAt: new Date().toISOString() }) : r);
    await saveRules(next);
    await logEvent({ type: "TOGGLE_RULE", ruleId, enabled: Boolean(enabled) });
    return next;
  }

  async function clearRulesForSite(site) {
    const target = site || safeHostname(location.href);
    const rules = await getRules();
    const next = rules.filter((r) => !matchesPattern(r.sitePattern, target, "https://" + target + "/"));
    await saveRules(next);
    await logEvent({ type: "CLEAR_SITE_RULES", site: target, removed: rules.length - next.length });
    return next;
  }

  async function clearAllRules() {
    await saveRules([]);
    await logEvent({ type: "CLEAR_ALL_RULES" });
    return [];
  }

  async function getRuleLog() {
    const data = await storageGet([STORAGE_KEYS.ruleLog]);
    return Array.isArray(data[STORAGE_KEYS.ruleLog]) ? data[STORAGE_KEYS.ruleLog] : [];
  }

  async function logEvent(event) {
    const log = await getRuleLog();
    const clean = Object.assign({
      id: safeId("rule-log"),
      at: new Date().toISOString(),
      site: safeHostname(location.href),
      url: location.href,
      version: VERSION
    }, event || {});
    log.push(clean);
    await storageSet({ [STORAGE_KEYS.ruleLog]: log.slice(-300) });
    return clean;
  }

  function summarizePatch(settingsPatch, blocked) {
    const parts = [];
    const keys = Object.keys(settingsPatch || {});
    keys.forEach((key) => parts.push(`${key}=${settingsPatch[key]}`));
    if (blocked && blocked.length) parts.push(`blocked actions=${blocked.length}`);
    return parts.join(" · ") || "No settings patch.";
  }

  function evaluate(rules, input) {
    const site = (input && input.site) || safeHostname(location.href);
    const url = (input && input.url) || location.href;
    const all = Array.isArray(rules) ? rules.map(normalizeRule) : [];
    const enabled = all.filter((r) => r.enabled !== false);
    const matched = enabled.filter((rule) => matchesPattern(rule.sitePattern, site, url)).sort((a, b) => b.priority - a.priority);
    const settingsPatch = {};
    const blocked = [];
    const notes = [];
    matched.forEach((rule) => {
      Object.assign(settingsPatch, rule.settingsPatch || {});
      (rule.blockActionTypes || []).forEach((type) => { if (!blocked.includes(type)) blocked.push(type); });
      notes.push(`${rule.label}: ${summarizePatch(rule.settingsPatch || {}, rule.blockActionTypes || [])}`);
    });
    if (blocked.length) settingsPatch.ruleBlockedActionTypes = blocked;
    const status = matched.length ? "ACTIVE" : "NO_MATCH";
    const summary = matched.length
      ? `${matched.length} local rule(s) matched ${site}. ${summarizePatch(settingsPatch, blocked)}`
      : `No per-site rule matched ${site}.`;
    return {
      id: "rule-decision-" + Date.now() + "-" + Math.random().toString(16).slice(2),
      version: VERSION,
      status,
      site,
      url,
      allRulesCount: all.length,
      enabledRulesCount: enabled.length,
      matchedRules: matched.map((r) => ({ id: r.id, label: r.label, presetType: r.presetType, sitePattern: r.sitePattern, priority: r.priority, blockActionTypes: r.blockActionTypes || [], settingsPatch: r.settingsPatch || {} })),
      settingsPatch,
      blockedActionTypes: blocked,
      notes,
      summary,
      createdAt: new Date().toISOString()
    };
  }

  window.AetherionRuleComposer = {
    VERSION,
    STORAGE_KEYS,
    PRESETS,
    getRules,
    saveRules,
    addRule,
    addPreset,
    removeRule,
    toggleRule,
    clearRulesForSite,
    clearAllRules,
    getRuleLog,
    logEvent,
    evaluate,
    matchesPattern,
    safeHostname
  };
})();
