/* Aetherion DevOS v18 - MV3 background service worker */
const AETHERION_V18_DEFAULT_SETTINGS = {
  overlayEnabled: true,
  compactOverlay: false,
  guardBannerEnabled: true,
  guardBannerCriticalOnly: false,
  autoSaveSessions: true,
  agentEnabled: true,
  learningProfilesEnabled: true,
  plannerEnabled: true,
  actionSafeMode: true,
  recommendationMode: "balanced",
  maxSessions: 300,
  maxAgentLog: 300,
  maxActionLog: 300,
  maxLearningLog: 300,
  highMutationThreshold: 120,
  criticalMutationThreshold: 350,
  trustedRiskDiscount: 10,
  debugMode: false
};

chrome.runtime.onInstalled.addListener((details) => {
  chrome.storage.local.get(["aetherion.settings.v15", "aetherion.settings.v10"], (data) => {
    if (!data["aetherion.settings.v15"]) {
      chrome.storage.local.set({
        "aetherion.settings.v15": Object.assign({}, AETHERION_V18_DEFAULT_SETTINGS, data["aetherion.settings.v10"] || {}, {
          plannerEnabled: true,
          actionSafeMode: true
        })
      });
    }
  });
  if (details.reason === "install") console.log("Aetherion v18 installed.");
  if (details.reason === "update") console.log("Aetherion updated to v18.");
});
