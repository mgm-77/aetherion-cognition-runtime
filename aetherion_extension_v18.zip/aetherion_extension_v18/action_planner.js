/*
 * Aetherion DevOS v18 - Policy Planner
 * Converts risk + agent guidance into reversible, local, non-destructive action cards.
 */
(function () {
  "use strict";

  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function action(id, type, severity, title, detail, mode, requiresConfirm, data) {
    return {
      id,
      type,
      severity,
      title,
      detail,
      mode: mode || "assist",
      requiresConfirm: requiresConfirm !== false,
      data: data || {},
      createdAt: new Date().toISOString()
    };
  }

  function urgencyFromRisk(score) {
    if (score >= 80) return "critical";
    if (score >= 55) return "high";
    if (score >= 30) return "medium";
    return "low";
  }

  function safeSignals(risk) {
    return (risk && risk.signals) || {};
  }

  function makePlan(input) {
    const snapshot = input.snapshot || {};
    const risk = input.risk || { score: snapshot.riskScore || 0, level: snapshot.riskLevel || "LOW", signals: {} };
    const agent = input.agent || snapshot.agentDecision || {};
    const settings = input.settings || {};
    const profile = input.profile || null;
    const signals = safeSignals(risk);
    const forms = signals.forms || {};
    const scripts = signals.scripts || {};
    const links = signals.links || {};
    const dark = signals.darkPatterns || {};
    const iframes = signals.iframes || {};
    const phishingIndicators = signals.phishingIndicators || [];
    const score = Number(risk.score || snapshot.riskScore || 0);
    const trusted = Boolean(profile && profile.trusted);
    const actions = [];
    const notes = [];

    if (settings.plannerEnabled === false) {
      return {
        planId: "plan-disabled-" + Date.now(),
        status: "DISABLED",
        urgency: "none",
        summary: "Policy Planner is disabled.",
        actions: [],
        notes: ["Enable Planner in the popup to generate action cards."],
        version: "18.0.0"
      };
    }

    if (score >= 55 && (forms.passwordFields > 0 || forms.sensitiveInputs > 0 || phishingIndicators.length > 0)) {
      actions.push(action(
        "highlight_sensitive_forms",
        "HIGHLIGHT_FORMS",
        score >= 80 ? "critical" : "high",
        "Highlight sensitive forms",
        "Draws local outlines around password/sensitive forms and labels external destinations. It does not submit, block, or edit data.",
        "visual_assist",
        true,
        { reason: "sensitive_or_phishing_surface" }
      ));
      notes.push("Form-assist is visual only and reversible.");
    }

    if ((dark && dark.hits && dark.hits.length > 0) || score >= 70) {
      actions.push(action(
        "soft_hide_intrusive_overlays",
        "HIDE_INTRUSIVE_OVERLAYS",
        score >= 80 ? "high" : "medium",
        "Soft-hide intrusive overlays",
        "Attempts to hide large fixed/sticky overlays, cookie walls, and pressure banners. You can restore them instantly with Undo.",
        "page_cleanup",
        true,
        { maxNodes: 8 }
      ));
    }

    if (links.dangerousDownloads > 0) {
      actions.push(action(
        "mark_download_links",
        "MARK_DOWNLOAD_LINKS",
        "high",
        "Mark risky download links",
        "Adds a visible Aetherion warning label near executable/installable download links.",
        "visual_assist",
        true,
        { reason: "dangerous_download_extension" }
      ));
    }

    if (scripts.trackers >= 4 || iframes.external >= 5) {
      actions.push(action(
        "privacy_focus_overlay",
        "PRIVACY_FOCUS_OVERLAY",
        scripts.trackers >= 8 ? "medium" : "low",
        "Show privacy focus note",
        "Adds a small local note summarizing tracker/iframe density for the current page.",
        "visual_assist",
        false,
        { trackers: scripts.trackers || 0, externalIframes: iframes.external || 0 }
      ));
    }

    if (score >= 45) {
      actions.push(action(
        "save_local_report",
        "SAVE_SESSION",
        "medium",
        "Save local session report",
        "Stores this page snapshot, risk reasons, agent decision, and action plan in local extension memory.",
        "memory",
        false,
        { includePlan: true }
      ));
    }

    if (trusted && score < 40) {
      actions.push(action(
        "switch_compact_overlay",
        "SET_COMPACT_OVERLAY",
        "low",
        "Use compact overlay on trusted site",
        "Reduces the page overlay to a small status line for trusted/low-risk pages.",
        "comfort",
        false,
        { compactOverlay: true }
      ));
    }

    if (!trusted && score < 30 && Number(snapshot.durationMs || 0) > 20000) {
      actions.push(action(
        "offer_trust_site",
        "MARK_TRUSTED_SITE",
        "low",
        "Mark site as trusted",
        "Adds this domain to Aetherion local trusted memory. This reduces noise but does not disable analysis.",
        "memory",
        true,
        { trusted: true }
      ));
    }

    if (score >= 80 && settings.guardBannerEnabled !== false) {
      actions.unshift(action(
        "keep_guard_visible",
        "SHOW_GUARD_BANNER",
        "critical",
        "Keep guard banner visible",
        "Keeps the high-risk warning visible while interacting with this page.",
        "guard",
        false,
        { riskScore: score }
      ));
    }

    if (!actions.length) {
      actions.push(action(
        "continue_observing",
        "NOOP",
        "low",
        "Continue observing",
        "No immediate action is needed. Aetherion will keep watching local signals.",
        "observe",
        false
      ));
    }

    const unique = [];
    const seen = new Set();
    for (const item of actions) {
      if (!seen.has(item.id)) {
        seen.add(item.id);
        unique.push(item);
      }
    }

    const actionable = unique.filter((item) => item.type !== "NOOP").length;
    const urgency = urgencyFromRisk(score);
    const stance = agent.stance || "OBSERVE";

    return {
      planId: "plan-" + Date.now() + "-" + Math.random().toString(16).slice(2),
      status: actionable ? "READY" : "OBSERVE",
      urgency,
      summary: actionable
        ? `${actionable} local action${actionable === 1 ? "" : "s"} available · ${stance}`
        : "No local assist needed right now.",
      actions: unique.slice(0, 8),
      notes,
      confidence: clamp((agent.confidence || 35) + (actionable ? 5 : 0), 20, 98),
      version: "18.0.0"
    };
  }

  window.AetherionActionPlanner = { makePlan };
})();
