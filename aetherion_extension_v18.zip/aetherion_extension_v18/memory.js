/*
 * Aetherion DevOS v18 - Memory Layer
 * Local-only MV3 storage helpers for sessions, site profiles, settings, agent decisions, action logs, policy logs, Site Intelligence+, Learning Profiles+, Rule Composer+, Trust Calibration+, and Report Intelligence+ and Timeline Intelligence+ and Causal Guard+ and Evidence Graph+ and Counterfactual Guard+.
 */
(function () {
  "use strict";

  const STORAGE_KEYS = {
    sessions: "aetherion.sessions.v18",
    profiles: "aetherion.siteProfiles.v18",
    settings: "aetherion.settings.v18",
    agentLog: "aetherion.agentLog.v18",
    actionLog: "aetherion.actionLog.v18",
    policyLog: "aetherion.policyLog.v18",
    siteIntelLog: "aetherion.siteIntelLog.v18",
    learningLog: "aetherion.learningLog.v18",
    rules: "aetherion.rules.v18",
    ruleLog: "aetherion.ruleLog.v18",
    trustLog: "aetherion.trustLog.v18",
    reportLog: "aetherion.reportLog.v18",
    timelineLog: "aetherion.timelineLog.v18",
    causalLog: "aetherion.causalLog.v18",
    evidenceGraphLog: "aetherion.evidenceGraphLog.v18",
    counterfactualLog: "aetherion.counterfactualLog.v18",
    legacySessionsV17: "aetherion.sessions.v17",
    legacyProfilesV17: "aetherion.siteProfiles.v17",
    legacySettingsV17: "aetherion.settings.v17",
    legacyAgentLogV17: "aetherion.agentLog.v17",
    legacyActionLogV17: "aetherion.actionLog.v17",
    legacyPolicyLogV17: "aetherion.policyLog.v17",
    legacySiteIntelLogV17: "aetherion.siteIntelLog.v17",
    legacyLearningLogV17: "aetherion.learningLog.v17",
    legacyRulesV17: "aetherion.rules.v17",
    legacyRuleLogV17: "aetherion.ruleLog.v17",
    legacyTrustLogV17: "aetherion.trustLog.v17",
    legacyReportLogV17: "aetherion.reportLog.v17",
    legacyTimelineLogV17: "aetherion.timelineLog.v17",
    legacyCausalLogV17: "aetherion.causalLog.v17",
    legacyEvidenceGraphLogV17: "aetherion.evidenceGraphLog.v17",
    legacySessionsV16: "aetherion.sessions.v16",
    legacyProfilesV16: "aetherion.siteProfiles.v16",
    legacySettingsV16: "aetherion.settings.v16",
    legacyAgentLogV16: "aetherion.agentLog.v16",
    legacyActionLogV16: "aetherion.actionLog.v16",
    legacyPolicyLogV16: "aetherion.policyLog.v16",
    legacySiteIntelLogV16: "aetherion.siteIntelLog.v16",
    legacyLearningLogV16: "aetherion.learningLog.v16",
    legacyRulesV16: "aetherion.rules.v16",
    legacyRuleLogV16: "aetherion.ruleLog.v16",
    legacyTrustLogV16: "aetherion.trustLog.v16",
    legacyReportLogV16: "aetherion.reportLog.v16",
    legacyTimelineLogV16: "aetherion.timelineLog.v16",
    legacyCausalLogV16: "aetherion.causalLog.v16",
    legacySessionsV15: "aetherion.sessions.v15",
    legacyProfilesV15: "aetherion.siteProfiles.v15",
    legacySettingsV15: "aetherion.settings.v15",
    legacyAgentLogV15: "aetherion.agentLog.v15",
    legacyActionLogV15: "aetherion.actionLog.v15",
    legacyPolicyLogV15: "aetherion.policyLog.v15",
    legacySiteIntelLogV15: "aetherion.siteIntelLog.v15",
    legacyLearningLogV15: "aetherion.learningLog.v15",
    legacyRulesV15: "aetherion.rules.v15",
    legacyRuleLogV15: "aetherion.ruleLog.v15",
    legacyTrustLogV15: "aetherion.trustLog.v15",
    legacyReportLogV15: "aetherion.reportLog.v15",
    legacyTimelineLogV15: "aetherion.timelineLog.v15",
    legacySessionsV14: "aetherion.sessions.v14",
    legacyProfilesV14: "aetherion.siteProfiles.v14",
    legacySettingsV14: "aetherion.settings.v14",
    legacyAgentLogV14: "aetherion.agentLog.v14",
    legacyActionLogV14: "aetherion.actionLog.v14",
    legacyPolicyLogV14: "aetherion.policyLog.v14",
    legacySiteIntelLogV14: "aetherion.siteIntelLog.v14",
    legacyLearningLogV14: "aetherion.learningLog.v14",
    legacyRulesV14: "aetherion.rules.v14",
    legacyRuleLogV14: "aetherion.ruleLog.v14",
    legacyTrustLogV14: "aetherion.trustLog.v14",
    legacyReportLogV14: "aetherion.reportLog.v14",
    legacySessionsV13: "aetherion.sessions.v13",
    legacyProfilesV13: "aetherion.siteProfiles.v13",
    legacySettingsV13: "aetherion.settings.v13",
    legacyAgentLogV13: "aetherion.agentLog.v13",
    legacyActionLogV13: "aetherion.actionLog.v13",
    legacyPolicyLogV13: "aetherion.policyLog.v13",
    legacySiteIntelLogV13: "aetherion.siteIntelLog.v13",
    legacyLearningLogV13: "aetherion.learningLog.v13",
    legacyRulesV13: "aetherion.rules.v13",
    legacyRuleLogV13: "aetherion.ruleLog.v13",
    legacyTrustLogV13: "aetherion.trustLog.v13",
    legacySessionsV12: "aetherion.sessions.v12",
    legacyProfilesV12: "aetherion.siteProfiles.v12",
    legacySettingsV12: "aetherion.settings.v12",
    legacyAgentLogV12: "aetherion.agentLog.v12",
    legacyActionLogV12: "aetherion.actionLog.v12",
    legacyPolicyLogV12: "aetherion.policyLog.v12",
    legacySiteIntelLogV12: "aetherion.siteIntelLog.v12",
    legacyLearningLogV12: "aetherion.learningLog.v12",
    legacyRulesV12: "aetherion.rules.v12",
    legacyRuleLogV12: "aetherion.ruleLog.v12",
    legacyRulesV11: "aetherion.rules.v11",
    legacyRuleLogV11: "aetherion.ruleLog.v11",
    legacySessionsV10: "aetherion.sessions.v10",
    legacyProfilesV10: "aetherion.siteProfiles.v10",
    legacySettingsV10: "aetherion.settings.v10",
    legacyAgentLogV10: "aetherion.agentLog.v10",
    legacyActionLogV10: "aetherion.actionLog.v10",
    legacyPolicyLogV10: "aetherion.policyLog.v10",
    legacySiteIntelLogV10: "aetherion.siteIntelLog.v10",
    legacySessionsV9: "aetherion.sessions.v9",
    legacyProfilesV9: "aetherion.siteProfiles.v9",
    legacySettingsV9: "aetherion.settings.v9",
    legacyAgentLogV9: "aetherion.agentLog.v9",
    legacyActionLogV9: "aetherion.actionLog.v9",
    legacyPolicyLogV9: "aetherion.policyLog.v9",
    legacySessionsV8: "aetherion.sessions.v8",
    legacyProfilesV8: "aetherion.siteProfiles.v8",
    legacySettingsV8: "aetherion.settings.v8",
    legacyAgentLogV8: "aetherion.agentLog.v8",
    legacyActionLogV8: "aetherion.actionLog.v8",
    legacySessionsV7: "aetherion.sessions.v7",
    legacyProfilesV7: "aetherion.siteProfiles.v7",
    legacySettingsV7: "aetherion.settings.v7",
    legacyAgentLogV7: "aetherion.agentLog.v7",
    legacySessionsV6: "aetherion.sessions.v6",
    legacyProfilesV6: "aetherion.siteProfiles.v6",
    legacySettingsV6: "aetherion.settings.v6"
  };

  const DEFAULT_SETTINGS = {
    overlayEnabled: true,
    compactOverlay: false,
    guardBannerEnabled: true,
    guardBannerCriticalOnly: false,
    autoSaveSessions: true,
    agentEnabled: true,
    plannerEnabled: true,
    actionSafeMode: true,
    policyEnabled: true,
    policyMode: "balanced",
    autoModeEnabled: false,
    autoApplyVisualSafeActions: true,
    autoApplyMemoryActions: true,
    policyDryRun: false,
    siteIntelligenceEnabled: true,
    learningProfilesEnabled: true,
    ruleComposerEnabled: true,
    trustCalibrationEnabled: true,
    reportIntelligenceEnabled: true,
    reportAutoBuild: true,
    timelineIntelligenceEnabled: true,
    timelineAutoCapture: true,
    causalGuardEnabled: true,
    evidenceGraphEnabled: true,
    counterfactualGuardEnabled: true,
    adaptivePolicyHints: true,
    siteReputationSensitivity: "balanced",
    learningSensitivity: "balanced",
    recommendationMode: "balanced",
    maxSessions: 300,
    maxAgentLog: 300,
    maxActionLog: 300,
    maxPolicyLog: 300,
    maxSiteIntelLog: 300,
    maxLearningLog: 300,
    maxRuleLog: 300,
    maxTrustLog: 300,
    maxReportLog: 300,
    maxTimelineLog: 300,
    maxCausalLog: 300,
    maxEvidenceGraphLog: 300,
    maxCounterfactualLog: 300,
    highMutationThreshold: 120,
    criticalMutationThreshold: 350,
    trustedRiskDiscount: 10,
    debugMode: false
  };

  function hasChromeStorage() {
    return typeof chrome !== "undefined" && chrome.storage && chrome.storage.local;
  }

  function storageGet(keys) {
    return new Promise((resolve) => {
      if (!hasChromeStorage()) return resolve({});
      try { chrome.storage.local.get(keys, (result) => resolve(result || {})); }
      catch (error) { console.warn("[Aetherion] storageGet failed", error); resolve({}); }
    });
  }

  function storageSet(payload) {
    return new Promise((resolve) => {
      if (!hasChromeStorage()) return resolve(false);
      try { chrome.storage.local.set(payload, () => resolve(true)); }
      catch (error) { console.warn("[Aetherion] storageSet failed", error); resolve(false); }
    });
  }

  function safeHostname(urlLike) {
    try { return new URL(urlLike || location.href).hostname; }
    catch (_) { return location.hostname || "unknown"; }
  }

  function safeNumber(value, fallback) {
    const n = Number(value);
    return Number.isFinite(n) ? n : fallback;
  }

  function firstArray(obj, keys) {
    for (const key of keys) if (Array.isArray(obj[key])) return obj[key];
    return null;
  }

  function firstObject(obj, keys) {
    for (const key of keys) if (obj[key] && typeof obj[key] === "object" && !Array.isArray(obj[key])) return obj[key];
    return null;
  }

  async function migrateLegacyIfNeeded() {
    const current = await storageGet([STORAGE_KEYS.sessions, STORAGE_KEYS.profiles, STORAGE_KEYS.settings, STORAGE_KEYS.learningLog, STORAGE_KEYS.reportLog, STORAGE_KEYS.timelineLog, STORAGE_KEYS.counterfactualLog]);
    const alreadyInitialized = Boolean(current[STORAGE_KEYS.sessions] || current[STORAGE_KEYS.profiles] || current[STORAGE_KEYS.settings]);
    if (alreadyInitialized) return false;

    const legacy = await storageGet([
      STORAGE_KEYS.legacySessionsV17, STORAGE_KEYS.legacyProfilesV17, STORAGE_KEYS.legacySettingsV17, STORAGE_KEYS.legacyAgentLogV17, STORAGE_KEYS.legacyActionLogV17, STORAGE_KEYS.legacyPolicyLogV17, STORAGE_KEYS.legacySiteIntelLogV17, STORAGE_KEYS.legacyLearningLogV17, STORAGE_KEYS.legacyRulesV17, STORAGE_KEYS.legacyRuleLogV17, STORAGE_KEYS.legacyTrustLogV17, STORAGE_KEYS.legacyReportLogV17, STORAGE_KEYS.legacyTimelineLogV17, STORAGE_KEYS.legacyCausalLogV17, STORAGE_KEYS.legacyEvidenceGraphLogV17,
      STORAGE_KEYS.legacySessionsV16, STORAGE_KEYS.legacyProfilesV16, STORAGE_KEYS.legacySettingsV16, STORAGE_KEYS.legacyAgentLogV16, STORAGE_KEYS.legacyActionLogV16, STORAGE_KEYS.legacyPolicyLogV16, STORAGE_KEYS.legacySiteIntelLogV16, STORAGE_KEYS.legacyLearningLogV16, STORAGE_KEYS.legacyRulesV16, STORAGE_KEYS.legacyRuleLogV16, STORAGE_KEYS.legacyTrustLogV16, STORAGE_KEYS.legacyReportLogV16, STORAGE_KEYS.legacyTimelineLogV16, STORAGE_KEYS.legacyCausalLogV16,
      STORAGE_KEYS.legacySessionsV14, STORAGE_KEYS.legacyProfilesV14, STORAGE_KEYS.legacySettingsV14, STORAGE_KEYS.legacyAgentLogV14, STORAGE_KEYS.legacyActionLogV14, STORAGE_KEYS.legacyPolicyLogV14, STORAGE_KEYS.legacySiteIntelLogV14, STORAGE_KEYS.legacyLearningLogV14, STORAGE_KEYS.legacyRulesV14, STORAGE_KEYS.legacyRuleLogV14, STORAGE_KEYS.legacyTrustLogV14, STORAGE_KEYS.legacyReportLogV14,
      STORAGE_KEYS.legacySessionsV13, STORAGE_KEYS.legacyProfilesV13, STORAGE_KEYS.legacySettingsV13, STORAGE_KEYS.legacyAgentLogV13, STORAGE_KEYS.legacyActionLogV13, STORAGE_KEYS.legacyPolicyLogV13, STORAGE_KEYS.legacySiteIntelLogV13, STORAGE_KEYS.legacyLearningLogV13, STORAGE_KEYS.legacyRulesV13, STORAGE_KEYS.legacyRuleLogV13, STORAGE_KEYS.legacyTrustLogV13,
      STORAGE_KEYS.legacySessionsV12, STORAGE_KEYS.legacyProfilesV12, STORAGE_KEYS.legacySettingsV12, STORAGE_KEYS.legacyAgentLogV12, STORAGE_KEYS.legacyActionLogV12, STORAGE_KEYS.legacyPolicyLogV12, STORAGE_KEYS.legacySiteIntelLogV12, STORAGE_KEYS.legacyLearningLogV12, STORAGE_KEYS.legacyRulesV12, STORAGE_KEYS.legacyRuleLogV12,
      STORAGE_KEYS.legacySessionsV10, STORAGE_KEYS.legacyProfilesV10, STORAGE_KEYS.legacySettingsV10, STORAGE_KEYS.legacyAgentLogV10, STORAGE_KEYS.legacyActionLogV10, STORAGE_KEYS.legacyPolicyLogV10, STORAGE_KEYS.legacySiteIntelLogV10,
      STORAGE_KEYS.legacySessionsV9, STORAGE_KEYS.legacyProfilesV9, STORAGE_KEYS.legacySettingsV9, STORAGE_KEYS.legacyAgentLogV9, STORAGE_KEYS.legacyActionLogV9, STORAGE_KEYS.legacyPolicyLogV9,
      STORAGE_KEYS.legacySessionsV8, STORAGE_KEYS.legacyProfilesV8, STORAGE_KEYS.legacySettingsV8, STORAGE_KEYS.legacyAgentLogV8, STORAGE_KEYS.legacyActionLogV8,
      STORAGE_KEYS.legacySessionsV7, STORAGE_KEYS.legacyProfilesV7, STORAGE_KEYS.legacySettingsV7, STORAGE_KEYS.legacyAgentLogV7,
      STORAGE_KEYS.legacySessionsV6, STORAGE_KEYS.legacyProfilesV6, STORAGE_KEYS.legacySettingsV6
    ]);

    const payload = {};
    const legacySessions = firstArray(legacy, [STORAGE_KEYS.legacySessionsV17, STORAGE_KEYS.legacySessionsV16, STORAGE_KEYS.legacySessionsV15, STORAGE_KEYS.legacySessionsV14, STORAGE_KEYS.legacySessionsV13, STORAGE_KEYS.legacySessionsV12, STORAGE_KEYS.legacySessionsV10, STORAGE_KEYS.legacySessionsV9, STORAGE_KEYS.legacySessionsV8, STORAGE_KEYS.legacySessionsV7, STORAGE_KEYS.legacySessionsV6]);
    const legacyProfiles = firstObject(legacy, [STORAGE_KEYS.legacyProfilesV17, STORAGE_KEYS.legacyProfilesV16, STORAGE_KEYS.legacyProfilesV15, STORAGE_KEYS.legacyProfilesV14, STORAGE_KEYS.legacyProfilesV13, STORAGE_KEYS.legacyProfilesV12, STORAGE_KEYS.legacyProfilesV10, STORAGE_KEYS.legacyProfilesV9, STORAGE_KEYS.legacyProfilesV8, STORAGE_KEYS.legacyProfilesV7, STORAGE_KEYS.legacyProfilesV6]);
    const legacySettings = firstObject(legacy, [STORAGE_KEYS.legacySettingsV17, STORAGE_KEYS.legacySettingsV16, STORAGE_KEYS.legacySettingsV15, STORAGE_KEYS.legacySettingsV14, STORAGE_KEYS.legacySettingsV13, STORAGE_KEYS.legacySettingsV12, STORAGE_KEYS.legacySettingsV10, STORAGE_KEYS.legacySettingsV9, STORAGE_KEYS.legacySettingsV8, STORAGE_KEYS.legacySettingsV7, STORAGE_KEYS.legacySettingsV6]);

    if (Array.isArray(legacySessions)) {
      payload[STORAGE_KEYS.sessions] = legacySessions.map((item) => Object.assign({}, item, { migratedTo: "v18", migratedAt: new Date().toISOString() }));
    }
    if (legacyProfiles) payload[STORAGE_KEYS.profiles] = legacyProfiles;
    if (legacySettings) {
      payload[STORAGE_KEYS.settings] = Object.assign({}, DEFAULT_SETTINGS, legacySettings, {
        plannerEnabled: legacySettings.plannerEnabled !== false,
        actionSafeMode: legacySettings.actionSafeMode !== false,
        policyEnabled: legacySettings.policyEnabled !== false,
        siteIntelligenceEnabled: legacySettings.siteIntelligenceEnabled !== false,
        learningProfilesEnabled: legacySettings.learningProfilesEnabled !== false,
        ruleComposerEnabled: legacySettings.ruleComposerEnabled !== false,
        trustCalibrationEnabled: legacySettings.trustCalibrationEnabled !== false,
        reportIntelligenceEnabled: legacySettings.reportIntelligenceEnabled !== false,
        reportAutoBuild: legacySettings.reportAutoBuild !== false,
        timelineIntelligenceEnabled: legacySettings.timelineIntelligenceEnabled !== false,
        timelineAutoCapture: legacySettings.timelineAutoCapture !== false,
        causalGuardEnabled: legacySettings.causalGuardEnabled !== false,
        evidenceGraphEnabled: legacySettings.evidenceGraphEnabled !== false,
        counterfactualGuardEnabled: legacySettings.counterfactualGuardEnabled !== false,
        adaptivePolicyHints: legacySettings.adaptivePolicyHints !== false,
        policyMode: legacySettings.policyMode || "balanced",
        autoModeEnabled: Boolean(legacySettings.autoModeEnabled),
        policyDryRun: Boolean(legacySettings.policyDryRun)
      });
    }
    const agentLog = firstArray(legacy, [STORAGE_KEYS.legacyAgentLogV17, STORAGE_KEYS.legacyAgentLogV16, STORAGE_KEYS.legacyAgentLogV15, STORAGE_KEYS.legacyAgentLogV14, STORAGE_KEYS.legacyAgentLogV13, STORAGE_KEYS.legacyAgentLogV12, STORAGE_KEYS.legacyAgentLogV10, STORAGE_KEYS.legacyAgentLogV9, STORAGE_KEYS.legacyAgentLogV8, STORAGE_KEYS.legacyAgentLogV7]);
    const actionLog = firstArray(legacy, [STORAGE_KEYS.legacyActionLogV17, STORAGE_KEYS.legacyActionLogV16, STORAGE_KEYS.legacyActionLogV15, STORAGE_KEYS.legacyActionLogV14, STORAGE_KEYS.legacyActionLogV13, STORAGE_KEYS.legacyActionLogV12, STORAGE_KEYS.legacyActionLogV10, STORAGE_KEYS.legacyActionLogV9, STORAGE_KEYS.legacyActionLogV8]);
    const policyLog = firstArray(legacy, [STORAGE_KEYS.legacyPolicyLogV17, STORAGE_KEYS.legacyPolicyLogV16, STORAGE_KEYS.legacyPolicyLogV15, STORAGE_KEYS.legacyPolicyLogV14, STORAGE_KEYS.legacyPolicyLogV13, STORAGE_KEYS.legacyPolicyLogV12, STORAGE_KEYS.legacyPolicyLogV10, STORAGE_KEYS.legacyPolicyLogV9]);
    if (agentLog) payload[STORAGE_KEYS.agentLog] = agentLog;
    if (actionLog) payload[STORAGE_KEYS.actionLog] = actionLog;
    if (policyLog) payload[STORAGE_KEYS.policyLog] = policyLog;
    const siteIntelLog = firstArray(legacy, [STORAGE_KEYS.legacySiteIntelLogV17, STORAGE_KEYS.legacySiteIntelLogV16, STORAGE_KEYS.legacySiteIntelLogV15, STORAGE_KEYS.legacySiteIntelLogV14, STORAGE_KEYS.legacySiteIntelLogV13, STORAGE_KEYS.legacySiteIntelLogV12, STORAGE_KEYS.legacySiteIntelLogV10]);
    if (siteIntelLog) payload[STORAGE_KEYS.siteIntelLog] = siteIntelLog;
    const learningLog = firstArray(legacy, [STORAGE_KEYS.legacyLearningLogV17, STORAGE_KEYS.legacyLearningLogV16, STORAGE_KEYS.legacyLearningLogV15, STORAGE_KEYS.legacyLearningLogV14, STORAGE_KEYS.legacyLearningLogV13, STORAGE_KEYS.legacyLearningLogV12]);
    if (learningLog) payload[STORAGE_KEYS.learningLog] = learningLog;
    const rules = firstArray(legacy, [STORAGE_KEYS.legacyRulesV17, STORAGE_KEYS.legacyRulesV16, STORAGE_KEYS.legacyRulesV15, STORAGE_KEYS.legacyRulesV14, STORAGE_KEYS.legacyRulesV13, STORAGE_KEYS.legacyRulesV12, STORAGE_KEYS.legacyRulesV11]);
    if (rules) payload[STORAGE_KEYS.rules] = rules;
    const ruleLog = firstArray(legacy, [STORAGE_KEYS.legacyRuleLogV17, STORAGE_KEYS.legacyRuleLogV16, STORAGE_KEYS.legacyRuleLogV15, STORAGE_KEYS.legacyRuleLogV14, STORAGE_KEYS.legacyRuleLogV13, STORAGE_KEYS.legacyRuleLogV12, STORAGE_KEYS.legacyRuleLogV11]);
    if (ruleLog) payload[STORAGE_KEYS.ruleLog] = ruleLog;
    const trustLog = firstArray(legacy, [STORAGE_KEYS.legacyTrustLogV17, STORAGE_KEYS.legacyTrustLogV16, STORAGE_KEYS.legacyTrustLogV15, STORAGE_KEYS.legacyTrustLogV14, STORAGE_KEYS.legacyTrustLogV13]);
    if (trustLog) payload[STORAGE_KEYS.trustLog] = trustLog;
    const reportLog = firstArray(legacy, [STORAGE_KEYS.legacyReportLogV17, STORAGE_KEYS.legacyReportLogV16, STORAGE_KEYS.legacyReportLogV15, STORAGE_KEYS.legacyReportLogV14]);
    if (reportLog) payload[STORAGE_KEYS.reportLog] = reportLog;
    const timelineLog = firstArray(legacy, [STORAGE_KEYS.legacyTimelineLogV17, STORAGE_KEYS.legacyTimelineLogV16, STORAGE_KEYS.legacyTimelineLogV15]);
    if (timelineLog) payload[STORAGE_KEYS.timelineLog] = timelineLog;
    const causalLog = firstArray(legacy, [STORAGE_KEYS.legacyCausalLogV17, STORAGE_KEYS.legacyCausalLogV16]);
    if (causalLog) payload[STORAGE_KEYS.causalLog] = causalLog;
    const evidenceGraphLog = firstArray(legacy, [STORAGE_KEYS.legacyEvidenceGraphLogV17]);
    if (evidenceGraphLog) payload[STORAGE_KEYS.evidenceGraphLog] = evidenceGraphLog;
    if (Object.keys(payload).length > 0) { await storageSet(payload); return true; }
    return false;
  }

  async function getSettings() {
    await migrateLegacyIfNeeded();
    const data = await storageGet([STORAGE_KEYS.settings]);
    return Object.assign({}, DEFAULT_SETTINGS, data[STORAGE_KEYS.settings] || {});
  }

  async function setSettings(partialSettings) {
    const current = await getSettings();
    const next = Object.assign({}, current, partialSettings || {});
    await storageSet({ [STORAGE_KEYS.settings]: next });
    return next;
  }

  async function getSessions() {
    await migrateLegacyIfNeeded();
    const data = await storageGet([STORAGE_KEYS.sessions]);
    return Array.isArray(data[STORAGE_KEYS.sessions]) ? data[STORAGE_KEYS.sessions] : [];
  }

  async function saveSession(session) {
    const settings = await getSettings();
    const sessions = await getSessions();
    const cleanSession = Object.assign({
      id: "session-" + Date.now() + "-" + Math.random().toString(16).slice(2),
      savedAt: new Date().toISOString(),
      site: safeHostname(location.href),
      url: location.href,
      version: "18.0.0"
    }, session || {});
    sessions.push(cleanSession);
    const trimmed = sessions.slice(-Math.max(25, safeNumber(settings.maxSessions, 300)));
    await storageSet({ [STORAGE_KEYS.sessions]: trimmed });
    await updateSiteProfile(cleanSession);
    return cleanSession;
  }

  async function getProfiles() {
    await migrateLegacyIfNeeded();
    const data = await storageGet([STORAGE_KEYS.profiles]);
    const profiles = data[STORAGE_KEYS.profiles];
    return profiles && typeof profiles === "object" ? profiles : {};
  }

  async function getSiteProfile(site) {
    const profiles = await getProfiles();
    return profiles[site || safeHostname(location.href)] || null;
  }

  async function updateSiteProfile(session) {
    const profiles = await getProfiles();
    const site = session.site || safeHostname(session.url || location.href);
    const previous = profiles[site] || {
      site, visits: 0, trusted: false, firstSeen: new Date().toISOString(), lastSeen: null,
      avgRisk: 0, maxRisk: 0, minRisk: null, totalAnomalies: 0, totalMutations: 0,
      guardEvents: 0, actionEvents: 0, riskTrend: [], intelHistory: [], learningHistory: [], trustHistory: [], reportHistory: [], timelineHistory: [], causalHistory: [], evidenceGraphHistory: [], trustLevel: "local", lastSummary: null, lastIntelligence: null, lastLearningProfile: null, lastTimelineIntelligence: null, lastCausalGuard: null, lastEvidenceGraph: null
    };

    const riskScore = safeNumber(session.riskScore, 0);
    const visits = safeNumber(previous.visits, 0) + 1;
    const priorTrend = Array.isArray(previous.riskTrend) ? previous.riskTrend : [];
    const siteIntelligence = session.siteIntelligence || null;
    const learningProfile = session.learningProfile || null;
    const trustCalibration = session.trustCalibration || null;
    const reportIntelligence = session.reportIntelligence || null;
    const timelineIntelligence = session.timelineIntelligence || null;
    const causalGuard = session.causalGuard || null;
    const evidenceGraph = session.evidenceGraph || null;
    const counterfactualGuard = session.counterfactualGuard || null;
    const nextTrend = priorTrend.concat([{ riskScore, riskLevel: session.riskLevel || "UNKNOWN", at: session.savedAt || new Date().toISOString(), title: session.title || "", url: session.url || "" }]).slice(-30);
    const priorIntel = Array.isArray(previous.intelHistory) ? previous.intelHistory : [];
    const nextIntel = siteIntelligence ? priorIntel.concat([{ at: siteIntelligence.at || new Date().toISOString(), reputationScore: siteIntelligence.reputationScore, reputationLevel: siteIntelligence.reputationLevel, trendDirection: siteIntelligence.trendDirection, policyHint: siteIntelligence.policyHint, behaviorClass: siteIntelligence.behaviorClass }]).slice(-30) : priorIntel;
    const priorLearning = Array.isArray(previous.learningHistory) ? previous.learningHistory : [];
    const nextLearning = learningProfile ? priorLearning.concat([{ at: learningProfile.at || new Date().toISOString(), learningClass: learningProfile.learningClass, confidence: learningProfile.confidence, suspicionIndex: learningProfile.suspicionIndex, policyHint: learningProfile.policyHint }]).slice(-30) : priorLearning;
    const priorTrust = Array.isArray(previous.trustHistory) ? previous.trustHistory : [];
    const priorEvidenceGraph = Array.isArray(previous.evidenceGraphHistory) ? previous.evidenceGraphHistory : [];
    const priorCounterfactual = Array.isArray(previous.counterfactualHistory) ? previous.counterfactualHistory : [];
    const nextEvidenceGraph = evidenceGraph ? priorEvidenceGraph.concat([{ at: evidenceGraph.generatedAt || new Date().toISOString(), healthBand: evidenceGraph.healthBand, graphConfidence: evidenceGraph.graphConfidence, nodeCount: evidenceGraph.nodeCount, edgeCount: evidenceGraph.edgeCount }]).slice(-30) : priorEvidenceGraph;
    const nextCounterfactual = counterfactualGuard ? priorCounterfactual.concat([{ at: counterfactualGuard.generatedAt || new Date().toISOString(), confidence: counterfactualGuard.counterfactualConfidence, bestScenario: counterfactualGuard.bestScenario && counterfactualGuard.bestScenario.id, avoidedRiskEstimate: counterfactualGuard.avoidedRiskEstimate }]).slice(-30) : priorCounterfactual;
    const priorReports = Array.isArray(previous.reportHistory) ? previous.reportHistory : [];
    const nextReports = reportIntelligence ? priorReports.concat([{ at: reportIntelligence.at || new Date().toISOString(), reportScore: reportIntelligence.reportScore, reportGrade: reportIntelligence.reportGrade, healthBand: reportIntelligence.healthBand, confidence: reportIntelligence.confidence }]).slice(-30) : priorReports;
    const priorTimeline = Array.isArray(previous.timelineHistory) ? previous.timelineHistory : [];
    const nextTimeline = timelineIntelligence ? priorTimeline.concat([{ at: timelineIntelligence.at || new Date().toISOString(), status: timelineIntelligence.status, momentum: timelineIntelligence.momentum, volatilityScore: timelineIntelligence.volatilityScore, riskDelta: timelineIntelligence.riskDelta, eventCount: timelineIntelligence.eventCount }]).slice(-30) : priorTimeline;
    const nextTrust = trustCalibration ? priorTrust.concat([{ at: trustCalibration.createdAt || new Date().toISOString(), userTrustLevel: trustCalibration.userTrustLevel, effectiveTrustLevel: trustCalibration.effectiveTrustLevel, trustScore: trustCalibration.trustScore, policyHint: trustCalibration.policyHint }]).slice(-30) : priorTrust;

    profiles[site] = Object.assign({}, previous, {
      visits,
      lastSeen: new Date().toISOString(),
      avgRisk: Number((((safeNumber(previous.avgRisk, 0) * safeNumber(previous.visits, 0)) + riskScore) / visits).toFixed(2)),
      maxRisk: Math.max(safeNumber(previous.maxRisk, 0), riskScore),
      minRisk: previous.minRisk === null || previous.minRisk === undefined ? riskScore : Math.min(safeNumber(previous.minRisk, riskScore), riskScore),
      totalAnomalies: safeNumber(previous.totalAnomalies, 0) + safeNumber(session.anomalies, 0),
      totalMutations: safeNumber(previous.totalMutations, 0) + safeNumber(session.mutations, 0),
      guardEvents: safeNumber(previous.guardEvents, 0) + (session.agentDecision && session.agentDecision.guardLevel ? 1 : 0),
      actionEvents: safeNumber(previous.actionEvents, 0) + (session.actionPlan && session.actionPlan.actions ? session.actionPlan.actions.length : 0),
      riskTrend: nextTrend,
      intelHistory: nextIntel,
      learningHistory: nextLearning,
      trustHistory: nextTrust,
      reportHistory: nextReports,
      timelineHistory: nextTimeline,
      lastReportIntelligence: reportIntelligence || previous.lastReportIntelligence || null,
      lastTimelineIntelligence: timelineIntelligence || previous.lastTimelineIntelligence || null,
      lastCausalGuard: causalGuard || previous.lastCausalGuard || null,
      lastEvidenceGraph: evidenceGraph || previous.lastEvidenceGraph || null,
      evidenceGraphHistory: nextEvidenceGraph,
      lastCounterfactualGuard: counterfactualGuard || previous.lastCounterfactualGuard || null,
      counterfactualHistory: nextCounterfactual,
      causalHistory: causalGuard ? (Array.isArray(previous.causalHistory) ? previous.causalHistory : []).concat([{ at: session.savedAt || new Date().toISOString(), status: causalGuard.status, primaryCause: causalGuard.primaryCause, confidence: causalGuard.causalConfidence, riskDelta: causalGuard.riskDelta }]).slice(-30) : (previous.causalHistory || []),
      reportScore: reportIntelligence ? reportIntelligence.reportScore : previous.reportScore,
      reportGrade: reportIntelligence ? reportIntelligence.reportGrade : previous.reportGrade,
      healthBand: reportIntelligence ? reportIntelligence.healthBand : previous.healthBand,
      reportConfidence: reportIntelligence ? reportIntelligence.confidence : previous.reportConfidence,
      timelineStatus: timelineIntelligence ? timelineIntelligence.status : previous.timelineStatus,
      timelineVolatilityScore: timelineIntelligence ? timelineIntelligence.volatilityScore : previous.timelineVolatilityScore,
      timelineRiskDelta: timelineIntelligence ? timelineIntelligence.riskDelta : previous.timelineRiskDelta,
      lastTrustCalibration: trustCalibration || previous.lastTrustCalibration || null,
      trustLevel: previous.trustLevel || (previous.trusted ? "trusted" : "local"),
      trustScore: trustCalibration ? trustCalibration.trustScore : previous.trustScore,
      effectiveTrustLevel: trustCalibration ? trustCalibration.effectiveTrustLevel : previous.effectiveTrustLevel,
      trustPolicyHint: trustCalibration ? trustCalibration.policyHint : previous.trustPolicyHint,
      lastLearningProfile: learningProfile || previous.lastLearningProfile || null,
      learningClass: learningProfile ? learningProfile.learningClass : previous.learningClass,
      learningConfidence: learningProfile ? learningProfile.confidence : previous.learningConfidence,
      suspicionIndex: learningProfile ? learningProfile.suspicionIndex : previous.suspicionIndex,
      learnedPolicyHint: learningProfile ? learningProfile.policyHint : previous.learnedPolicyHint,
      lastIntelligence: siteIntelligence || previous.lastIntelligence || null,
      reputationScore: siteIntelligence ? siteIntelligence.reputationScore : previous.reputationScore,
      reputationLevel: siteIntelligence ? siteIntelligence.reputationLevel : previous.reputationLevel,
      trendDirection: siteIntelligence ? siteIntelligence.trendDirection : previous.trendDirection,
      volatilityScore: siteIntelligence ? siteIntelligence.volatilityScore : previous.volatilityScore,
      behaviorClass: siteIntelligence ? siteIntelligence.behaviorClass : previous.behaviorClass,
      policyHint: siteIntelligence ? siteIntelligence.policyHint : previous.policyHint,
      lastSummary: {
        riskScore,
        riskLevel: session.riskLevel || "UNKNOWN",
        agentStance: session.agentDecision && session.agentDecision.stance,
        actionCount: session.actionPlan && session.actionPlan.actions ? session.actionPlan.actions.length : 0,
        reputationLevel: siteIntelligence && siteIntelligence.reputationLevel,
        policyHint: siteIntelligence && siteIntelligence.policyHint,
        learningClass: learningProfile && learningProfile.learningClass,
        learningConfidence: learningProfile && learningProfile.confidence,
        learnedPolicyHint: learningProfile && learningProfile.policyHint,
        trustLevel: trustCalibration && trustCalibration.effectiveTrustLevel,
        trustScore: trustCalibration && trustCalibration.trustScore,
        reportScore: reportIntelligence && reportIntelligence.reportScore,
        reportGrade: reportIntelligence && reportIntelligence.reportGrade,
        healthBand: reportIntelligence && reportIntelligence.healthBand,
        timelineStatus: timelineIntelligence && timelineIntelligence.status,
        timelineVolatilityScore: timelineIntelligence && timelineIntelligence.volatilityScore,
        evidenceGraphHealth: evidenceGraph && evidenceGraph.healthBand,
        evidenceGraphConfidence: evidenceGraph && evidenceGraph.graphConfidence,
        counterfactualConfidence: counterfactualGuard && counterfactualGuard.counterfactualConfidence,
        savedAt: session.savedAt || new Date().toISOString(),
        url: session.url || location.href
      }
    });

    await storageSet({ [STORAGE_KEYS.profiles]: profiles });
    return profiles[site];
  }

  function normalizeTrustLevel(level) {
    const raw = String(level || "local").toLowerCase();
    return ["local", "trusted", "watched", "sensitive", "blocked"].includes(raw) ? raw : "local";
  }

  async function setTrustLevel(site, level) {
    const profiles = await getProfiles();
    const target = site || safeHostname(location.href);
    const trustLevel = normalizeTrustLevel(level);
    const previous = profiles[target] || { site: target, visits: 0, firstSeen: new Date().toISOString(), avgRisk: 0, maxRisk: 0, totalAnomalies: 0, totalMutations: 0, riskTrend: [], intelHistory: [], learningHistory: [], trustHistory: [] };
    const event = { at: new Date().toISOString(), type: "manual_trust_level", trustLevel };
    profiles[target] = Object.assign({}, previous, {
      trustLevel,
      trusted: trustLevel === "trusted",
      watched: trustLevel === "watched",
      sensitive: trustLevel === "sensitive",
      blocked: trustLevel === "blocked",
      trustUpdatedAt: event.at,
      trustHistory: (Array.isArray(previous.trustHistory) ? previous.trustHistory : []).concat([event]).slice(-30)
    });
    await storageSet({ [STORAGE_KEYS.profiles]: profiles });
    return profiles[target];
  }

  async function setTrustedSite(site, trusted) {
    return setTrustLevel(site, trusted ? "trusted" : "local");
  }

  async function getAgentLog() { const data = await storageGet([STORAGE_KEYS.agentLog]); return Array.isArray(data[STORAGE_KEYS.agentLog]) ? data[STORAGE_KEYS.agentLog] : []; }
  async function saveAgentDecision(decision, context) {
    const settings = await getSettings(); const log = await getAgentLog();
    const cleanDecision = Object.assign({ id: "agent-" + Date.now() + "-" + Math.random().toString(16).slice(2), savedAt: new Date().toISOString(), site: safeHostname(location.href), url: location.href, version: "18.0.0" }, decision || {}, { context: context || null });
    log.push(cleanDecision); await storageSet({ [STORAGE_KEYS.agentLog]: log.slice(-Math.max(25, safeNumber(settings.maxAgentLog, 300))) }); return cleanDecision;
  }

  async function getActionLog() { const data = await storageGet([STORAGE_KEYS.actionLog]); return Array.isArray(data[STORAGE_KEYS.actionLog]) ? data[STORAGE_KEYS.actionLog] : []; }
  async function saveActionEvent(actionEvent) {
    const settings = await getSettings(); const log = await getActionLog();
    const clean = Object.assign({ id: "action-" + Date.now() + "-" + Math.random().toString(16).slice(2), savedAt: new Date().toISOString(), site: safeHostname(location.href), url: location.href, version: "18.0.0" }, actionEvent || {});
    log.push(clean); await storageSet({ [STORAGE_KEYS.actionLog]: log.slice(-Math.max(25, safeNumber(settings.maxActionLog, 300))) }); return clean;
  }

  async function getPolicyLog() { const data = await storageGet([STORAGE_KEYS.policyLog]); return Array.isArray(data[STORAGE_KEYS.policyLog]) ? data[STORAGE_KEYS.policyLog] : []; }
  async function savePolicyDecision(policyDecision, context) {
    const settings = await getSettings(); const log = await getPolicyLog();
    const clean = Object.assign({ id: "policy-log-" + Date.now() + "-" + Math.random().toString(16).slice(2), savedAt: new Date().toISOString(), site: safeHostname(location.href), url: location.href, version: "18.0.0" }, policyDecision || {}, { context: context || null });
    log.push(clean); await storageSet({ [STORAGE_KEYS.policyLog]: log.slice(-Math.max(25, safeNumber(settings.maxPolicyLog, 300))) }); return clean;
  }

  async function getSiteIntelLog() { const data = await storageGet([STORAGE_KEYS.siteIntelLog]); return Array.isArray(data[STORAGE_KEYS.siteIntelLog]) ? data[STORAGE_KEYS.siteIntelLog] : []; }
  async function saveSiteIntelligence(siteIntelligence, context) {
    const settings = await getSettings(); const log = await getSiteIntelLog();
    const clean = Object.assign({ id: "site-intel-log-" + Date.now() + "-" + Math.random().toString(16).slice(2), savedAt: new Date().toISOString(), site: safeHostname(location.href), url: location.href, version: "18.0.0" }, siteIntelligence || {}, { context: context || null });
    log.push(clean); await storageSet({ [STORAGE_KEYS.siteIntelLog]: log.slice(-Math.max(25, safeNumber(settings.maxSiteIntelLog, 300))) }); return clean;
  }


  async function getLearningLog() { const data = await storageGet([STORAGE_KEYS.learningLog]); return Array.isArray(data[STORAGE_KEYS.learningLog]) ? data[STORAGE_KEYS.learningLog] : []; }
  async function saveLearningProfile(learningProfile, context) {
    const settings = await getSettings(); const log = await getLearningLog();
    const clean = Object.assign({ id: "learning-log-" + Date.now() + "-" + Math.random().toString(16).slice(2), savedAt: new Date().toISOString(), site: safeHostname(location.href), url: location.href, version: "18.0.0" }, learningProfile || {}, { context: context || null });
    log.push(clean); await storageSet({ [STORAGE_KEYS.learningLog]: log.slice(-Math.max(25, safeNumber(settings.maxLearningLog, 300))) }); return clean;
  }

  async function getTrustLog() { const data = await storageGet([STORAGE_KEYS.trustLog]); return Array.isArray(data[STORAGE_KEYS.trustLog]) ? data[STORAGE_KEYS.trustLog] : []; }
  async function saveTrustCalibration(trustCalibration, context) {
    const settings = await getSettings(); const log = await getTrustLog();
    const clean = Object.assign({ id: "trust-log-" + Date.now() + "-" + Math.random().toString(16).slice(2), savedAt: new Date().toISOString(), site: safeHostname(location.href), url: location.href, version: "18.0.0" }, trustCalibration || {}, { context: context || null });
    log.push(clean); await storageSet({ [STORAGE_KEYS.trustLog]: log.slice(-Math.max(25, safeNumber(settings.maxTrustLog, 300))) }); return clean;
  }

  async function getReportLog() { const data = await storageGet([STORAGE_KEYS.reportLog]); return Array.isArray(data[STORAGE_KEYS.reportLog]) ? data[STORAGE_KEYS.reportLog] : []; }
  async function saveReportIntelligence(reportIntelligence, context) {
    const settings = await getSettings(); const log = await getReportLog();
    const clean = Object.assign({ id: "report-log-" + Date.now() + "-" + Math.random().toString(16).slice(2), savedAt: new Date().toISOString(), site: safeHostname(location.href), url: location.href, version: "18.0.0" }, reportIntelligence || {}, { context: context || null });
    log.push(clean); await storageSet({ [STORAGE_KEYS.reportLog]: log.slice(-Math.max(25, safeNumber(settings.maxReportLog, 300))) }); return clean;
  }

  async function getTimelineLog() { const data = await storageGet([STORAGE_KEYS.timelineLog]); return Array.isArray(data[STORAGE_KEYS.timelineLog]) ? data[STORAGE_KEYS.timelineLog] : []; }
  async function saveTimelineIntelligence(timelineIntelligence, context) {
    const settings = await getSettings(); const log = await getTimelineLog();
    const clean = Object.assign({ id: "timeline-log-" + Date.now() + "-" + Math.random().toString(16).slice(2), savedAt: new Date().toISOString(), site: safeHostname(location.href), url: location.href, version: "18.0.0" }, timelineIntelligence || {}, { context: context || null });
    log.push(clean); await storageSet({ [STORAGE_KEYS.timelineLog]: log.slice(-Math.max(25, safeNumber(settings.maxTimelineLog, 300))) }); return clean;
  }



  async function getCausalLog() { const data = await storageGet([STORAGE_KEYS.causalLog]); return Array.isArray(data[STORAGE_KEYS.causalLog]) ? data[STORAGE_KEYS.causalLog] : []; }
  async function saveCausalGuard(causalGuard, context) {
    const settings = await getSettings(); const log = await getCausalLog();
    const clean = Object.assign({ id: "causal-log-" + Date.now() + "-" + Math.random().toString(16).slice(2), savedAt: new Date().toISOString(), site: safeHostname(location.href), url: location.href, version: "18.0.0" }, causalGuard || {}, { context: context || null });
    log.push(clean); await storageSet({ [STORAGE_KEYS.causalLog]: log.slice(-Math.max(25, safeNumber(settings.maxCausalLog, 300))) }); return clean;
  }



  async function getEvidenceGraphLog() { const data = await storageGet([STORAGE_KEYS.evidenceGraphLog]); return Array.isArray(data[STORAGE_KEYS.evidenceGraphLog]) ? data[STORAGE_KEYS.evidenceGraphLog] : []; }
  async function saveEvidenceGraph(evidenceGraph, context) {
    const settings = await getSettings(); const log = await getEvidenceGraphLog();
    const clean = Object.assign({ id: "evidence-graph-log-" + Date.now() + "-" + Math.random().toString(16).slice(2), savedAt: new Date().toISOString(), site: safeHostname(location.href), url: location.href, version: "18.0.0" }, evidenceGraph || {}, { context: context || null });
    log.push(clean); await storageSet({ [STORAGE_KEYS.evidenceGraphLog]: log.slice(-Math.max(25, safeNumber(settings.maxEvidenceGraphLog, 300))) }); return clean;
  }

  async function getCounterfactualLog() { const data = await storageGet([STORAGE_KEYS.counterfactualLog]); return Array.isArray(data[STORAGE_KEYS.counterfactualLog]) ? data[STORAGE_KEYS.counterfactualLog] : []; }
  async function saveCounterfactualGuard(counterfactualGuard, context) {
    const settings = await getSettings(); const log = await getCounterfactualLog();
    const clean = Object.assign({ id: "counterfactual-log-" + Date.now() + "-" + Math.random().toString(16).slice(2), savedAt: new Date().toISOString(), site: safeHostname(location.href), url: location.href, version: "18.0.0" }, counterfactualGuard || {}, { context: context || null });
    log.push(clean); await storageSet({ [STORAGE_KEYS.counterfactualLog]: log.slice(-Math.max(25, safeNumber(settings.maxCounterfactualLog, 300))) }); return clean;
  }

  async function clearAetherionMemory() {
    await storageSet({ [STORAGE_KEYS.sessions]: [], [STORAGE_KEYS.profiles]: {}, [STORAGE_KEYS.settings]: DEFAULT_SETTINGS, [STORAGE_KEYS.agentLog]: [], [STORAGE_KEYS.actionLog]: [], [STORAGE_KEYS.policyLog]: [], [STORAGE_KEYS.siteIntelLog]: [], [STORAGE_KEYS.learningLog]: [], [STORAGE_KEYS.rules]: [], [STORAGE_KEYS.ruleLog]: [], [STORAGE_KEYS.trustLog]: [], [STORAGE_KEYS.reportLog]: [], [STORAGE_KEYS.timelineLog]: [], [STORAGE_KEYS.causalLog]: [], [STORAGE_KEYS.evidenceGraphLog]: [], [STORAGE_KEYS.counterfactualLog]: [] });
    return true;
  }

  window.AetherionMemory = { STORAGE_KEYS, DEFAULT_SETTINGS, getSettings, setSettings, getSessions, saveSession, getProfiles, getSiteProfile, updateSiteProfile, setTrustedSite, setTrustLevel, getAgentLog, saveAgentDecision, getActionLog, saveActionEvent, getPolicyLog, savePolicyDecision, getSiteIntelLog, saveSiteIntelligence, getLearningLog, saveLearningProfile, getTrustLog, saveTrustCalibration, getReportLog, saveReportIntelligence, getTimelineLog, saveTimelineIntelligence, getCausalLog, saveCausalGuard, getEvidenceGraphLog, saveEvidenceGraph, getCounterfactualLog, saveCounterfactualGuard, clearAetherionMemory, safeHostname };
})();
