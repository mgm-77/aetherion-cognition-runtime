# Aetherion Extension v18.0 - Counterfactual Guard Guardian+

Local-only MV3 browser guardian for Kiwi/Chromium.

## New in v18

- Counterfactual Guard+
- Local what-if scenarios:
  - observed path
  - no Aetherion assists
  - strict policy
  - protective policy
  - observe-only
  - trusted override
  - sensitive / blocked calibration
- Best/worst estimated path
- avoided-risk estimate
- action-value estimate
- scenario assumptions and recommendations
- Popup panel for counterfactuals
- Export JSON includes `counterfactualGuard`
- Local memory log for counterfactual decisions
- Migration path from v17 storage keys

No API key. No external server. Heuristic/local only.

## Install in Kiwi

1. Open `chrome://extensions`
2. Enable Developer mode
3. Load unpacked
4. Select the `aetherion_extension_v18` folder
