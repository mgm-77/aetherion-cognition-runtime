/* Aetherion DevOS v18 - Popup Controller with Counterfactual Guard+ */
(function () {
  "use strict";
  const el = (id) => document.getElementById(id);
  let activeTabId = null;
  let lastPayload = null;

  function setStatus(text) { el("statusLine").textContent = text || ""; }
  function riskColor(level) { if (level === "CRITICAL") return "#ff7b7b"; if (level === "HIGH") return "#ffad66"; if (level === "MEDIUM") return "#ffd166"; return "#77e39b"; }
  function escapeHTML(value) { return String(value || "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"); }

  function sendToContent(type, payload) {
    return new Promise((resolve) => {
      if (!activeTabId || !chrome.tabs) return resolve({ ok: false, error: "No active tab." });
      try {
        chrome.tabs.sendMessage(activeTabId, Object.assign({ type }, payload || {}), (response) => {
          if (chrome.runtime.lastError) resolve({ ok: false, error: chrome.runtime.lastError.message });
          else resolve(response || { ok: false, error: "No response." });
        });
      } catch (error) { resolve({ ok: false, error: error.message }); }
    });
  }

  function badgeClass(severity) { if (severity === "critical") return "badge critical"; if (severity === "high") return "badge high"; if (severity === "medium") return "badge medium"; if (severity === "low") return "badge low"; return "badge"; }

  function renderRecommendations(agent) {
    const recs = agent && Array.isArray(agent.recommendations) ? agent.recommendations : [];
    if (!recs.length) { el("recommendations").innerHTML = "<li class='rec'><div class='rec-title'>No agent recommendation yet.</div><div class='rec-detail'>Run Analyze now on an active page.</div></li>"; return; }
    el("recommendations").innerHTML = recs.slice(0,5).map((rec) => `<li class="rec"><div class="top"><div class="rec-title">${escapeHTML(rec.title)}</div><div class="${badgeClass(rec.severity)}">${escapeHTML(rec.severity || "info")}</div></div><div class="rec-detail">${escapeHTML(rec.detail)}</div></li>`).join("");
  }

  function renderEvidence(agent) {
    const cards = agent && Array.isArray(agent.evidenceCards) ? agent.evidenceCards : [];
    if (!cards.length) { el("evidenceCards").innerHTML = "<div><b>Evidence</b><br>No evidence cards yet.</div>"; return; }
    el("evidenceCards").innerHTML = cards.slice(0,4).map((card) => `<div><b>${escapeHTML(card.title)}</b><br>${escapeHTML(card.value)}</div>`).join("");
  }

  function actionButtonClass(action) {
    if (action.severity === "critical" || action.severity === "high") return "warn";
    if (action.type === "NOOP") return "safe";
    return "safe";
  }


  function renderRules(ruleDecision, rules) {
    const decision = ruleDecision || {};
    const matched = Array.isArray(decision.matchedRules) ? decision.matchedRules : [];
    const allRules = Array.isArray(rules) ? rules : [];
    const blocked = Array.isArray(decision.blockedActionTypes) ? decision.blockedActionTypes : [];
    el("ruleStatus").textContent = `${decision.status || "WARMING"} · ${matched.length}/${decision.allRulesCount || allRules.length || 0} matched`;
    el("ruleSummary").textContent = decision.summary || "No local site rule matched yet.";
    el("ruleMatched").textContent = String(matched.length);
    el("ruleTotal").textContent = String(decision.allRulesCount || allRules.length || 0);
    el("ruleBlocked").textContent = String(blocked.length);
    const localRules = allRules.filter((rule) => matched.some((m) => m.id === rule.id) || (lastPayload && lastPayload.status && String(rule.sitePattern || "") === String(lastPayload.status.site || "")));
    const list = localRules.length ? localRules : matched;
    if (!list.length) {
      el("rulesList").innerHTML = "<li class='act'><div class='act-title'>No rule for this site yet.</div><div class='act-detail'>Use a preset button above to create one.</div></li>";
      return;
    }
    el("rulesList").innerHTML = list.slice(0,8).map((rule) => `<li class="act"><div class="top"><div class="act-title">${escapeHTML(rule.label || rule.presetType || "Rule")}</div><div class="badge low">${escapeHTML(rule.enabled === false ? "off" : "on")}</div></div><div class="act-detail">${escapeHTML(rule.sitePattern || "site")} · ${escapeHTML(rule.presetType || "CUSTOM")}</div><button class="danger" data-rule-remove="${escapeHTML(rule.id)}">Remove rule</button></li>`).join("");
    Array.from(document.querySelectorAll("button[data-rule-remove]")).forEach((button) => {
      button.addEventListener("click", () => removeRule(button.getAttribute("data-rule-remove")));
    });
  }

  function renderActions(plan) {
    const actions = plan && Array.isArray(plan.actions) ? plan.actions : [];
    el("plannerStatus").textContent = `${plan && plan.status ? plan.status : "READY"} · ${plan && plan.confidence ? plan.confidence : 0}% confidence`;
    el("plannerSummary").textContent = plan && plan.summary ? plan.summary : "No action plan yet.";
    const notes = plan && Array.isArray(plan.notes) ? plan.notes : [];
    el("plannerNotes").textContent = notes.length ? notes.slice(0, 2).join(" ") : "Actions are local, reversible where visual, and do not send data externally.";
    if (!actions.length) { el("actions").innerHTML = "<li class='act'><div class='act-title'>No action card yet.</div><div class='act-detail'>Run Analyze now.</div></li>"; return; }
    el("actions").innerHTML = actions.slice(0,6).map((action) => {
      const disabled = action.type === "NOOP" ? "disabled" : "";
      const label = action.type === "NOOP" ? "No action needed" : "Apply action";
      return `<li class="act"><div class="top"><div class="act-title">${escapeHTML(action.title)}</div><div class="${badgeClass(action.severity)}">${escapeHTML(action.severity || "info")}</div></div><div class="act-detail">${escapeHTML(action.detail)}</div><button class="${actionButtonClass(action)}" data-action-id="${escapeHTML(action.id)}" ${disabled}>${label}</button></li>`;
    }).join("");
    Array.from(document.querySelectorAll("button[data-action-id]")).forEach((button) => {
      button.addEventListener("click", () => applyAction(button.getAttribute("data-action-id")));
    });
  }

  function render(payload) {
    if (!payload || !payload.status) { setStatus("Aetherion content script is not active on this page."); return; }
    lastPayload = payload;
    const status = payload.status;
    const signals = status.signals || {};
    const scripts = signals.scripts || {};
    const forms = signals.forms || {};
    const links = signals.links || {};
    const userEvents = status.userEvents || {};
    const totalEvents = Number(userEvents.clicks || 0) + Number(userEvents.scrolls || 0) + Number(userEvents.keys || 0);
    const agent = status.agentDecision || {};
    const plan = status.actionPlan || {};
    const policy = status.policyDecision || {};
    const intel = status.siteIntelligence || {};
    const learning = status.learningProfile || {};
    const ruleDecision = status.ruleDecision || {};
    const trustCalibration = status.trustCalibration || {};
    const report = status.reportIntelligence || {};
    const timelineIntel = status.timelineIntelligence || {};
    const causalGuard = status.causalGuard || {};
    const evidenceGraph = status.evidenceGraph || {};
    const counterfactualGuard = status.counterfactualGuard || {};
    const rules = payload.rules || [];
    const profile = payload.profile || null;
    const settings = payload.settings || {};

    el("riskScore").textContent = String(status.riskScore ?? "--");
    el("riskScore").style.color = riskColor(status.riskLevel);
    el("riskLevel").textContent = `${status.riskLevel || "UNKNOWN"} · heuristic local scan`;
    el("site").textContent = status.site || status.url || "Unknown site";
    el("trustLabel").textContent = (trustCalibration.effectiveTrustLevel || (profile && profile.trustLevel) || (profile && profile.trusted ? "trusted" : "local"));
    el("mutations").textContent = String(status.mutations || 0);
    el("anomalies").textContent = String(status.anomalies || 0);
    el("trackers").textContent = String(scripts.trackers || 0);
    el("forms").textContent = String(forms.total || 0);
    el("downloads").textContent = String(links.dangerousDownloads || 0);
    el("events").textContent = String(totalEvents);
    el("agentStance").textContent = `${agent.stance || "OBSERVE"} · ${agent.confidence || 0}% confidence`;
    el("agentSummary").textContent = agent.summary || "No agent summary yet.";
    el("policyStatus").textContent = `${policy.status || "WARMING"} · ${policy.mode || "balanced"} · ${policy.confidence || 0}% confidence`;
    el("policySummary").textContent = policy.summary || "No policy decision yet.";
    el("reportHealth").textContent = `${report.healthBand || "WARMING"} · grade ${report.reportGrade || "--"}`;
    el("reportSummary").textContent = report.executiveSummary || "Report Intelligence+ is warming up.";
    el("reportScore").textContent = String(report.reportScore ?? "--");
    el("reportGrade").textContent = report.reportGrade || "--";
    el("reportConfidence").textContent = String(report.confidence ?? "--");
    el("reportRiskBand").textContent = report.riskBand || "--";
    el("reportRedFlags").textContent = String(Array.isArray(report.redFlags) ? report.redFlags.length : 0);
    el("reportGreenFlags").textContent = String(Array.isArray(report.greenFlags) ? report.greenFlags.length : 0);
    const timeline = Array.isArray(report.timeline) ? report.timeline : [];
    el("reportTimeline").textContent = timeline.slice(0, 3).map((item) => `${item.label}: ${item.value}`).join(" · ") || "No report timeline yet.";
    const reportRecs = Array.isArray(report.recommendations) ? report.recommendations : [];
    el("reportRecommendation").textContent = reportRecs.length ? `${reportRecs[0].title}: ${reportRecs[0].detail}` : "No report recommendation yet.";
    el("timelineStatus").textContent = `${timelineIntel.status || "WARMING"} · ${timelineIntel.eventCount || 0} point(s)`;
    el("timelineSummary").textContent = timelineIntel.summary || "Timeline Intelligence+ is warming up.";
    el("timelineMomentum").textContent = timelineIntel.momentum || "--";
    el("timelineVolatility").textContent = String(timelineIntel.volatilityScore ?? "--");
    el("timelineDelta").textContent = String(timelineIntel.riskDelta ?? "--");
    el("timelineEvents").textContent = String(timelineIntel.eventCount ?? 0);
    el("timelineSignificant").textContent = String(timelineIntel.significantEventCount ?? 0);
    el("timelineTrigger").textContent = timelineIntel.dominantTrigger || "--";
    const latestPoint = timelineIntel.latestPoint || {};
    el("timelineLatest").textContent = latestPoint.at ? `${latestPoint.trigger || "sample"}: risk ${latestPoint.riskScore ?? "--"}, DOM Δ ${latestPoint.deltaMutations ?? 0}, anomaly Δ ${latestPoint.deltaAnomalies ?? 0}` : "No timeline points yet.";
    const timelineRecs = Array.isArray(timelineIntel.recommendations) ? timelineIntel.recommendations : [];
    el("timelineRecommendation").textContent = timelineRecs.length ? `${timelineRecs[0].title}: ${timelineRecs[0].detail}` : "No timeline recommendation yet.";
    el("causalStatus").textContent = `${causalGuard.status || "WARMING"} · ${causalGuard.causalConfidence ?? 0}% confidence`;
    el("causalSummary").textContent = causalGuard.summary || "Causal Guard+ is warming up.";
    el("causalConfidence").textContent = String(causalGuard.causalConfidence ?? "--");
    el("causalCause").textContent = causalGuard.primaryCause && causalGuard.primaryCause.type ? causalGuard.primaryCause.type : "--";
    el("causalDelta").textContent = String(causalGuard.riskDelta ?? "--");
    el("causalCategory").textContent = causalGuard.dominantRiskCategory || "--";
    el("causalChain").textContent = String(Array.isArray(causalGuard.causalChain) ? causalGuard.causalChain.length : 0);
    el("causalMomentum").textContent = causalGuard.timelineMomentum || "--";
    const causeEvidence = causalGuard.primaryCause && Array.isArray(causalGuard.primaryCause.evidence) ? causalGuard.primaryCause.evidence : [];
    el("causalEvidence").textContent = causeEvidence.slice(0, 4).join(" · ") || "No causal evidence yet.";
    const causalRecs = Array.isArray(causalGuard.recommendations) ? causalGuard.recommendations : [];
    el("causalRecommendation").textContent = causalRecs.length ? `${causalRecs[0].title}: ${causalRecs[0].detail}` : "No causal recommendation yet.";

    el("graphStatus").textContent = `${evidenceGraph.status || "WARMING"} · ${evidenceGraph.graphConfidence ?? 0}% confidence`;
    el("graphSummary").textContent = evidenceGraph.summary || "Evidence Graph+ is warming up.";
    el("graphConfidence").textContent = String(evidenceGraph.graphConfidence ?? "--");
    el("graphHealth").textContent = evidenceGraph.healthBand || "--";
    el("graphNodes").textContent = String(evidenceGraph.nodeCount ?? 0);
    el("graphEdges").textContent = String(evidenceGraph.edgeCount ?? 0);
    el("graphGaps").textContent = String(Array.isArray(evidenceGraph.gaps) ? evidenceGraph.gaps.length : 0);
    el("graphRisk").textContent = String(evidenceGraph.riskScore ?? "--");
    el("graphPath").textContent = evidenceGraph.topPath || "No graph path yet.";
    const graphRecs = Array.isArray(evidenceGraph.recommendations) ? evidenceGraph.recommendations : [];
    const graphGaps = Array.isArray(evidenceGraph.gaps) ? evidenceGraph.gaps : [];
    el("graphRecommendation").textContent = graphRecs.length ? `${graphRecs[0].title}: ${graphRecs[0].detail}` : (graphGaps[0] || "No graph recommendation yet.");

    el("counterfactualStatus").textContent = `${counterfactualGuard.status || "WARMING"} · ${counterfactualGuard.counterfactualConfidence ?? 0}% confidence`;
    el("counterfactualSummary").textContent = counterfactualGuard.summary || "Counterfactual Guard+ is warming up.";
    el("counterfactualConfidence").textContent = String(counterfactualGuard.counterfactualConfidence ?? "--");
    el("counterfactualBest").textContent = counterfactualGuard.bestScenario && counterfactualGuard.bestScenario.label ? counterfactualGuard.bestScenario.label : "--";
    el("counterfactualWorst").textContent = counterfactualGuard.worstScenario && counterfactualGuard.worstScenario.label ? counterfactualGuard.worstScenario.label : "--";
    el("counterfactualAvoided").textContent = String(counterfactualGuard.avoidedRiskEstimate ?? "--");
    el("counterfactualActionValue").textContent = String(counterfactualGuard.actionValueEstimate ?? "--");
    el("counterfactualScenarios").textContent = String(counterfactualGuard.scenarioCount ?? (Array.isArray(counterfactualGuard.scenarios) ? counterfactualGuard.scenarios.length : 0));
    const bestCf = counterfactualGuard.bestScenario || {};
    const worstCf = counterfactualGuard.worstScenario || {};
    el("counterfactualPath").textContent = bestCf.label ? `Best: ${bestCf.label} risk ${bestCf.estimatedRisk}/100 Δ ${bestCf.delta}; Worst: ${worstCf.label || "--"} ${worstCf.estimatedRisk ?? "--"}/100` : "No counterfactual path yet.";
    const cfRecs = Array.isArray(counterfactualGuard.recommendations) ? counterfactualGuard.recommendations : [];
    el("counterfactualRecommendation").textContent = cfRecs.length ? `${cfRecs[0].title}: ${cfRecs[0].detail}` : "No counterfactual recommendation yet.";


    el("intelReputation").textContent = `${intel.reputationLevel || "NEW"} · ${intel.reputationScore ?? "--"}/100`;
    el("intelSummary").textContent = intel.summary || "No site intelligence summary yet.";
    el("intelTrend").textContent = intel.trendDirection || "--";
    el("intelVolatility").textContent = String(intel.volatilityScore ?? "--");
    el("intelVisits").textContent = String(intel.visits || 0);
    el("intelPolicyHint").textContent = intel.policyHint || "--";
    el("intelReputationScore").textContent = String(intel.reputationScore ?? "--");
    el("intelClass").textContent = intel.behaviorClass || "--";
    const intelNotes = Array.isArray(intel.notes) ? intel.notes : [];
    const intelRecs = Array.isArray(intel.recommendations) ? intel.recommendations : [];
    el("intelNotes").textContent = intelNotes.concat(intelRecs).slice(0, 3).join(" ") || "No site-level intelligence notes yet.";
    const learnFeatures = learning.features || {};
    el("learnClass").textContent = `${learning.learningClass || "WARMING_UP"} · ${learning.confidence || 0}% confidence`;
    el("learnSummary").textContent = learning.summary || "No learning profile summary yet.";
    el("learnConfidence").textContent = String(learning.confidence ?? "--");
    el("learnSuspicion").textContent = String(learning.suspicionIndex ?? "--");
    el("learnPolicyHint").textContent = learning.policyHint || "--";
    el("learnDynamic").textContent = String(learnFeatures.dynamicIndex ?? "--");
    el("learnTracking").textContent = String(learnFeatures.trackingIndex ?? "--");
    el("learnInstability").textContent = String(learnFeatures.instabilityIndex ?? "--");
    const learnNotes = Array.isArray(learning.notes) ? learning.notes : [];
    const learnRecs = Array.isArray(learning.recommendations) ? learning.recommendations : [];
    el("learnNotes").textContent = learnNotes.concat(learnRecs).slice(0, 3).join(" ") || "No learning notes yet.";

    const trustReasons = Array.isArray(trustCalibration.reasons) ? trustCalibration.reasons : [];
    const trustRestrictions = Array.isArray(trustCalibration.restrictions) ? trustCalibration.restrictions : [];
    el("trustCalLevel").textContent = `${trustCalibration.effectiveTrustLevel || "local"} · ${trustCalibration.trustScore ?? "--"}/100`;
    el("trustCalSummary").textContent = trustCalibration.summary || "No trust calibration summary yet.";
    el("trustCalScore").textContent = String(trustCalibration.trustScore ?? "--");
    el("trustCalEffective").textContent = trustCalibration.effectiveTrustLevel || "--";
    el("trustCalUser").textContent = trustCalibration.userTrustLevel || (profile && profile.trustLevel) || "local";
    el("trustCalPolicy").textContent = trustCalibration.policyHint || "--";
    el("trustCalConfidence").textContent = String(trustCalibration.confidence ?? "--");
    el("trustCalRiskBand").textContent = trustCalibration.riskBand || "--";
    el("trustCalReasons").textContent = trustReasons.concat(trustRestrictions).slice(0, 4).join(" ") || "No trust calibration notes yet.";

    el("overlayToggle").checked = Boolean(settings.overlayEnabled);
    el("compactToggle").checked = Boolean(settings.compactOverlay);
    el("agentToggle").checked = settings.agentEnabled !== false;
    el("plannerToggle").checked = settings.plannerEnabled !== false;
    el("safeModeToggle").checked = settings.actionSafeMode !== false;
    el("policyToggle").checked = settings.policyEnabled !== false;
    el("autoModeToggle").checked = Boolean(settings.autoModeEnabled);
    el("dryRunToggle").checked = Boolean(settings.policyDryRun);
    el("siteIntelToggle").checked = settings.siteIntelligenceEnabled !== false;
    el("learningToggle").checked = settings.learningProfilesEnabled !== false;
    el("adaptivePolicyToggle").checked = settings.adaptivePolicyHints !== false;
    el("ruleComposerToggle").checked = settings.ruleComposerEnabled !== false;
    el("trustCalibrationToggle").checked = settings.trustCalibrationEnabled !== false;
    el("reportIntelligenceToggle").checked = settings.reportIntelligenceEnabled !== false;
    el("timelineIntelligenceToggle").checked = settings.timelineIntelligenceEnabled !== false;
    el("causalGuardToggle").checked = settings.causalGuardEnabled !== false;
    el("evidenceGraphToggle").checked = settings.evidenceGraphEnabled !== false;
    el("counterfactualGuardToggle").checked = settings.counterfactualGuardEnabled !== false;
    el("guardToggle").checked = settings.guardBannerEnabled !== false;
    el("criticalOnlyToggle").checked = Boolean(settings.guardBannerCriticalOnly);
    el("trustToggle").checked = Boolean((profile && profile.trustLevel === "trusted") || (profile && profile.trusted));
    el("modeSelect").value = settings.recommendationMode || "balanced";
    el("policyModeSelect").value = settings.policyMode || "balanced";

    renderRules(ruleDecision, rules);
    renderActions(plan);
    renderRecommendations(agent);
    renderEvidence(agent);
    const reasons = Array.isArray(status.riskReasons) ? status.riskReasons : [];
    el("reasons").innerHTML = reasons.slice(0,6).map((reason) => `<li>${escapeHTML(reason)}</li>`).join("") || "<li>No major local risk reason yet.</li>";
  }

  async function loadStatus() {
    setStatus("Scanning active tab...");
    const tabs = await new Promise((resolve) => chrome.tabs.query({ active: true, currentWindow: true }, resolve));
    const tab = tabs && tabs[0];
    activeTabId = tab && tab.id;
    if (!activeTabId) { setStatus("No active tab found."); return; }
    const response = await sendToContent("AETHERION_GET_STATUS");
    if (!response.ok) { setStatus("Cannot read this page: " + (response.error || "unknown error")); return; }
    render(response); setStatus("Ready.");
  }

  async function analyzeNow() {
    setStatus("Running fresh analysis + site intelligence + learning + trust calibration + report + timeline + causal + graph + counterfactual guard + agent + planner...");
    const response = await sendToContent("AETHERION_ANALYZE_NOW");
    if (response.ok) { render(response); setStatus("Analysis updated."); }
    else setStatus("Analyze failed: " + (response.error || "unknown"));
  }

  async function saveSession() {
    setStatus("Saving session + site intelligence + learning profile + trust calibration + agent + action plan...");
    const response = await sendToContent("AETHERION_SAVE_SESSION");
    if (response.ok) { render(response); setStatus("Session saved to local memory."); }
    else setStatus("Save failed: " + (response.error || "unknown"));
  }

  async function applyAction(actionId) {
    setStatus("Applying local action...");
    const response = await sendToContent("AETHERION_APPLY_ACTION", { actionId });
    if (response.ok) { render(response); setStatus(response.message || "Action applied."); }
    else setStatus("Action failed: " + (response.message || response.error || "unknown"));
  }

  async function undoActions() {
    setStatus("Undoing visual assists...");
    const response = await sendToContent("AETHERION_UNDO_ACTIONS");
    if (response.ok) { render(response); setStatus((response.result && response.result.message) || "Undo complete."); }
    else setStatus("Undo failed: " + (response.error || "unknown"));
  }


  async function runAutoMode() {
    setStatus("Running Policy Engine+ auto-mode...");
    const response = await sendToContent("AETHERION_RUN_AUTO_MODE");
    if (response.ok) { render(response); setStatus(response.result && response.result.applied ? `Auto applied ${response.result.applied} action(s).` : "Auto-mode checked; nothing safe to auto-apply."); }
    else setStatus("Auto-mode failed: " + (response.error || "unknown"));
  }

  function exportReport() {
    if (!lastPayload || !lastPayload.status) { setStatus("No report available yet."); return; }
    const report = { exportedAt: new Date().toISOString(), product: "Aetherion DevOS", version: "18.0.0", reportIntelligence: lastPayload && lastPayload.status && lastPayload.status.reportIntelligence, timelineIntelligence: lastPayload && lastPayload.status && lastPayload.status.timelineIntelligence, evidenceGraph: lastPayload && lastPayload.status && lastPayload.status.evidenceGraph, counterfactualGuard: lastPayload && lastPayload.status && lastPayload.status.counterfactualGuard, payload: lastPayload };
    const blob = new Blob([JSON.stringify(report, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    const site = (lastPayload.status.site || "site").replace(/[^a-z0-9._-]/gi, "_");
    a.href = url;
    a.download = `aetherion_v18_report_${site}_${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 500);
    setStatus("Report exported as JSON.");
  }

  async function setOverlay(enabled) {
    const response = await sendToContent("AETHERION_SET_OVERLAY", { enabled });
    if (response.ok) setStatus(enabled ? "Overlay enabled." : "Overlay disabled.");
    else setStatus("Overlay update failed: " + (response.error || "unknown"));
  }

  async function setPatch(patch, label) {
    const response = await sendToContent("AETHERION_SET_SETTING", { patch });
    if (response.ok) { render(response); setStatus(label || "Setting updated."); }
    else setStatus("Setting failed: " + (response.error || "unknown"));
  }

  async function setTrusted(trusted) {
    const response = await sendToContent("AETHERION_TRUST_SITE", { trusted });
    if (response.ok) { render(response); setStatus(trusted ? "Site marked as trusted." : "Site trust removed."); }
    else setStatus("Trust update failed: " + (response.error || "unknown"));
  }

  async function setTrustLevel(level) {
    setStatus(`Setting trust level: ${level}...`);
    const response = await sendToContent("AETHERION_SET_TRUST_LEVEL", { level });
    if (response.ok) { render(response); setStatus(`Trust level set to ${level}.`); }
    else setStatus("Trust calibration update failed: " + (response.error || "unknown"));
  }


  async function addRulePreset(presetType, label) {
    setStatus(`Adding rule: ${label || presetType}...`);
    const response = await sendToContent("AETHERION_ADD_RULE_PRESET", { presetType });
    if (response.ok) { render(response); setStatus("Rule added for this site."); }
    else setStatus("Rule add failed: " + (response.error || "unknown"));
  }

  async function removeRule(ruleId) {
    setStatus("Removing rule...");
    const response = await sendToContent("AETHERION_REMOVE_RULE", { ruleId });
    if (response.ok) { render(response); setStatus("Rule removed."); }
    else setStatus("Rule remove failed: " + (response.error || "unknown"));
  }

  async function clearSiteRules() {
    setStatus("Clearing rules for this site...");
    const response = await sendToContent("AETHERION_CLEAR_SITE_RULES");
    if (response.ok) { render(response); setStatus("Site rules cleared."); }
    else setStatus("Clear site rules failed: " + (response.error || "unknown"));
  }

  async function clearMemory() {
    setStatus("Clearing Aetherion v18 memory...");
    chrome.storage.local.set({
      "aetherion.sessions.v18": [],
      "aetherion.siteProfiles.v18": {},
      "aetherion.agentLog.v18": [],
      "aetherion.actionLog.v18": [],
      "aetherion.policyLog.v18": [],
      "aetherion.siteIntelLog.v18": [],
      "aetherion.learningLog.v18": [],
      "aetherion.rules.v18": [],
      "aetherion.ruleLog.v18": [],
      "aetherion.trustLog.v18": [],
      "aetherion.reportLog.v18": [],
      "aetherion.timelineLog.v18": [],
      "aetherion.causalLog.v18": [],
      "aetherion.evidenceGraphLog.v18": [],
      "aetherion.counterfactualLog.v18": [],
      "aetherion.settings.v18": {
        overlayEnabled: true, compactOverlay: false, guardBannerEnabled: true, guardBannerCriticalOnly: false,
        autoSaveSessions: true, agentEnabled: true, plannerEnabled: true, actionSafeMode: true,
        policyEnabled: true, policyMode: "balanced", autoModeEnabled: false, autoApplyVisualSafeActions: true, autoApplyMemoryActions: true, policyDryRun: false,
        siteIntelligenceEnabled: true, learningProfilesEnabled: true, ruleComposerEnabled: true, trustCalibrationEnabled: true, reportIntelligenceEnabled: true, reportAutoBuild: true, timelineIntelligenceEnabled: true, timelineAutoCapture: true, causalGuardEnabled: true, evidenceGraphEnabled: true, counterfactualGuardEnabled: true, adaptivePolicyHints: true, siteReputationSensitivity: "balanced", learningSensitivity: "balanced",
        recommendationMode: "balanced", maxSessions: 300, maxAgentLog: 300, maxActionLog: 300, maxPolicyLog: 300, maxSiteIntelLog: 300, maxLearningLog: 300, maxRuleLog: 300, maxTrustLog: 300, maxReportLog: 300, maxTimelineLog: 300, maxCausalLog: 300, maxEvidenceGraphLog: 300, maxCounterfactualLog: 300,
        highMutationThreshold: 120, criticalMutationThreshold: 350, trustedRiskDiscount: 10, debugMode: false
      }
    }, async () => { setStatus("Memory cleared."); await loadStatus(); });
  }

  document.addEventListener("DOMContentLoaded", () => {
    el("analyzeBtn").addEventListener("click", analyzeNow);
    el("saveBtn").addEventListener("click", saveSession);
    el("exportBtn").addEventListener("click", exportReport);
    el("undoBtn").addEventListener("click", undoActions);
    el("autoBtn").addEventListener("click", runAutoMode);
    el("refreshBtn").addEventListener("click", loadStatus);
    el("clearBtn").addEventListener("click", clearMemory);
    el("overlayToggle").addEventListener("change", (event) => setOverlay(event.target.checked));
    el("compactToggle").addEventListener("change", (event) => setPatch({ compactOverlay: event.target.checked }, "Compact overlay updated."));
    el("agentToggle").addEventListener("change", (event) => setPatch({ agentEnabled: event.target.checked }, "Agent setting updated."));
    el("plannerToggle").addEventListener("change", (event) => setPatch({ plannerEnabled: event.target.checked }, "Planner setting updated."));
    el("safeModeToggle").addEventListener("change", (event) => setPatch({ actionSafeMode: event.target.checked }, "Safe mode updated."));
    el("policyToggle").addEventListener("change", (event) => setPatch({ policyEnabled: event.target.checked }, "Policy engine updated."));
    el("autoModeToggle").addEventListener("change", (event) => setPatch({ autoModeEnabled: event.target.checked }, "Auto-mode guard updated."));
    el("dryRunToggle").addEventListener("change", (event) => setPatch({ policyDryRun: event.target.checked }, "Policy dry-run updated."));
    el("siteIntelToggle").addEventListener("change", (event) => setPatch({ siteIntelligenceEnabled: event.target.checked }, "Site Intelligence+ updated."));
    el("learningToggle").addEventListener("change", (event) => setPatch({ learningProfilesEnabled: event.target.checked }, "Learning Profiles+ and Rule Composer+ updated."));
    el("adaptivePolicyToggle").addEventListener("change", (event) => setPatch({ adaptivePolicyHints: event.target.checked }, "Adaptive policy hints updated."));
    el("ruleComposerToggle").addEventListener("change", (event) => setPatch({ ruleComposerEnabled: event.target.checked }, "Rule Composer+ updated."));
    el("trustCalibrationToggle").addEventListener("change", (event) => setPatch({ trustCalibrationEnabled: event.target.checked }, "Trust Calibration+ updated."));
    el("reportIntelligenceToggle").addEventListener("change", (event) => setPatch({ reportIntelligenceEnabled: event.target.checked }, "Report Intelligence+ updated."));
    el("timelineIntelligenceToggle").addEventListener("change", (event) => setPatch({ timelineIntelligenceEnabled: event.target.checked }, "Timeline Intelligence+ updated."));
    el("causalGuardToggle").addEventListener("change", (event) => setPatch({ causalGuardEnabled: event.target.checked }, "Causal Guard+ updated."));
    el("evidenceGraphToggle").addEventListener("change", (event) => setPatch({ evidenceGraphEnabled: event.target.checked }, "Evidence Graph+ updated."));
    el("counterfactualGuardToggle").addEventListener("change", (event) => setPatch({ counterfactualGuardEnabled: event.target.checked }, "Counterfactual Guard+ updated."));
    el("guardToggle").addEventListener("change", (event) => setPatch({ guardBannerEnabled: event.target.checked }, "Guard banner setting updated."));
    el("criticalOnlyToggle").addEventListener("change", (event) => setPatch({ guardBannerCriticalOnly: event.target.checked }, "Guard threshold updated."));
    el("trustToggle").addEventListener("change", (event) => setTrusted(event.target.checked));
    el("trustLocalBtn").addEventListener("click", () => setTrustLevel("local"));
    el("trustTrustedBtn").addEventListener("click", () => setTrustLevel("trusted"));
    el("trustWatchedBtn").addEventListener("click", () => setTrustLevel("watched"));
    el("trustSensitiveBtn").addEventListener("click", () => setTrustLevel("sensitive"));
    el("trustBlockedBtn").addEventListener("click", () => setTrustLevel("blocked"));
    el("modeSelect").addEventListener("change", (event) => setPatch({ recommendationMode: event.target.value }, "Recommendation mode updated."));
    el("policyModeSelect").addEventListener("change", (event) => setPatch({ policyMode: event.target.value }, "Policy mode updated."));
    el("ruleNoBannerBtn").addEventListener("click", () => addRulePreset("NO_BANNER_HERE", "No banner here"));
    el("ruleProtectiveBtn").addEventListener("click", () => addRulePreset("PROTECTIVE_HERE", "Protective here"));
    el("ruleObserveBtn").addEventListener("click", () => addRulePreset("OBSERVE_HERE", "Observe only here"));
    el("ruleCompactBtn").addEventListener("click", () => addRulePreset("COMPACT_HERE", "Compact here"));
    el("ruleAutoOffBtn").addEventListener("click", () => addRulePreset("AUTO_OFF_HERE", "Auto off here"));
    el("ruleBlockVisualBtn").addEventListener("click", () => addRulePreset("BLOCK_VISUAL_ASSISTS_HERE", "Block visual assists here"));
    el("ruleStrictSensitiveBtn").addEventListener("click", () => addRulePreset("STRICT_SENSITIVE_HERE", "Strict sensitive here"));
    el("ruleClearSiteBtn").addEventListener("click", clearSiteRules);
    loadStatus();
  });
})();
