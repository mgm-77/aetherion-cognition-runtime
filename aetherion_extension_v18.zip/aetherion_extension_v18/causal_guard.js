/*
 * Aetherion DevOS v18 - Causal Guard+ and Evidence Graph+ and Counterfactual Guard+
 * Local heuristic causal attribution for risk shifts. It does not claim certainty;
 * it builds a ranked "likely cause" map from timeline deltas, DOM/security signals,
 * policy state, and user interaction context.
 */
(function () {
  "use strict";

  function clamp(value, min, max) { return Math.max(min, Math.min(max, Number(value || 0))); }
  function safeArray(value) { return Array.isArray(value) ? value : []; }
  function safeNumber(value, fallback) { const n = Number(value); return Number.isFinite(n) ? n : fallback; }
  function round(value) { return Math.round(Number(value || 0)); }

  function confidenceFrom(score, evidenceCount, riskDelta) {
    const deltaBoost = Math.min(20, Math.abs(Number(riskDelta || 0)) * 2);
    return clamp(Math.round(score * 0.62 + evidenceCount * 7 + deltaBoost), 0, 99);
  }

  function addCause(causes, type, label, impact, evidence, recommendation) {
    const cleanImpact = clamp(impact, 0, 100);
    if (cleanImpact <= 0) return;
    causes.push({
      type,
      label,
      impact: cleanImpact,
      evidence: safeArray(evidence).filter(Boolean).slice(0, 5),
      recommendation: recommendation || "Observe and keep the action reversible.",
      generatedAt: new Date().toISOString()
    });
  }

  function extractSignalDeltas(latestPoint, previousPoint, snapshot) {
    const latest = latestPoint || {};
    const prev = previousPoint || {};
    const signals = snapshot.signals || {};
    const scripts = signals.scripts || {};
    const forms = signals.forms || {};
    const links = signals.links || {};
    const dark = signals.darkPatterns || {};
    const iframes = signals.iframes || {};
    return {
      riskDelta: safeNumber(latest.riskDelta, safeNumber(snapshot.riskScore, 0) - safeNumber(prev.riskScore, 0)),
      mutationDelta: safeNumber(latest.deltaMutations, safeNumber(snapshot.mutations, 0) - safeNumber(prev.mutations, 0)),
      anomalyDelta: safeNumber(latest.deltaAnomalies, safeNumber(snapshot.anomalies, 0) - safeNumber(prev.anomalies, 0)),
      userDelta: safeNumber(latest.deltaUserEvents, 0),
      trigger: latest.trigger || snapshot.trigger || "sample",
      scripts,
      forms,
      links,
      dark,
      iframes
    };
  }

  function causeCategoryFromRisk(risk) {
    const categories = risk && risk.categories ? risk.categories : {};
    let best = ["unknown", 0];
    for (const key of Object.keys(categories)) {
      if (Number(categories[key] || 0) > best[1]) best = [key, Number(categories[key] || 0)];
    }
    return { category: best[0], weight: best[1] };
  }

  function analyze(input) {
    const snapshot = input.snapshot || {};
    const risk = input.risk || { score: snapshot.riskScore || 0, level: snapshot.riskLevel || "UNKNOWN", signals: snapshot.signals || {}, categories: snapshot.riskCategories || {}, reasons: [] };
    const points = safeArray(input.points);
    const timeline = input.timelineIntelligence || {};
    const settings = input.settings || {};
    const latestPoint = timeline.latestPoint || points[points.length - 1] || null;
    const previousPoint = points.length > 1 ? points[points.length - 2] : null;
    const deltas = extractSignalDeltas(latestPoint, previousPoint, Object.assign({}, snapshot, { signals: risk.signals || snapshot.signals || {} }));
    const causes = [];
    const riskDelta = safeNumber(timeline.riskDelta, deltas.riskDelta);
    const score = safeNumber(risk.score, snapshot.riskScore || 0);
    const level = risk.level || snapshot.riskLevel || "UNKNOWN";
    const category = causeCategoryFromRisk(risk);

    // 1) DOM / mutation burst attribution.
    if (deltas.mutationDelta > safeNumber(settings.highMutationThreshold, 120) || deltas.anomalyDelta > 0 || category.category === "behavior") {
      addCause(
        causes,
        "MUTATION_BURST",
        "DOM mutation burst / page self-change",
        clamp(18 + deltas.mutationDelta / 18 + deltas.anomalyDelta * 12 + (category.category === "behavior" ? category.weight : 0), 0, 95),
        [
          `DOM Δ: ${round(deltas.mutationDelta)}`,
          `Anomaly Δ: ${round(deltas.anomalyDelta)}`,
          deltas.trigger ? `Timeline trigger: ${deltas.trigger}` : null,
          category.category === "behavior" ? `Dominant risk category: behavior (${round(category.weight)})` : null
        ],
        "Wait for the page to stabilize; keep guard banner/action planner active."
      );
    }

    // 2) Script/tracker attribution.
    const scriptImpact = clamp((deltas.scripts.trackers || 0) * 8 + (deltas.scripts.crypto || 0) * 30 + (deltas.scripts.external || 0) * 2 + (deltas.scripts.inlineLarge || 0) * 3, 0, 100);
    if (scriptImpact > 0 || category.category === "tracking") {
      addCause(
        causes,
        "SCRIPT_ACTIVITY",
        "Script / tracker surface",
        clamp(scriptImpact + (category.category === "tracking" ? category.weight : 0), 0, 96),
        [
          `Trackers: ${deltas.scripts.trackers || 0}`,
          `External scripts: ${deltas.scripts.external || 0}`,
          `Large inline scripts: ${deltas.scripts.inlineLarge || 0}`,
          (deltas.scripts.crypto || 0) ? `Crypto-like patterns: ${deltas.scripts.crypto}` : null,
          safeArray(deltas.scripts.examples)[0] ? `Example: ${safeArray(deltas.scripts.examples)[0]}` : null
        ],
        "Prefer observe/protective policy; avoid entering sensitive data until stable."
      );
    }

    // 3) Form/credential attribution.
    const formImpact = clamp((deltas.forms.passwordFields || 0) * 12 + (deltas.forms.externalPostForms || 0) * 18 + (deltas.forms.insecurePasswordForms || 0) * 35 + (deltas.forms.sensitiveInputs || 0) * 4, 0, 100);
    if (formImpact > 0 || category.category === "credential") {
      addCause(
        causes,
        "FORM_SURFACE",
        "Sensitive form / credential surface",
        clamp(formImpact + (category.category === "credential" ? category.weight : 0), 0, 98),
        [
          `Forms: ${deltas.forms.total || 0}`,
          `Password fields: ${deltas.forms.passwordFields || 0}`,
          `External post forms: ${deltas.forms.externalPostForms || 0}`,
          `Insecure password forms: ${deltas.forms.insecurePasswordForms || 0}`,
          `Sensitive inputs: ${deltas.forms.sensitiveInputs || 0}`
        ],
        "Use highlight-sensitive-forms; verify domain before typing credentials."
      );
    }

    // 4) Overlay/dark-pattern attribution.
    const darkImpact = clamp((deltas.dark.hits ? deltas.dark.hits.length : 0) * 8 + (deltas.dark.fixedPanels || 0) * 8 + (deltas.dark.asymmetryHints || 0) * 2 + (deltas.dark.scoreHint || 0), 0, 95);
    if (darkImpact > 0 || category.category === "deception") {
      addCause(
        causes,
        "OVERLAY_DARK_PATTERN",
        "Overlay / dark-pattern pressure",
        clamp(darkImpact + (category.category === "deception" ? category.weight : 0), 0, 95),
        [
          `Fixed panels: ${deltas.dark.fixedPanels || 0}`,
          `Dark-pattern hints: ${deltas.dark.hits ? deltas.dark.hits.length : 0}`,
          `Asymmetry hints: ${deltas.dark.asymmetryHints || 0}`,
          category.category === "deception" ? `Dominant category: deception (${round(category.weight)})` : null
        ],
        "Use reversible soft-hide overlay action rather than destructive blocking."
      );
    }

    // 5) Download/link attribution.
    const linkImpact = clamp((deltas.links.dangerousDownloads || 0) * 28 + (deltas.links.javascriptLinks || 0) * 2 + (deltas.links.newTabExternal || 0) / 2 + (deltas.links.emptyOrMasked || 0) / 3, 0, 100);
    if (linkImpact > 0 || category.category === "downloads") {
      addCause(
        causes,
        "DOWNLOAD_LINK_SURFACE",
        "Risky download / link surface",
        clamp(linkImpact + (category.category === "downloads" ? category.weight : 0), 0, 99),
        [
          `Dangerous download links: ${deltas.links.dangerousDownloads || 0}`,
          `javascript: links: ${deltas.links.javascriptLinks || 0}`,
          `External new-tab links: ${deltas.links.newTabExternal || 0}`,
          safeArray(deltas.links.examples)[0] ? `Example host: ${safeArray(deltas.links.examples)[0].host || "unknown"}` : null
        ],
        "Mark risky download links and avoid installing APK/EXE/MSI files from this page."
      );
    }

    // 6) Iframe/embedding attribution.
    const iframeImpact = clamp((deltas.iframes.external || 0) * 5 + (deltas.iframes.hidden || 0) * 12, 0, 80);
    if (iframeImpact > 0 || category.category === "embedding") {
      addCause(
        causes,
        "EMBEDDED_SURFACE",
        "External or hidden iframe surface",
        clamp(iframeImpact + (category.category === "embedding" ? category.weight : 0), 0, 90),
        [
          `Iframes: ${deltas.iframes.total || 0}`,
          `External iframes: ${deltas.iframes.external || 0}`,
          `Hidden/small iframes: ${deltas.iframes.hidden || 0}`,
          safeArray(deltas.iframes.examples)[0] ? `Example: ${safeArray(deltas.iframes.examples)[0]}` : null
        ],
        "Keep the page watched; iframe-heavy pages benefit from protective policy."
      );
    }

    // 7) User interaction as contextual cause, usually not malicious by itself.
    const userEvents = snapshot.userEvents || {};
    const userImpact = clamp((userEvents.clicks || 0) + (userEvents.keys || 0) * 2 + (userEvents.downloadsClicked || 0) * 15 + (userEvents.passwordFieldsFocused || 0) * 18, 0, 75);
    if (deltas.trigger === "click" || deltas.trigger === "focus" || userImpact >= 20) {
      addCause(
        causes,
        "USER_INTERACTION_CONTEXT",
        "Risk shift followed user interaction",
        userImpact,
        [
          `Clicks: ${userEvents.clicks || 0}`,
          `Keys: ${userEvents.keys || 0}`,
          `Forms focused: ${userEvents.formsFocused || 0}`,
          `Password fields focused: ${userEvents.passwordFieldsFocused || 0}`,
          `Downloads clicked: ${userEvents.downloadsClicked || 0}`
        ],
        "Treat this as context, not proof: user actions may have triggered normal dynamic page behavior."
      );
    }

    causes.sort((a, b) => b.impact - a.impact);
    const top = causes[0] || null;
    const confidence = top ? confidenceFrom(top.impact, top.evidence.length, riskDelta) : 0;
    const status = !top ? "NO_CAUSE_FOUND" : (confidence >= 72 ? "LIKELY_CAUSE_FOUND" : "POSSIBLE_CAUSE_FOUND");
    const causalChain = causes.slice(0, 5).map((cause, index) => ({
      step: index + 1,
      type: cause.type,
      label: cause.label,
      impact: cause.impact,
      evidence: cause.evidence.slice(0, 3)
    }));

    const recommendations = [];
    if (top) recommendations.push({ title: "Primary likely cause", detail: `${top.label}: ${top.recommendation}` });
    if (score >= 55 && confidence < 60) recommendations.push({ title: "Keep uncertainty visible", detail: "Risk is elevated but cause confidence is not high; use reversible actions only." });
    if (riskDelta > 15) recommendations.push({ title: "Risk jumped", detail: "Save a session report now so the timeline and causal chain are preserved." });
    if (level === "CRITICAL") recommendations.push({ title: "Critical posture", detail: "Avoid sensitive input and downloads until the page is reviewed." });
    if (!recommendations.length) recommendations.push({ title: "Continue observing", detail: "No strong causal trigger yet; keep passive monitoring." });

    return {
      status,
      riskScore: score,
      riskLevel: level,
      riskDelta: round(riskDelta),
      timelineMomentum: timeline.momentum || "STABLE",
      primaryCause: top,
      causalConfidence: confidence,
      dominantRiskCategory: category.category,
      dominantRiskWeight: round(category.weight),
      causeMap: causes.reduce((acc, item) => { acc[item.type] = { impact: item.impact, label: item.label }; return acc; }, {}),
      causalChain,
      recommendations: recommendations.slice(0, 4),
      summary: top
        ? `${top.label} is the strongest local explanation for the current risk posture (${confidence}% confidence).`
        : "No single strong local cause was isolated yet.",
      generatedAt: new Date().toISOString(),
      heuristic: true,
      version: "18.0.0"
    };
  }

  window.AetherionCausalGuard = { analyze };
})();
